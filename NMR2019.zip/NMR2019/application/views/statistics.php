<html>
<head>
	<style type="text/css">
		.chart
		{
			width: 750px;
			height: 400px;
			float: left;
		}
	</style>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/chart.js"></script>
	<script type="text/javascript">
		google.charts.load("current", {packages:["corechart", "bar"]});
		google.charts.setOnLoadCallback(function() {
			drawPieChart(count_major);

			drawPieChart(count_gender);
			drawPieChart(count_zodiac);
			drawPieChart(count_price);
			drawPieChart(count_group);
			drawLineChart(count_time);
			drawLineChart(count_time_cumulative);
			drawLineChart(sum_time);
			drawLineChart(sum_time_cumulative);
			drawLineChart(count_batch);
			drawLineChart(count_batch_cumulative);

			drawPieChart(count_major_b1);
			drawPieChart(count_major_b2);
			drawPieChart(count_major_b3);
			drawPieChart(count_major_b4);
			drawPieChart(count_major_b5);

			drawPieChart(count_gender_b1);
			drawPieChart(count_gender_b2);
			drawPieChart(count_gender_b3);
			drawPieChart(count_gender_b4);
			drawPieChart(count_gender_b5);

			drawColChart(count_shift);
		});

		function drawLineChart(obj) {
			var data = google.visualization.arrayToDataTable(obj.values);

			var options = {
				title: obj.title,
				curveType: obj.curveType,
				legend: { position: 'right' },
				series : obj.series
			};

			var chart = new google.visualization.LineChart(document.getElementById(obj.id));

			chart.draw(data, options);
		}


		function drawPieChart(obj) {
			var data = google.visualization.arrayToDataTable(obj.values);

			var options = {
				title: obj.title,
				pieHole: 0.4,
				slices : obj.slices
			};

			var chart = new google.visualization.PieChart(document.getElementById(obj.id));
			chart.draw(data, options);
		};

		function drawColChart(obj) {
			var data = google.visualization.arrayToDataTable(obj.values);

			var view = new google.visualization.DataView(data);
				view.setColumns([0, 1,
					{ calc: "stringify",
					sourceColumn: 1,
					type: "string",
					role: "annotation" }], 2);

			var options = {
				title: obj.title,
				width: 600,
				height: 400,
				bar: {groupWidth: "95%"},
				legend: { position: "none" },
			};
			var chart = new google.visualization.ColumnChart(document.getElementById(obj.id));
			chart.draw(view, options);
		}

		var count_major = {
			values : [
				["Major", 'Count'],
				<?php foreach ($count_major as $key => $value): ?>
					['<?php echo $value->major; ?> (<?php echo $value->count_; ?>)', <?php echo $value->count_; ?>],
				<?php endforeach ?>
				["Comp", 0]
			],
			title : "Major",
			id : "count_major",
			slices : null
		};

		var count_gender = {
			values : [
				["Major", 'Count'],
				<?php foreach ($count_gender as $key => $value): ?>
					['<?php echo $value->gender; ?> (<?php echo $value->count; ?>)', <?php echo $value->count; ?>],
				<?php endforeach ?>
			],
			title : "Gender",
			id : "count_gender",
			slices : {
				0 : {"color": "#6fbbd3"},
				1 : {"color": "#ff5f77"},
			}
		};

		var count_zodiac = {
			values : [
				["Zodiac", 'Count'],
				<?php foreach ($count_zodiac as $key => $value): ?>
					['<?php echo $value->zodiac; ?> ', <?php echo $value->count; ?>],
				<?php endforeach ?>
			],
			title : "Zodiac",
			id : "count_zodiac",
			slices : null
		};

		var count_price = {
			values : [
				["Major", 'Count'],
				<?php foreach ($count_price as $key => $value): ?>
					['<?php 
					switch ($value->price) {
							case 55000:
								echo "5 people";
								break;

							case 70000:
								echo "3 people";
								break;

							case 85000:
								echo "1 person";
								break;

							case 40000:
								echo "Certificate";
								break;
							
							default:
								# code...
								break;
						}
					 ?> (<?php echo $value->count; ?>)', <?php echo $value->count; ?>],
				<?php endforeach ?>
			],
			title : "Price",
			id : "count_price",
			slices : {
				0 : {"color": "#32ddc2"},
				1 : {"color": "#1fbaa2"},
				2 : {"color": "#199582"},
				3 : {"color": "#f48223"}
			}
		};

		var count_group = {
			values : [
				["Major", 'Count'],
				<?php foreach ($count_price as $key => $value): ?>
					<?php 
						switch ($value->price) {
							case 55000:
								$div = 5;
								break;

							case 70000:
								$div = 3;
								break;

							case 85000:
								$div = 1;
								break;

							case 40000:
								$div = 1;
								break;
							
							default:
								$div = 1;
								break;
						}
					 ?>
					['<?php 
					switch ($value->price) {
							case 55000:
								echo "5 people";
								break;

							case 70000:
								echo "3 people";
								break;

							case 85000:
								echo "1 person";
								break;

							case 40000:
								echo "Certificate";
								break;
							
							default:
								# code...
								break;
						}
					 ?> (<?php echo $value->count/$div; ?> groups)', <?php echo $value->count / $div;?>],
				<?php endforeach ?>
			],
			title : "Group",
			id : "count_group",
			slices : {
				0 : {"color": "#32ddc2"},
				1 : {"color": "#1fbaa2"},
				2 : {"color": "#199582"},
				3 : {"color": "#f48223"}
			}
		};

		var count_time = {
			values : [
				["Major", 'Batch 1', 'Batch 2', 'Batch 3', 'Batch 4', 'Batch 5'],
				<?php foreach ($count_time as $key => $value): ?>
					[
						'<?php echo $key; ?>',
						<?php echo isset($value[1]->count) ? $value[1]->count : 0; ?>,
						<?php echo isset($value[2]->count) ? $value[2]->count : 0; ?>,
						<?php echo isset($value[3]->count) ? $value[3]->count : 0; ?>,
						<?php echo isset($value[4]->count) ? $value[4]->count : 0; ?>,
						<?php echo isset($value[5]->count) ? $value[5]->count : 0; ?>
					],
				<?php endforeach ?>
			],
			title : "Time",
			id : "count_time",
			curveType : null,
			series : null
		};

		var count_time_cumulative = {
			values : [
				["Major", 'Batch 1', 'Batch 2', 'Batch 3', 'Batch 4', 'Batch 5'],
				<?php $total = [0,0,0,0,0,0]; ?>
				<?php foreach ($count_time_cumulative as $key => $value): ?>
					[

						'<?php echo $key; ?>',
						<?php $total[1] = isset($value[1]->count) ? $total[1] + $value[1]->count : $total[1] + 0; ?>
						<?php $total[2] = isset($value[2]->count) ? $total[2] + $value[2]->count : $total[2] + 0; ?>
						<?php $total[3] = isset($value[3]->count) ? $total[3] + $value[3]->count : $total[3] + 0; ?>
						<?php $total[4] = isset($value[4]->count) ? $total[4] + $value[4]->count : $total[4] + 0; ?>
						<?php $total[5] = isset($value[5]->count) ? $total[5] + $value[5]->count : $total[5] + 0; ?>

						<?php echo $total[1]; ?>,
						<?php echo $total[2]; ?>,
						<?php echo $total[3]; ?>,
						<?php echo $total[4]; ?>,
						<?php echo $total[5]; ?>
					],
				<?php endforeach ?>
			],
			title : "Time Cumulative",
			id : "count_time_cumulative",
			curveType: null,
			series : null
		};

		var sum_time = {
			values : [
				["Major", 'Batch 1', 'Batch 2', 'Batch 3', 'Batch 4', 'Batch 5'],
				<?php foreach ($sum_time as $key => $value): ?>
					[
						'<?php echo $key; ?>',
						<?php echo isset($value[1]->sum) ? $value[1]->sum : 0; ?>,
						<?php echo isset($value[2]->sum) ? $value[2]->sum : 0; ?>,
						<?php echo isset($value[3]->sum) ? $value[3]->sum : 0; ?>,
						<?php echo isset($value[4]->sum) ? $value[4]->sum : 0; ?>,
						<?php echo isset($value[5]->sum) ? $value[5]->sum : 0; ?>
					],
				<?php endforeach ?>
			],
			title : "Price",
			id : "sum_time",
			curveType : null,
			series : null
		};

		var sum_time_cumulative = {
			values : [
				["Major", 'Batch 1', 'Batch 2', 'Batch 3', 'Batch 4', 'Batch 5'],
				<?php $total = [0,0,0,0,0,0]; ?>
				<?php foreach ($sum_time_cumulative as $key => $value): ?>
					[

						'<?php echo $key; ?>',
						<?php $total[1] = isset($value[1]->sum) ? $total[1] + $value[1]->sum : $total[1] + 0; ?>
						<?php $total[2] = isset($value[2]->sum) ? $total[2] + $value[2]->sum : $total[2] + 0; ?>
						<?php $total[3] = isset($value[3]->sum) ? $total[3] + $value[3]->sum : $total[3] + 0; ?>
						<?php $total[4] = isset($value[4]->sum) ? $total[4] + $value[4]->sum : $total[4] + 0; ?>
						<?php $total[5] = isset($value[5]->sum) ? $total[5] + $value[5]->sum : $total[5] + 0; ?>

						<?php echo $total[1]; ?>,
						<?php echo $total[2]; ?>,
						<?php echo $total[3]; ?>,
						<?php echo $total[4]; ?>,
						<?php echo $total[5]; ?>
					],
				<?php endforeach ?>
			],
			title : "Price Cumulative",
			id : "sum_time_cumulative",
			curveType: null,
			series : null
		};

		var count_batch = {
			values : [
				["Major", '6th', '5th', '4th'],
				<?php foreach ($count_batch as $key => $value): ?>
					[
						'Batch <?php echo $key; ?>',
						<?php echo $value->curr; ?>,
						<?php echo $value->pres5; ?>,
						<?php echo $value->pres4; ?>,
					],
				<?php endforeach ?>

			],
			title : "Count per Batch",
			id : "count_batch",
			curveType : null,
			series : {
				0 : {color: "#f48223"},
				1 : {color: "#aaa"},
				2 : {color: "#ddd"}
			}
		};

		var count_batch_cumulative = {
			values : [
				["Major", '6th', '5th', '4th'],
				<?php $total = [0,0,0,0]; ?>
				<?php $increments = [0, 105, 77, 51, 118, 177]; ?>
				<?php foreach ($count_batch as $key => $value): ?>
					[

						'Batch <?php echo $key; ?>',
						<?php $total[1] = isset($value->curr) ? $total[1] + $value->curr : $total[1] + 0; ?>
						<?php $total[2] += $value->pres5; ?>
						<?php $total[3] += $value->pres4; ?>

						<?php echo $total[1]; ?>,
						<?php echo $total[2]; ?>,
						<?php echo $total[3]; ?>,
					],
				<?php endforeach ?>
			],
			title : "Batch Cumulative",
			id : "count_batch_cumulative",
			curveType: null,
			series : {
				0 : {color: "#f48223"},
				1 : {color: "#aaa"},
				2 : {color: "#ddd"}
			}
		};

		var count_major_b1 = {
			values : [
				["Major", 'Count'],
				<?php if ($count_major_batch[1] != false): ?>
					<?php foreach ($count_major_batch[1] as $key => $value): ?>
						['<?php echo $value->major; ?> (<?php echo $value->count_; ?>)', <?php echo $value->count_; ?>],
					<?php endforeach ?>
				<?php endif ?>
				["Comp", 0]
			],
			title : "Batch 1",
			id : "count_major_b1",
			slices : null
		};

		var count_major_b2 = {
			values : [
				["Major", 'Count'],
				<?php if ($count_major_batch[2] != false): ?>
					<?php foreach ($count_major_batch[2] as $key => $value): ?>
						['<?php echo $value->major; ?> (<?php echo $value->count_; ?>)', <?php echo $value->count_; ?>],
					<?php endforeach ?>
				<?php endif ?>
				["Comp", 0]
			],
			title : "Batch 2",
			id : "count_major_b2",
			slices : null
		};

		var count_major_b3 = {
			values : [
				["Major", 'Count'],
				<?php if ($count_major_batch[3] != false): ?>
					<?php foreach ($count_major_batch[3] as $key => $value): ?>
						['<?php echo $value->major; ?> (<?php echo $value->count_; ?>)', <?php echo $value->count_; ?>],
					<?php endforeach ?>
				<?php endif ?>
				["Comp", 0]
			],
			title : "Batch 3",
			id : "count_major_b3",
			slices : null
		};

		var count_major_b4 = {
			values : [
				["Major", 'Count'],
				<?php if ($count_major_batch[4] != false): ?>
					<?php foreach ($count_major_batch[4] as $key => $value): ?>
						['<?php echo $value->major; ?> (<?php echo $value->count_; ?>)', <?php echo $value->count_; ?>],
					<?php endforeach ?>
				<?php endif ?>
				["Comp", 0]
			],
			title : "Batch 4",
			id : "count_major_b4",
			slices : null
		};

		var count_major_b5 = {
			values : [
				["Major", 'Count'],
				<?php if ($count_major_batch[5] != false): ?>
					<?php foreach ($count_major_batch[5] as $key => $value): ?>
						['<?php echo $value->major; ?> (<?php echo $value->count_; ?>)', <?php echo $value->count_; ?>],
					<?php endforeach ?>
				<?php endif ?>
				["Comp", 0]
			],
			title : "Batch 5",
			id : "count_major_b5",
			slices : null
		};

		var count_gender_b1 = {
			values : [
				["Gender", 'Count'],
				<?php if ($count_gender_batch[1] != false): ?>
					<?php foreach ($count_gender_batch[1] as $key => $value): ?>
						['<?php echo $value->gender; ?> (<?php echo $value->count; ?>)', <?php echo $value->count; ?>],
					<?php endforeach ?>
				<?php endif ?>
				["Comp", 0]
			],
			title : "Batch 1",
			id : "count_gender_b1",
			slices : {
				0 : {"color": "#6fbbd3"},
				1 : {"color": "#ff5f77"},
			}
		};

		var count_gender_b2 = {
			values : [
				["Gender", 'Count'],
				<?php if ($count_gender_batch[2] != false): ?>
					<?php foreach ($count_gender_batch[2] as $key => $value): ?>
						['<?php echo $value->gender; ?> (<?php echo $value->count; ?>)', <?php echo $value->count; ?>],
					<?php endforeach ?>
				<?php endif ?>
				["Comp", 0]
			],
			title : "Batch 2",
			id : "count_gender_b2",
			slices : {
				0 : {"color": "#6fbbd3"},
				1 : {"color": "#ff5f77"},
			}
		};

		var count_gender_b3 = {
			values : [
				["Gender", 'Count'],
				<?php if ($count_gender_batch[3] != false): ?>
					<?php foreach ($count_gender_batch[3] as $key => $value): ?>
						['<?php echo $value->gender; ?> (<?php echo $value->count; ?>)', <?php echo $value->count; ?>],
					<?php endforeach ?>
				<?php endif ?>
				["Comp", 0]
			],
			title : "Batch 3",
			id : "count_gender_b3",
			slices : {
				0 : {"color": "#6fbbd3"},
				1 : {"color": "#ff5f77"},
			}
		};

		var count_gender_b4 = {
			values : [
				["Gender", 'Count'],
				<?php if ($count_gender_batch[4] != false): ?>
					<?php foreach ($count_gender_batch[4] as $key => $value): ?>
						['<?php echo $value->gender; ?> (<?php echo $value->count; ?>)', <?php echo $value->count; ?>],
					<?php endforeach ?>
				<?php endif ?>
				["Comp", 0]
			],
			title : "Batch 4",
			id : "count_gender_b4",
			slices : {
				0 : {"color": "#6fbbd3"},
				1 : {"color": "#ff5f77"},
			}
		};

		var count_gender_b5 = {
			values : [
				["Gender", 'Count'],
				<?php if ($count_gender_batch[5] != false): ?>
					<?php foreach ($count_gender_batch[5] as $key => $value): ?>
						['<?php echo $value->gender; ?> (<?php echo $value->count; ?>)', <?php echo $value->count; ?>],
					<?php endforeach ?>
				<?php endif ?>
				["Comp", 0]
			],
			title : "Batch 5",
			id : "count_gender_b5",
			slices : {
				0 : {"color": "#6fbbd3"},
				1 : {"color": "#ff5f77"},
			}
		};

		var count_shift = {
			values : [
				["Shift", "Registrant", { role: 'style' }, { role: 'annotation' }],
				<?php foreach ($count_shift as $key => $value): ?>
					["Shift <?php echo $key; ?>", <?php echo $value; ?>, "#1fbaa2", "(<?php echo $value; ?>)"],
				<?php endforeach ?>
				// ["Comp", 0, "#1fbaa2"]
			],
			title : "Count per shift",
			id : "count_shift"

		};

		// setInterval(function(){
		// 	document.location.href = "<?php echo base_url(); ?>BNEC/statistics";
		// }, 10000);

	</script>
</head>
<body>
	<div id="count_shift" class="chart"></div>
	<div id="count_major" class="chart"></div>
	<div id="count_gender" class="chart"></div>
	<div id="count_zodiac" class="chart"></div>
	
	<div id="count_time" class="chart"></div>
	<div id="count_time_cumulative" class="chart"></div>
	<div id="sum_time" class="chart" style="<?php if($admin == 0) echo "display: none;"?>"></div>
	<div id="sum_time_cumulative" class="chart" style="<?php if($admin == 0) echo "display: none;"?>"></div>
	<div id="count_price" class="chart"></div>
	<div id="count_group" class="chart"></div>
	<div id="count_batch" class="chart"></div>
	<div id="count_batch_cumulative" class="chart"></div>

	<div style="clear: both;"></div>
	<h2 style="text-align: center;">Major per batch</h2>
	<div id="count_major_b1" class="chart"></div>
	<div id="count_major_b2" class="chart"></div>
	<div id="count_major_b3" class="chart"></div>
	<div id="count_major_b4" class="chart"></div>
	<div id="count_major_b5" class="chart"></div>

	<div style="clear: both;"></div>
	<h2 style="text-align: center;">Gender per batch</h2>
	<div id="count_gender_b1" class="chart"></div>
	<div id="count_gender_b2" class="chart"></div>
	<div id="count_gender_b3" class="chart"></div>
	<div id="count_gender_b4" class="chart"></div>
	<div id="count_gender_b5" class="chart"></div>
</body>
</html>