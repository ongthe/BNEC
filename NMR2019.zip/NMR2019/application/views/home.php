<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/materialize/icon.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/css/materialize.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/materialize/css/materialize.min.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/materialize/jquery.js"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/js/materialize.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/materialize/js/materialize.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/css/materialize.min.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/js/materialize.min.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/2017/css/animate.css">
	<!-- <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/2017/css/style.css"> -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/2017/css/additionalBsByCV101.css">

	<script src="<?php echo base_url(); ?>assets/general/1.0.0/materialize-init.js"></script>
	<script src="<?php echo base_url(); ?>assets/general/1.0.0/form.js"></script>
	<style type="text/css">
		.uniform
		{
			height: 50px;
			line-height: 50px;
			font-size: 1.1em;
		}
		.button{
			width: 380px;
		}

		.btn-180
		{
			width: 100%;
			margin: 5px;
		}
		.btn:hover{
			color: white;
			background-color: #f48223; 
		}
		
		.font-awesome-edit
		{
			margin-left: 4px;
			position: relative;
			top: -4px;
		}

		.ip
		{
			position: fixed; 
			right: 0;
			bottom: 0;
		}

		@media(max-width: 720px)
		{
			.ip
			{
				display: none;
			}
		}
	</style>
</head>
<body>
	<h1 style="text-align: center;">Welcome Binusian 2023</h1>
	<img src="<?php echo base_url(); ?>assets/img/full_logo.png" style="height: 50vh; margin-left: calc(50vw - 25vh);">
	<br>

	<div class="col-md-12 col-sm-12 col-xs-12">
		<div id="btn-computer col-md-12 col-sm-12 col-xs-12">
			<div class="col-md-4 col-sm-12 col-xs-12">
				<a style="text-decoration: none;" class="waves-effect waves-light btn-large btn-180 btn" href="<?php echo base_url(); ?>BNEC/form/1"><i class="material-icons right">person_add</i>1 Person - IDR 85<span class="thou">,000</span></a>
			</div>
			<div class="col-md-4 col-sm-12 col-xs-12">
				<a style="text-decoration: none;" class="waves-effect waves-light btn-large btn-180 btn" href="<?php echo base_url(); ?>BNEC/form/3"><i class="material-icons right">group_add</i>3 People - IDR 225<span class="thou">,000</span></a>
			</div>
			<div class="col-md-4 col-sm-12 col-xs-12">
				<a style="text-decoration: none;" class="waves-effect waves-light btn-large btn-180 btn" href="<?php echo base_url(); ?>BNEC/form/0">
					<i class="material-icons right">list_alt</i>Certificate - IDR 65<span class="thou">,000</span>
				</a>
			</div>
		</div>

	</div>

	<div class="ip">IP : <?php echo $_SERVER['REMOTE_ADDR']; ?></div>
</body>
</html>