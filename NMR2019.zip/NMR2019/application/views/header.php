<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div>HEADER</div>
	<?= $body?>
	<div>FOOTER</div>
</body>
</html>