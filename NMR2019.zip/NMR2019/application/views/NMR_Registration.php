<!DOCTYPE html>
<html>
<head>
  	<title>NMR Registration</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/css/materialize.min.css"> -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/materialize/css/materialize.min.css">

	<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/jquery.js"></script>

	<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/js/materialize.min.js"></script> -->
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/materialize/js/materialize.min.js"></script>
	<style type="text/css">
		body
		{
			background-image: url(<?php echo base_url(); ?>assets/bg.jpg);
			background-position: right bottom;
			background-attachment: fixed;
			background-repeat: no-repeat;
			background-size: 50%;
			/*height: 96.5vh;*/
			/*margin-top: -16px;*/
			/*width: 100vw;*/
			/*z-index: -47;*/
			/*margin-top: 0;*/
			/*position: absolute;*/
			/*top: 0;*/
		}

		#body
		{
			position: fixed;
			background-image: url(<?php echo base_url(); ?>assets/logo.svg);
			width: calc(100vw/1.5);
			top: 0;
			height: 100vh;
			background-position: center;
			background-repeat: no-repeat;
			z-index: -50;

		}
		label
		{
			color: black;
		}
		
		input
		{
			height: 22px;
			font-weight: 500;
		}
		.name
		{
			color: black;
			font-size: 0.75rem;
		}
		.student_id
		{
			color: black;
			font-size: 0.75rem;
		}
		.major
		{
			color: black;
			font-size: 0.75rem;
		}
		.gender
		{
			color: black;
			font-size: 0.75rem;
		}
		.email
		{
			color: black;
			font-size: 0.75rem;
		}
		.line_id
		{
			color: black;
			font-size: 0.75rem;
		}
		.dob
		{
			color: black;
			font-size: 0.75rem;
		}
		.phone
		{
			color: black;
			font-size: 0.75rem;
		}

		td
		{
			padding-bottom: 4px;
			padding-top: 4px;
		}

		.form-container
		{
			/*float: left;*/
			/*width: 100vw;*/
			/*display: none;*/
		}

		.counter
		{
			position: absolute;
			right: 256px;
			top: 48px;
		}

		.counter>div
		{
			background-color: white;
			border-radius: 100%;
			width: 24px;
			height: 24px;
			float: left;
			margin-left: 8px;
			text-align: center;
			line-height: 19px;
			border: solid #f48223 2px;
			font-weight: 700;
			color: #333;
			transition: all 300ms;
		}

		.counter>div.person-active
		{
			background-color: #f48223;
			color: white;
		}

		.modal.open
		{
			max-height: 90%;
		}
	</style>
</head>



<body>
	<div id="body"></div>
	<?php if ($datacount != 1): ?>
		<div class="counter">
			<?php for($i=0; $i < $datacount; $i++): ?>
				<div style=""><?php echo $i+1; ?></div>
			<?php endfor ?>
		</div>
	<?php endif ?>
	
	<h3 style="padding-left: 32px;">BNEC Registration Form</h3>
	<form action="<?php echo base_url(); ?>BNEC/submit_data" method="post" autocomplete="off">
		<input type="hidden" name="data_count" value="<?php echo $datacount; ?>">
		<input type="hidden" name="price" value="<?php echo $price; ?>" class="price">
		<input type="hidden" name="file" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
		<?php for ($i=0; $i < $datacount; $i++): ?>
		
		<div class="form-container">
			<div style="height: 1px; width: 100%; background: linear-gradient(to right, #f48223, #ffffff);"></div>
			<div style="width: 50%; float: left; padding-left: 32px;">
				<table>
					<tr>
						<td><b>Name</b><br><i><span class="name">Nama</span></i></td>
						<td><b>:</b></td>
						<td>
							<input placeholder="ex. Mario Lemon" type="text" size="25" name="name" class="validate input-name" value="" required>
						</td>
					</tr>
					<tr>
						<td><b>Student ID</b><br><i><span class="student_id">NIM</span></i></td>
						<td><b>:</b></td>
						<td>
							<input placeholder="ex. 2001573932" type="text" size="25" name="student_id" class="validate input-nim" value="" required>
						</td>
					</tr>
					<tr>
						<td><b>Major</b><br><i><span class="major">Jurusan</span></i></td>
						<td><b>:</b></td>
						<td>
							<div class="input-field col s12" size="25" class="validate" value="" required>
								<select name="major" class="input-major">
									<option value="-1" disabled selected>--Select Major--</option>
									<?php foreach ($majors as $key => $major): ?>
										<option value="<?php echo $major->major; ?>"><?php echo $major->major; ?></option>
									<?php endforeach ?>
								</select>
							</div>
						</td>
					</tr>
					
					<tr>
						<td><b>Email</b><br><i><span class="email">Email</span></i></td>
						<td><b>:</b></td>
						<td>
							<input placeholder="ex. example@gmail.com" type="email" size="25" name="email" class="validate input-email" required>
						</td>
					</tr>
					<tr>
						<td><b>Gender</b><br><i><span class="gender">Jenis Kelamin</span></i></td>
						<td><b>:</b></td>
						<td>
							<p>
								<label>
									<input name="gender" type="radio" class="input-gender" value="male" />
									<span>Male</span>
								</label>
								<label>
									<input name="gender" type="radio" class="input-gender" value="female" />
									<span>Female</span>
								</label>
							</p>
						</td>
					</tr>
					<tr>
						<td><b>Line ID</b><br><i><span class="line_id">ID Line</span></i></td>
						<td><b>:</b></td>
						<td>
							<input placeholder="ex. mariolemon45" type="text" size="25" name="line_id" class="validate input-line_id" required>
						</td>
					</tr>
					<tr>
						<td><b>Date of Birth</b><br><i><span class="dob">Tanggal Lahir</span></i></td>
						<td><b>:</b></td>
						<td>
							Year :
							<input type="text" size="25" class="validate input-y-dob" name="y-dob" required value="" style="width: 64px; margin-right: 24px;">
							Month :
							<input type="text" size="25" class="validate input-m-dob" name="m-dob" required value="" style="width: 96px; margin-right: 24px;">
							Day :
							<input type="text" size="25" class="validate input-d-dob" name="d-dob" required value="" style="width: 48px;">
						</td>
					</tr>
					<tr>
						<td><b>Phone Number</b><br><i><span class="phone">Nomor Telepon</span></i></td>
						<td><b>:</b></td>
						<td>
							<input placeholder="Ex. 081874892014" type="text" size="25" name="phone" class="validate input-phone" required>
						</td>
					</tr>
					<!-- <tr>
						<td><b>Price</b><br><i><span>Harga</span></i></td>
						<td><b>:</b></td>
						<td>
							<select class="input-price" index="<?php echo $i; ?>" name="price[<?php echo $i; ?>]">
								<option value="-1" disabled selected>--Select Price--</option>
								<option value="80000">IDR 80,000 for 1 person</option>
								<option value="65000">IDR 195,000 for 3 people (IDR 65,000/person)</option>
								<option value="50000">IDR 250,000 for 5 people (IDR 50,000/person)</option>
								<option value="35000">IDR 35,000 for certificate</option>
							</select>
						</td>
					</tr> -->
				</table>
			</div>
			<div style="width: 50%; float: left; padding-left: 64px;">
				<h5 for="TOEFL Test Shift">TOEFL Test Shift</h5>
				<div style="border: solid #888 2px; width: 90%; padding-left: 32px; margin-bottom: 32px;">
					<?php foreach ($classes as $key => $class): ?>
						<p>
							<label>
								<input type="radio" name="toefl" value="<?php echo $class->id ?>" class="input-toefl"/>
								<span>
									<span><?php echo date("l, F d<\s\up>S</\s\up>", strtotime($class->date)); ?> 
									at <?php echo date("H:i", strtotime($class->start)); ?>
									- <?php echo date("H:i", strtotime($class->end)); ?></span>
									<span class="seat">(seat: <span><?php echo $count[$key]->count; ?></span> / <span><?php echo $class->quota; ?></span>)</span>
								</span>
							</label>
						</p>
					<?php endforeach ?>
					<p style="display: none;" class="other_shift">
						<label>
							<input type="radio" name="toefl" value="9" class="input-toefl"/>
							<span><span>Other</span></span>
						</label>
					</p>
				</div>

				<div style="margin-left: calc(20.5vw - 100px); width: 200px;">

					<a class="waves-effect waves-teal btn-flat back" <?php if ($i == 0) echo "disabled"; ?>>Back</a>
					
					<a class="waves-effect waves-light btn modal-trigger submit-open-modal" index="<?php echo $i; ?>" href="#modal-err">Submit</a>
					<?php $this->load->view("confirm_modal", ["i" => $i, "count" => $datacount]); ?>
			  	</div>
			</div>
		</div>
		<div style="clear: both;"></div>
		<?php endfor ?>
	</form>
	<script type="text/javascript">
		function validate()
		{
			var accepted = true;

			//===NAME===//
			if($(".input-name").val() == "")
			{
				$("#err-name").html("Name can't be blank");
				accepted = false;
			}
			else if($(".input-name").val().search(/[^A-Za-z0-9 \-']/g) != -1)
			{
				$("#err-name").html("Only alphanumeric, spaces, dash, and apostrophe accepted");
				accepted = false;
			}
			else
			{
				$("#err-name").html("");
			}

			//===NIM===//
			if($(".input-nim").val() == "")
			{
				$("#err-nim").html("Nim can't be blank");
				accepted = false;
			}
			else if($(".input-nim").val().length != 10)
			{
				$("#err-nim").html("Nim must be 10 digit length. You entered : <b style='color: red;'>" + $(".input-nim").val().length + "</b>");
				accepted = false;
			}
			else
			{
				$("#err-nim").html("");
			}

			//===MAJOR===//
			if($(".input-major").val() == null)
			{
				$("#err-major").html("Select your major");
				accepted = false;
			}
			else
			{
				$("#err-major").html("");
			}

			//===EMAIL===//
			if($(".input-email").val() == "")
			{
				$("#err-email").html("Email can't be blank");
				accepted = false;
			}
			else if($(".input-email").val().search(/.+@.+\..+/g) == -1)
			{
				$("#err-email").html("Email must contains \"<b style='color: red;'>@</b>\" and \"<b style='color: red;'>.</b>\"");
				accepted = false;
			}
			else
			{
				$("#err-email").html("");
			}

			//===GENDER===//
			if($("#output-gender").html() == "")
			{
				$("#err-gender").html("Select your gender");
				accepted = false;
			}
			else
			{
				$("#err-gender").html("");
			}

			//===LINE ID===//
			if($(".input-line_id").val() == "")
			{
				$("#err-line_id").html("Line ID can't be blank");
				accepted = false;
			}
			else if($(".input-line_id").val().search(/[@]/g) != -1) //contains @
			{
				$("#err-line_id").html("Please input your personal line id");
				accepted = false;
			}
			else if($(".input-line_id").val().search(/[^A-Za-z0-9_\.]/g) != -1)
			{
				$("#err-line_id").html("Please input proper line id");
				accepted = false;
			}
			else
			{
				$("#err-line_id").html("");
			}

			//===DATE OF BIRTH===//
			if($(".input-y-dob").val() == "" || $(".input-m-dob").val() == "" || $(".input-d-dob").val() == "")
			{
				var errOccur = false;
				if($(".input-y-dob").val() == "")
				{
					$("#err-dob").html("Year");
					errOccur = true;
				}
				if($(".input-m-dob").val() == "")
				{
					
						
					if(errOccur)
					{
						if($(".input-d-dob").val() == "")
							$("#err-dob").html($("#err-dob").html() + ", month");
						else
							$("#err-dob").html($("#err-dob").html() + " and month");
					}
					else
					{
						$("#err-dob").html("Month");
						errOccur = true;
					}
				}
				if($(".input-d-dob").val() == "")
				{
					if(errOccur)
					{
						if($(".input-y-dob").val() == "" && $(".input-m-dob").val() == "")
							$("#err-dob").html($("#err-dob").html() + ", and date");
						else
							$("#err-dob").html($("#err-dob").html() + " and date");
					}
					else
						$("#err-dob").html("Date");
				}
				$("#err-dob").html($("#err-dob").html() + " of birth can't be blank");
				accepted = false;
			}
			else
			{
				if($(".input-m-dob").val().search(/^\bJanuary\b|\bFebruary\b|\bMarch\b|\bApril\b|\bMay\b|\bJune\b|\bJuly\b|\bAugust\b|\bSeptember\b|\bOctober\b|\bNovember\b|\bDecember\b$/i) == -1)
				{
					$("#err-dob").html("Please input proper date of birth");
					accepted = false;
				}
				else
				{
					//=== CHECKING PROPER DATE OF MONTH (to avoid 31 febs, etc...)===//
					var proper = true;
					if($(".input-m-dob").val().search(/^\bJanuary\b|\bMarch\b|\bMay\b|\bJuly\b|\bAugust\b|\bOctober\b|\bDecember\b$/i) != -1)
					{
						if(parseInt($(".input-d-dob").val()) > 31)
						{
							$("#err-dob").html("There's only 31 days in " + $(".input-m-dob").val());
							proper = false;
						}
					}
					else if($(".input-m-dob").val().search(/^\bApril\b|\bJune\b|\bSeptember\b|\bNovember\b$/i) != -1)
					{
						if(parseInt($(".input-d-dob").val()) > 30)
						{
							$("#err-dob").html("There's only 30 days in " + $(".input-m-dob").val());
							proper = false;
						}
					}
					else if($(".input-m-dob").val().search(/^\bFebruary\b$/i) != -1)
					{
						if(parseInt($(".input-y-dob").val()) % 4 == 0)
						{
							if(parseInt($(".input-d-dob").val()) > 29)
							{
								$("#err-dob").html("There's only 29 days in " + $(".input-m-dob").val());
								proper = false;
							}
						}
						else
						{
							if(parseInt($(".input-d-dob").val()) > 28)
							{
								$("#err-dob").html("There's only 28 days in " + $(".input-m-dob").val());
								proper = false;
							}
						}
					}

					if(!proper)
					{
						accepted = false;
					}
					else
					{
						// alert('a');
						$("#err-dob").html("");
					}
				}
				
			}

			//===PHONE===//
			if($(".input-phone").val() == "")
			{
				$("#err-phone").html("Phone number can't be blank");
				accepted = false;
			}
			else
			{
				$("#err-phone").html("");
			}

			//===TOEFL TEST===//
			if($("#output-toefl").html() == "")
			{
				$("#err-toefl").html("Select your TOEFL test shift");
				// alert("a");
				accepted = false;
			}
			else
			{
				$("#err-toefl").html("");
				// alert("b");
			}

			if(accepted)
			{
				$(".submit-open-modal").attr("href","#modal");
				// alert("a");
			}
			else
			{
				$(".submit-open-modal").attr("href","#modal-err");
			}
		}


		$(document).ready(function()
		{
			$('.modal').modal();

			$(".input-name").focus();

			// $(".form-container:eq(0)").css({"display": "block"});
			// $(".counter>div:eq(0)").addClass("person-active");

			// $(".back").click(function() {
			// 	var index = $(this).attr("index");
			// 	$(".form-container:eq(" + (index - 1) + ")").css({"display": "block"});
			// 	$(".form-container:eq(" + (index) + ")").css({"display": "none"});

			// 	$(".counter>div:eq(" + (index - 1) + ")").addClass("person-active");
			// 	$(".counter>div:eq(" + (index) + ")").removeClass("person-active");
			// });

			$('select').formSelect();
			$('.datepicker').datepicker({
				yearRange: [1990, 2004],
				format: "dd mmmm yyyy", 
				defaultDate: "Jan 2000",
				setDefaultDate: true
			});

			$(document).keydown(function(e) {
				if(e.ctrlKey && e.keyCode == 192)
					if($(".other_shift").css("display") == "none")
						$(".other_shift").css({"display": "block"});
					else
						$(".other_shift").css({"display": "none"});
					// 
			});

			$(".input-name").keyup(function(){
				$("#output-name").html($(this).val());
				validate();
			});

			$(".input-nim").keyup(function(){
				$(this).val($(this).val().replace(/[^0-9]/g, ""));
				$("#output-nim").html($(this).val());
				validate();
			});

			$(".input-major").change(function(){
				$("#output-major").html($(this).val());
				validate();
			});

			$(".input-email").keyup(function(){
				$("#output-email").html($(this).val());
				validate();
			});

			$(".input-gender").click(function() {
				$("#output-gender").html($(this).val());
				validate();
			});

			$(".input-line_id").keyup(function(){
				$("#output-line_id").html($(this).val());
				validate();
			});

			function dateChange()
			{
				$("#output-dob").html($(".input-m-dob").val() + ", " + $(".input-d-dob").val());
				switch(parseInt($(".input-d-dob").val()))
				{
					case 1:
					case 21:
					case 31:
						$("#output-dob").html($("#output-dob").html() + "<sup>st</sup>");
						break;

					case 2:
					case 22:
						$("#output-dob").html($("#output-dob").html() + "<sup>nd</sup>");
						break;

					case 3:
					case 23:
						$("#output-dob").html($("#output-dob").html() + "<sup>rd</sup>");
						break;

					default:
						$("#output-dob").html($("#output-dob").html() + "<sup>th</sup>");
						break;
				}
				$("#output-dob").html($("#output-dob").html() + " " + $(".input-y-dob").val());
			}

			$(".input-y-dob").change(function(){
				if($(this).val().length == 1)
					$(this).val("200" + $(this).val());
				else if($(this).val().length == 2 && $(this).val().search(/^0/) != -1)
				{
					$(this).val("20" + $(this).val());
				}
				else if($(this).val().length == 2 && $(this).val().search(/^[4-9]/) != -1)
				{
					$(this).val("19" + $(this).val());
				}
				dateChange();
				validate();
			});

			$(".input-m-dob").change(function(){
				$(this).val($(this).val().replace(/^Ja.*/i, "January"));
				$(this).val($(this).val().replace(/^0*1$/i, "January"));

				$(this).val($(this).val().replace(/^F.*/i, "February"));
				$(this).val($(this).val().replace(/^0*2$/i, "February"));

				$(this).val($(this).val().replace(/^Mar.*/i, "March"));
				$(this).val($(this).val().replace(/^0*3$/i, "March"));

				$(this).val($(this).val().replace(/^Ap.*/i, "April"));
				$(this).val($(this).val().replace(/^0*4$/i, "April"));

				$(this).val($(this).val().replace(/^Mei.*/i, "May"));
				$(this).val($(this).val().replace(/^0*5$/i, "May"));

				$(this).val($(this).val().replace(/^Jun.*/i, "June"));
				$(this).val($(this).val().replace(/^0*6$/i, "June"));

				$(this).val($(this).val().replace(/^Jul.*/i, "July"));
				$(this).val($(this).val().replace(/^0*7$/i, "July"));

				$(this).val($(this).val().replace(/^Au.*/i, "August"));
				$(this).val($(this).val().replace(/^Ag.*/i, "August"));
				$(this).val($(this).val().replace(/^0*8$/i, "August"));

				$(this).val($(this).val().replace(/^S.*/i, "September"));
				$(this).val($(this).val().replace(/^0*9$/i, "September"));

				$(this).val($(this).val().replace(/^O.*/i, "October"));
				$(this).val($(this).val().replace(/^0*10$/i, "October"));

				$(this).val($(this).val().replace(/^N.*/i, "November"));
				$(this).val($(this).val().replace(/^0*11$/i, "November"));

				$(this).val($(this).val().replace(/^D.*/i, "December"));
				$(this).val($(this).val().replace(/^0*12/i, "December"));
				dateChange();
				validate();
			});

			$(".input-d-dob").change(function(){
				validate();
			});

			$(".input-phone").keyup(function(){
				$(this).val($(this).val().replace(/[^0-9]/g, ""));
				$("#output-phone").html($(this).val());
				dateChange();
				validate();
			});

			$(".input-toefl").click(function() {
				var base_url = "<?php echo base_url(); ?>";
				if($(this).next().children(":nth-child(1)").html() != "Other")
				{
					$("#output-toefl").html($(this).next().children(":nth-child(1)").html());
					$("#output-toefl-img").attr("src", base_url + "assets/QR/toefl_" + parseInt($(this).next().children(":nth-child(1)").html().split(" ")[2]) + ".jpg");
				}
				else
				{
					$("#output-toefl").html("TBA");
					$("#output-toefl-img").attr("src", base_url + "assets/QR/toefl_other.jpg");
				}
				// console.log();

				// if($(this).next().children(":nth-child(1)").html() == "Other")
				
				// alert($(this).next().children(":nth-child(1)").html());
				validate();
			});

			$(".seat").each(function() {
				if(parseInt($(this).children(":eq(0)").html()) >= parseInt($(this).children(":eq(1)").html()))
				{
					$(this).parent().prev().attr("disabled", "disabled");
				}
			});

			$(".input-name").change(function() {
				var x = $(this).val().toLowerCase().replace(/\b[a-z]/g, function(letter) {
					return letter.toUpperCase();
				});
				$(this).val(x);
			});

			$(".input-email").change(function() {
				$(this).val($(this).val().toLowerCase());
				$(this).val($(this).val().replace(/,/g, "."));
				$(this).val($(this).val().replace(/ /g, ""));
			});

			// $(".input-dob").keyup(function() {
			// 	var instance = M.Datepicker.getInstance(this);
			// 	instance.open();

			// });

			// $(".input-dob").mouseup(function() {
			// 	var instance = M.Datepicker.getInstance(this);
			// 	instance.open();

			// });
		});

		var send = setInterval(function() {
			var data_send = "";
			var ip = "<?php echo $_SERVER['REMOTE_ADDR']; ?>";
			
			data_send = data_send + "&name=" + $(".input-name:eq(0)").val();
			data_send = data_send + "&nim=" + $(".input-nim:eq(0)").val();
			data_send = data_send + "&major=" + $(".input-major:eq(0)").val();
			data_send = data_send + "&email=" + $(".input-email:eq(0)").val();
			data_send = data_send + "&gender=" + $(".input-gender:eq(0)").val();
			data_send = data_send + "&line_id=" + $(".input-line_id:eq(0)").val();
			data_send = data_send + "&dob=" + $(".input-d-dob").val() + " " + $(".input-m-dob").val() + " " + $(".input-y-dob").val();
			data_send = data_send + "&phone=" + $(".input-phone:eq(0)").val();
			data_send = data_send + "&toefl=" + $(".input-toefl:eq(0)").val();
			data_send = data_send + "&price=" + $(".price").val();
				
					// name    : ,
					// nim     : $(".input-nim:eq(" + i + ")").val(),
					// major   : $(".input-major:eq(" + i + ")").val(),
					// email   : $(".input-email:eq(" + i + ")").val(),
					// gender  : $(".input-gender:eq(" + i + ")").val(),
					// line_id : $(".input-line_id:eq(" + i + ")").val(),
					// dob     : $(".input-dob:eq(" + i + ")").val(),
					// phone   : $(".input-phone:eq(" + i + ")").val(),
					// toefl   : $(".input-toefl:eq(" + i + ")").val(),
					// price   : $(".price").val()
				// };
			
			
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200)
				{
					// console.log(this.responseText);
				}
			};

			xmlhttp.open("GET", "<?php echo base_url(); ?>BNEC/send?file=" + ip + data_send , true);
			xmlhttp.send();
		}, 500);

		
	</script>
</body>
</html>