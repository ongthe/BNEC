<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/jquery.js"></script>
	<style type="text/css">
		body
		{
			font-family: helvetica;
			font-size: 10pt;
		}

		th
		{
			background-color: #fbd6b7;
		}

		tr
		{
			transition: all 150ms;
		}

		tr:nth-child(odd)
		{
			background-color: #b5e8e0;
		}

		tr:hover
		{
			background-color: #ccd;
		}


		td, th
		{
			border: solid #999 1px;
			padding: 2px 4px 2px 4px;
		}

		.main-table td, #inc-table td
		{
			padding-top: 6px;
			padding-bottom: 6px;
		}

		table
		{
			border-collapse: collapse;
			cursor: default;
		}

		/*#regist_data, #inc-table
		{
			width: 84vw;
		}*/

		/*#regist_data table
		{
			width: 100%;
		}*/

		/*x = x + "<tr><td class=\"data_no\">" + data.member[i].no + "</td>"; //1
		x = x + "<td class=\"data_name\">" + data.member[i].name + "</td>";  //2
		x = x + "<td class=\"data_nim\">" + data.member[i].nim + "</td>";  //3
		x = x + "<td class=\"data_major\">" + data.member[i].major + "</td>";  //4
		x = x + "<td class=\"data_email\">" + data.member[i].email + "</td>";  //5
		x = x + "<td class=\"data_line\">" + data.member[i].line_id + "</td>";  //6
		x = x + "<td class=\"data_dob\">" + data.member[i].dob + "</td>";  //7 
		x = x + "<td class=\"data_gender\">" + data.member[i].gender.slice(0,1) + "</td>"; //8
		x = x + "<td class=\"data_price\">" + numberFormat(data.member[i].price) + "</td>";  //9
		x = x + "<td class=\"data_phone\">" + data.member[i].phone + "</td>";  //10
		x = x + "<td class=\"data_toefl\">" + data.member[i].toefl + "</td></tr>"; //11   */ 

		.main-table .data_no, #inc-table .data_no
		{
			width: 24px;
			text-align: right;
		}

		.main-table .data_ip, #inc-table .data_ip
		{
			width: 32px;
			text-align: right;
		}

		.main-table .data_name, #inc-table .data_name
		{
			width: 256px;
			font-weight: 550;
		}

		.main-table .data_nim, #inc-table .data_nim
		{
			width: 80px;
			font-weight: 550;
		}

		.main-table .data_major, #inc-table .data_major
		{
			width: 256px;
		}

		.main-table .data_email, #inc-table .data_email
		{
			width: 256px;
		}

		.main-table .data_line, #inc-table .data_line
		{
			width: 144px;
		}

		.main-table .data_dob, #inc-table .data_dob
		{
			width: 72px;
		}

		.main-table .data_gender, #inc-table .data_gender
		{
			width: 16px;
		}

		.main-table .data_price, #inc-table .data_price
		{
			width: 48px;
		}

		.main-table .data_phone, #inc-table .data_phone
		{
			width: 96px;
		}

		.main-table .data_toefl, #inc-table .data_toefl
		{
			width: 96px;
		}

		.main-table .data_time, #inc-table .data_time
		{
			width: 191px;
		}

		#total_sum
		{
			color: #f48823;
			margin-top: 0;
			font-family: futura Std;
			text-align: right;
		}

		#total_member
		{
			color: #1fbaa2;
			margin-top: 0;
			font-family: futura Std;
			text-align: right;
		}

		.title
		{
			width: 1281.6px;
			text-align: center;
		}
	</style>

</head>
<?php $table_no = 0; ?>
<body>
	<div id="regist_data">
		<?php foreach ($data as $key => $value): ?>
			<?php
			$comparator = 0;
			if($mode == "toefl")
				$comparator = $value->toefl_test_id;
			else if($mode == "batch")
				$comparator = $value->batch;
			?>
			<?php if ($table_no != $comparator && $table_no != 0): ?>
					</tbody>
				</table>
			<?php endif ?>
			<?php if ($table_no != $comparator): ?>
				<?php $table_no = $comparator; ?>
				<h2 style="text-align: center;">Shift <?php echo $table_no; ?></h2>
				<table style="margin-bottom: 32px;" class="main-table">
					<thead>
						<tr>
							<th class="data_no">No</th>
							<th class="data_name">Name</th>
							<th class="data_nim">NIM</th>
							
							
							
							<th class="data_major">Major</th>
							<th class="data_email">Email</th>
							<th class="data_gender">Gender</th>
							
							<th class="data_price">Price</th>
							<th class="data_line">Line ID</th>
							<th class="data_dob">DOB</th>
							
							
							<th class="data_phone">Phone</th>
							<th class="data_toefl">
								<?php if ($mode == "toefl"): ?>
									Batch
								<?php elseif($mode == "batch"): ?>
									Shift
								<?php endif ?>
								
							</th>
							<th class="time">Timestamp</th>
							<th class="data_ip">IP</th>
						</tr>
					</thead>
					<tbody>
				<?php endif ?>
			
				
					<tr>
						<td><?php echo $value->id; ?></td>
						<td><?php echo $value->name; ?></td>
						<td><?php echo $value->nim; ?></td>
						<td><?php echo $value->major; ?></td>
						<td><?php echo $value->email; ?></td>
						<td><?php echo $value->gender; ?></td>
						<td class="price"><?php echo $value->price; ?></td>
						<td><?php echo $value->line_id; ?></td>
						<td><?php echo date("d M y", strtotime($value->dob)); ?></td>
						<td>'<?php echo $value->phone; ?></td>
						<td>
							
							<?php if ($mode == "toefl"): ?>
									<?php echo $value->batch; ?>
								<?php elseif($mode == "batch"): ?>
									Aug <?php echo (int) (($value->toefl_test_id+1)/2) + 27; ?> - <?php echo sprintf('%02d', 8 + (($value->toefl_test_id+1) % 2) * 5); ?>:00
								<?php endif ?>
							</td>
						<td><?php echo $value->timestamp; ?></td>
						<td><?php echo $value->ip; ?></td>
					</tr>
				
				
		<?php endforeach ?>
	</div>

	
	

	<script type="text/javascript">

		function numberFormat(x)
		{			
			return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		}

		$(document).ready(function(){
			$(".price").each(function(){
				$(this).html(numberFormat($(this).html()));
			});
		});
	</script>
</body>
</html>
