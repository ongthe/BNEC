<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.11/css/all.css" integrity="sha384-p2jx59pefphTFIpeqCcISO9MdVfIm4pNnsL08A6v5vaQc4owkQqxMV8kg4Yvhaw/" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/css/materialize.min.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/js/materialize.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/jquery.js"></script>
	<style type="text/css">
		body
		{
			font-family: helvetica;
			font-size: 10pt;
		}

		th
		{
			background-color: #fbd6b7;
		}

		tr
		{
			transition: all 150ms;
		}

		tr:nth-child(odd)
		{
			background-color: #b5e8e0;
		}

		tr:hover
		{
			background-color: #ccd;
		}


		td, th
		{
			border: solid #999 1px;
			padding: 2px 4px 2px 4px;
		}

		.main-table td, #inc-table td
		{
			padding-top: 6px;
			padding-bottom: 6px;
		}

		table
		{
			border-collapse: collapse;
			cursor: default;
		}

		/*#regist_data, #inc-table
		{
			width: 84vw;
		}*/

		/*#regist_data table
		{
			width: 100%;
		}*/

		/*x = x + "<tr><td class=\"data_no\">" + data.member[i].no + "</td>"; //1
		x = x + "<td class=\"data_name\">" + data.member[i].name + "</td>";  //2
		x = x + "<td class=\"data_nim\">" + data.member[i].nim + "</td>";  //3
		x = x + "<td class=\"data_major\">" + data.member[i].major + "</td>";  //4
		x = x + "<td class=\"data_email\">" + data.member[i].email + "</td>";  //5
		x = x + "<td class=\"data_line\">" + data.member[i].line_id + "</td>";  //6
		x = x + "<td class=\"data_dob\">" + data.member[i].dob + "</td>";  //7 
		x = x + "<td class=\"data_gender\">" + data.member[i].gender.slice(0,1) + "</td>"; //8
		x = x + "<td class=\"data_price\">" + numberFormat(data.member[i].price) + "</td>";  //9
		x = x + "<td class=\"data_phone\">" + data.member[i].phone + "</td>";  //10
		x = x + "<td class=\"data_toefl\">" + data.member[i].toefl + "</td></tr>"; //11   */ 

		.main-table .data_no, #inc-table .data_no
		{
			width: 24px;
			text-align: right;
		}

		.main-table .data_ip, #inc-table .data_ip
		{
			width: 32px;
			text-align: right;
		}

		.main-table .data_name, #inc-table .data_name
		{
			width: 256px;
			font-weight: 550;
		}

		.main-table .data_nim, #inc-table .data_nim
		{
			width: 80px;
			font-weight: 550;
		}

		.main-table .data_major, #inc-table .data_major
		{
			width: 128px;
		}

		.main-table .data_email, #inc-table .data_email
		{
			width: 256px;
		}

		.main-table .data_line, #inc-table .data_line
		{
			width: 144px;
		}

		.main-table .data_dob, #inc-table .data_dob
		{
			width: 72px;
		}

		.main-table .data_gender, #inc-table .data_gender
		{
			width: 16px;
		}

		.main-table .data_price, #inc-table .data_price
		{
			width: 48px;
		}

		.main-table .data_phone, #inc-table .data_phone
		{
			width: 96px;
		}

		.main-table .data_toefl, #inc-table .data_toefl
		{
			width: 32px;
		}

		#total_sum
		{
			color: #f48823;
			margin-top: 0;
			font-family: futura Std;
			text-align: right;
		}

		#total_member
		{
			color: #1fbaa2;
			margin-top: 0;
			font-family: futura Std;
			text-align: right;
		}

		.title
		{
			width: 1281.6px;
			text-align: center;
		}
	</style>

</head>
<body>
	<div id="regist_data">
		
				
			
	</div>

	<table style="margin-bottom: 20	px;" id="inc-table">
		<thead>
			<tr>
				<th class="data_no">No</th>
				<th class="data_ip">IP</th>
				<th class="data_name">Name</th>
				<th class="data_nim">NIM</th>
				<th class="data_major">Major</th>
				<th class="data_email">Email</th>
				<th class="data_line">Line ID</th>
				<th class="data_dob">DOB</th>
				<!-- <th class="data_gender">G</th> -->
				<th class="data_price">price</th>
				<th class="data_phone">Phone</th>
				<th class="data_toefl">S</th>
			</tr>
		</thead>
		<tbody id="incomplete_data">
			
		</tbody>
	</table>
	<div id="tableStatistic" style="position: fixed; height: 100vh; width: 192px; right: 0; top: 0; box-shadow: -1px 0 15px #777; padding-left: 8px; padding-right: 8px; display: none;" >
		<h4 style="font-family: futura Std; text-align: center; font-size: 14pt;" id="date"></h4>

		<table style="width: 100%;">
			<tbody id="shift-counter"></tbody>
		</table>
		
		<table style="margin-top: 16px; width: 100%; text-align: right;">
			<thead>
				<tr>
					<th>B</th>
					<th>Count</th>
					<th>Sum</th>
				</tr>
			</thead>
			<tbody id="price_counter">
				<!-- -->
			</tbody>
		</table>

		<table style="margin-top: 16px; width: 100%; text-align: right;">
			<thead>
				<tr>
					<th>B</th>
					<th>85k</th>
					<th>70k</th>
					<th>55k</th>
					<th>40k</th>
				</tr>
			</thead>
			<tbody id="pack_counter"></tbody>
		</table>

		<table style="margin-top: 16px; width: 100%; text-align: right;">
			<thead>
				<tr>
					<th>?</th>
					<th>19</th>
					<th>20</th>
					<th>21</th>
					<th>22</th>
					<th>23</th>
				</tr>
			</thead>
			<tbody>
				<tr id="gen_counter"></tr>
			</tbody>
		</table>


		<h4 style="margin-bottom: 0">Registrant : </h4>
		<h2 id="total_member"></h2>
		<h4 style="margin-bottom: 0">Total : </h4>
		<h2 id="total_sum">IDR <span></span></h2>
	</div>

<p align="center" style="padding-top: 0">
	 <button id="show" class="btn">Show Table</button>
	<button class="btn"style="display: none;" id="hide">Hide Table</button>
</p>

	<script type="text/javascript">

  $(document).ready(function(){
   
     $("#show").click(function(){
       $("#tableStatistic").show();
       $("#hide").show();
       $("#show").hide()
     });

     $("#hide").click(function(){
      $("#tableStatistic").hide();
      $("#show").show();
      $("#hide").hide();
   });

  });
 </script>

	<script type="text/javascript">

		function numberFormat(x)
		{			
			return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		}

		<?php if($update_rate != 0): ?>var autoUpdate = setInterval(function() { 
			contentReceiver();
		}, <?php echo $update_rate; ?>); <?php endif ?>

		function contentReceiver()
		{
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200)
				{
					// cart = this.responseText;
					var batch = 0;
					var x = "";
					var thead = "<table style=\"margin-bottom: 32px;\" class=\"main-table\"><thead><tr>";

					//===TABLE HEADER===//
					thead = thead + "<th>No</th>";
					thead = thead + "<th>IP</th>";
					thead = thead + "<th>Name</th>";
					thead = thead + "<th>NIM</th>";
					thead = thead + "<th>Major</th>";
					thead = thead + "<th>Email</th>";
					thead = thead + "<th>Line ID</th>";
					thead = thead + "<th>DOB</th>";
					// thead = thead + "<th>G</th>";
					thead = thead + "<th>price</th>";
					thead = thead + "<th>Phone</th>";
					thead = thead + "<th>S</th>";

					thead = thead + "</tr></thead><tbody>";
					var inc = "";
					var stat_per_batch = "";
					var pack_per_batch = "";
					var shift_table = "";
					var binusian_table = "";
					var grandTotalMin = 0;
					var grandTotalMax = 0;
					// console.log("aa");
					// console.log(this.responseText.trim());

					if(this.responseText.trim().slice(0,1) == "{")
					{
						data = JSON.parse(this.responseText);

						var batch_sum = [null, 0, 0, 0, 0, 0]; //sum for pricce
						var batch_count = [null, 0, 0, 0, 0, 0]; //count
						var batch_pack = [null, [0,0,0,0], [0,0,0,0], [0,0,0,0], [0,0,0,0], [0,0,0,0]];
						var shift_counter = [null, 0, 0, 0, 0, 0, 0, 0, 0, 0];
						var binusian_count = [0, 0, 0, 0, 0, 0];

						var total_sum = 0;
						var total_count = 0;
						
						for (var i = 0; i < data.member.length; i++) {

							switch(parseInt(data.member[i].price))
							{
								case 85000:
									batch_pack[data.member[i].batch][0]++;
									break;

								case 70000:
									batch_pack[data.member[i].batch][1]++;
									break;

								case 55000:
									batch_pack[data.member[i].batch][2]++;
									break;

								case 40000:
									batch_pack[data.member[i].batch][3]++;
									break;
							}
							batch_sum[data.member[i].batch] += parseInt(data.member[i].price);
							batch_count[data.member[i].batch] ++;

							shift_counter[data.member[i].toefl]++;

							total_sum += parseInt(data.member[i].price);
							total_count ++;


							data.member[i].major = data.member[i].major.replace(/International Business Management/, "IBM");
							data.member[i].major = data.member[i].major.replace(/International Relations/, "IR");
							data.member[i].major = data.member[i].major.replace(/Marketing Communication/, "Marcomm");
							data.member[i].major = data.member[i].major.replace(/Cinematography.*/, "Cinematography");

							switch(parseInt(data.member[i].nim.slice(0, 2)))
							{
								// binusian_count
								case 19:
									binusian_count[1]++;
									break;

								case 20:
									binusian_count[2]++;
									break;

								case 21:
									binusian_count[3]++;
									break;

								case 22:
									binusian_count[4]++;
									break;

								case 23:
									binusian_count[5]++;
									break;

								default:
									binusian_count[0]++;
									break;
							}

							if(parseInt(data.member[i].batch) != batch)
							{
								if(batch == 0)
								{
									x = x + "<h2 class=\"title\">Batch " + (batch + 1) + "</h2>" + thead;
								}
								else
								{
									x = x + "</tbody></table><h2 class=\"title\">Batch " + (batch + 1) + "</h2>" + thead;
								}
								batch++;
							}

							x = x + "<tr><td class=\"data_no\">" + data.member[i].no + "</td>";
							x = x + "<td class=\"data_ip\">" + data.member[i].ip.split(".")[3] + "</td>";
							x = x + "<td class=\"data_name\">" + data.member[i].name + "</td>";
							x = x + "<td class=\"data_nim\">" + data.member[i].nim + "</td>";
							x = x + "<td class=\"data_major\">" + data.member[i].major + "</td>";
							x = x + "<td class=\"data_email\">" + data.member[i].email + "</td>";
							x = x + "<td class=\"data_line\">" + data.member[i].line_id + "</td>";
							x = x + "<td class=\"data_dob\">" + data.member[i].dob + "</td>";
							// x = x + "<td class=\"data_gender\">" + data.member[i].gender.slice(0,1) + "</td>";
							x = x + "<td class=\"data_price\">" + numberFormat(data.member[i].price) + "</td>";
							x = x + "<td class=\"data_phone\">" + data.member[i].phone + "</td>";
							x = x + "<td class=\"data_toefl\">" + data.member[i].toefl + "</td></tr>";

						}
						x = x + "</tbody></table>";
						for (var i = 0; i < data.inc.length; i++) {

							data.inc[i].major = data.inc[i].major.replace(/International Business Management/, "IBM");
							data.inc[i].major = data.inc[i].major.replace(/International Relations/, "IR");
							data.inc[i].major = data.inc[i].major.replace(/Marketing Communication/, "Marcomm");
							data.inc[i].major = data.inc[i].major.replace(/Cinematography.*/, "Cinematography");

							inc = inc + "<tr style='font-style: italic'><td class=\"data_no\"></td>";
							inc = inc + "<td class=\"data_ip\">" + data.inc[i].computer + "</td>";
							inc = inc + "<td class=\"data_name\">" + data.inc[i].name + "</td>";
							inc = inc + "<td class=\"data_nim\">" + data.inc[i].nim + "</td>";
							if(data.inc[i].major != "null")
								inc = inc + "<td class=\"data_major\">" + data.inc[i].major + "</td>";
							else
								inc = inc + "<td class=\"data_major\"></td>";
							inc = inc + "<td class=\"data_email\">" + data.inc[i].email + "</td>";
							inc = inc + "<td class=\"data_line\">" + data.inc[i].line_id + "</td>";
							inc = inc + "<td class=\"data_dob\">" + data.inc[i].dob + "</td>";
							// inc = inc + "<td class=\"data_gender\">" + data.inc[i].gender.slice(0,1) + "</td>";
							inc = inc + "<td class=\"data_price\">" + numberFormat(data.inc[i].price) + "</td>";
							inc = inc + "<td class=\"data_phone\">" + data.inc[i].phone + "</td>";
							if(data.inc[i].toefl != undefined)
								inc = inc + "<td class=\"data_toefl\">" + data.inc[i].toefl + "</td></tr>";
							else
								inc = inc + "<td class=\"data_toefl\"></td></tr>";
						}

						//=== STATISTICAL TO DISPLAY INCOME PER BATCH ===//
						for (var i = 1; i <= 5; i++) {
							stat_per_batch = stat_per_batch + "<tr><td>" + i + "</td>";
							stat_per_batch = stat_per_batch + "<td>" + batch_count[i] + "</td>";
							stat_per_batch = stat_per_batch + "<td>IDR " + numberFormat(batch_sum[i]) + "</td></tr>";

						}

						for(var i = 1; i <= 5; i++)
						{
							pack_per_batch = pack_per_batch + "<tr><td>" + i + "</td>";
							for(var j = 0; j < 4; j++)
							{
								pack_per_batch = pack_per_batch + "<td>" + batch_pack[i][j] + "</td>";
							}
							pack_per_batch = pack_per_batch + "</tr>";
						}

						for(var i = 1; i <= 8; i++)
						{
							shift_table = shift_table + "<tr><td>Shift - " + i + "</td>";
							shift_table = shift_table + "<td>" + shift_counter[i] + "/90</td></tr>";
						}
						shift_table = shift_table + "<tr><td>Other</td>";
						shift_table = shift_table + "<td>" + shift_counter[9] + "/&infin;</td></tr>";

						for(var i = 0; i < 6; i++)
						{
							binusian_table = binusian_table + "<td>" + binusian_count[i] + "</td>";
						}

						// console.log(this.responseText);
					}
					
					$("#regist_data").html(x);
					$("#incomplete_data").html(inc);
					$("#date").html(data.date);

					$("#shift-counter").html(shift_table);
					$("#price_counter").html(stat_per_batch);
					$("#pack_counter").html(pack_per_batch);
					$("#gen_counter").html(binusian_table);

					$("#total_member").html(total_count);
					$("#total_sum span").html(numberFormat(total_sum));

					
				}
			};

			xmlhttp.open("GET", "<?php echo base_url(); ?>BNEC/req", true);
			xmlhttp.send();
		}

		$(document).ready(function(){
			contentReceiver();
		});
		
	</script>
</body>
</html>
