<style type="text/css">

	.confirm_table td
	{
		padding-top: 2px;
		padding-bottom: 2px;
	}

	.confirm_table tr
	{
		border-bottom: none;
	}
	.confirm_table td:nth-child(1)
	{
		width: 29%;
	}

	.confirm_table td:nth-child(2)
	{
		width: 1%;
	}

	.confirm_table td:nth-child(3)
	{
		width: 70%;
	}

	.qr_code
	{
		margin-left: calc(50% - 115px);
	}
</style>

<div id="modal" class="modal">
	<div class="modal-content">
		<h4>You will submit</h4>
		<table class="confirm_table">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td id="output-name"></td>
			</tr>
			<tr>
				<td>NIM</td>
				<td>:</td>
				<td id="output-nim"></td>
			</tr>
			<tr>
				<td>Major</td>
				<td>:</td>
				<td id="output-major"></td>
			</tr>
			<tr>
				<td>Gender</td>
				<td>:</td>
				<td id="output-gender"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td id="output-email"></td>
			</tr>
			<tr>
				<td>Line ID</td>
				<td>:</td>
				<td id="output-line_id"></td>
			</tr>
			<tr>
				<td>Date of Birth</td>
				<td>:</td>
				<td id="output-dob"></td>
			</tr>
			<tr>
				<td>Phone Number</td>
				<td>:</td>
				<td id="output-phone"></td>
			</tr>
		</table>
		<p>Your TOEFL test will be held on <span id="output-toefl"></span></p>
		<img class="qr_code" src="<?php echo base_url(); ?>assets/QR/toefl_28" id="output-toefl-img">
	</div>
	<div class="modal-footer">
		<a href="#!" class="modal-close waves-effect waves-green btn-flat">Cancel</a>
		<?php if ($i == $count - 1): ?>
			<button class="modal-close btn waves-effect waves-light" type="submit" name="action">Submit</button>
		<?php else: ?>
			<button class="modal-close btn waves-effect waves-light" type="button" name="action" id="next" index="<?php echo $i; ?>">Next</button>
		<?php endif ?>
		
	</div>
</div>

<div id="modal-err" class="modal">
	<div class="modal-content">
		<h5 style="color: #f48223; font-weight: 700;">Warning!</h5>
		<p id="err-name">Name can't be blank</p>
		<p id="err-nim">Nim can't be blank</p>
		<p id="err-major">Select your major</p>
		<p id="err-email">Email can't be blank</p>
		<p id="err-gender">Select your gender</p>
		<p id="err-line_id">Line ID can't be blank</p>
		<p id="err-dob">Year, month, and date of birth can't be blank</p>
		<p id="err-phone">Phone number can't be blank</p>
		<p id="err-toefl">Select your TOEFL test shift</p>
	</div>
	<div class="modal-footer">
		<a href="#!" class="modal-close waves-effect waves-green btn-flat">Back</a>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function() {
		$("button#next").click(function() {
			var index = parseInt($(this).attr("index"));
			$(".form-container:eq(" + (index + 1) + ")").css({"display": "block"});
			$(".form-container:eq(" + (index) + ")").css({"display": "none"});

			$(".counter>div:eq(" + (index + 1) + ")").addClass("person-active");
			$(".counter>div:eq(" + (index) + ")").removeClass("person-active");

		});
		
	});
	
</script>