<table>
	<thead>
			<tr>
				<th>No</th>
				<th>name</th>
				<th>NIM</th>
				<th>Major</th>
			</tr>
	</thead>
	<tbody>
		<?php $count = 0; ?>
		<?php foreach ($data as $key => $value): ?>
			<tr>
				<td><?php echo ++$count; ?></td>
				<td><?php echo $value->name; ?></td>
				<td><?php echo $value->nim; ?></td>
				<td><?php echo $value->major; ?></td>
			</tr>
		<?php endforeach ?>
	</tbody>
</table>