<!DOCTYPE html>
<html>
<head>
  	<title>NMR Registration</title>
  	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.11/css/all.css" integrity="sha384-p2jx59pefphTFIpeqCcISO9MdVfIm4pNnsL08A6v5vaQc4owkQqxMV8kg4Yvhaw/" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/css/materialize.min.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/js/materialize.min.js"></script>
	<style type="text/css">
		label
		{
			color: black;
		}
		span
		{
			color: black;
		}
		input
		{
			height: 22px;
		}
		.name
		{
			color: black;
			font-size: 0.75rem;
		}
		.student_id
		{
			color: black;
			font-size: 0.75rem;
		}
		.major
		{
			color: black;
			font-size: 0.75rem;
		}
		.gender
		{
			color: black;
			font-size: 0.75rem;
		}
		.email
		{
			color: black;
			font-size: 0.75rem;
		}
		.line_id
		{
			color: black;
			font-size: 0.75rem;
		}
		.dob
		{
			color: black;
			font-size: 0.75rem;
		}
		.phone
		{
			color: black;
			font-size: 0.75rem;
		}
	</style>
</head>
<script type="text/javascript">
	function validate(){
		var name = document.getElementsById("Name");
		document.getElementsById("Name").innerHTML = name;
		var Student_id = document.getElementsById("student_id");
		document.getElementsById("student_id").innerHTML = Student_id;
		var major = document.getElementsById("Major");
		document.getElementsById("Major").innerHTML = major;
		var gender = document.getElementsByTagName("group1");
		document.getElementsById("group1").innerHTML = gender;
		var email = document.getElementsById("Email");
		document.getElementsById("Email").innerHTML = email;
		var line_ID = document.getElementsById("Line_ID");
		document.getElementsById("Line_ID").innerHTML = line_ID;
		var dob = document.getElementsById("DoB");
		document.getElementsById("DoB").innerHTML = dob;
		var phone = document.getElementsById("phone");
		document.getElementsById("phone").innerHTML = phone;
		var TOEFL = document.getElementsById("group2");
		document.getElementsById("group2").innerHTML = TOEFL;
	}
</script>
<body>
<span style="font-size: 2.50rem">Registration Form</span>
	<form action="BNEC/submit_data" method="post" autocomplete="off">
		<table class="col-md-4">
			<tr>
				<td>Name<br><i><span class="name">Nama</span></i></td>
				<td><b>:</b></td>
				<td>
					<input id="Name" placeholder="ex. Mario Lemon" type="text" size="25" name="student_name" class="validate" value="" required>
				</td>
			</tr>
			<tr>
				<td>Student ID<br><i><span class="student_id">NIM</span></i></td>
				<td><b>:</b></td>
				<td>
					<input id="Student" placeholder="ex. 2001573932" type="text" size="25" name="student_ID" class="validate" value="" required>
				</td>
			</tr>
			<tr>
				<td>Major<br><i><span class="major">Jurusan</span></i></td>
				<td><b>:</b></td>
				<td>
					<div class="input-field col s12" size="25" name="subject" class="validate" value="" required>
						<select id="Major">
							<option value="-1" disabled selected>--Select Major--</option>
							<option value="Accounting">Accounting</option>
							<option value="Business Creation">Business Creation</option>
							<option value="Chinese Literature">Chinese Literature</option>
							<option value="Cinematography (Film)">Cinematography (Film)</option>
							<option value="Computer Science">Computer Science</option>
							<option value="Computer Science (Global Class)">Computer Science (Global Class)</option>
							<option value="Finance">Finance</option>
							<option value="Food Technology">Food Technology</option>
							<option value="Information Systems">Information Systems</option>
							<option value="International Business Management">International Business Management</option>
							<option value="International Business Management (Global Class)">International Business Management (Global Class)</option>
							<option value="International Marketing">International Marketing</option>
							<option value="International Relations (Global Class)">International Relations (Global Class)</option>
							<option value="Management">Management</option>
							<option value="Management (Master Track)">Management (Master Track)</option>
							<option value="Marketing Communication">Marketing Communication</option>
							<option value="Mass Communication">Mass Communication</option>
							<option value="Visual Communication Design - Animation">Visual Communication Design - Animation</option>
							<option value="Visual Communication Design - New Media">Visual Communication Design - New Media</option>
						</select>
					</div>
				</td>
			</tr>
			<tr>
				<td>Gender<br><i><span class="gender">Jenis Kelamin</span></i></td>
				<td><b>:</b></td>
				<td>
					<p>
						<label>
							<input name="Group1" type="radio"/>
							<span>Male</span>
						</label>
						<label>
							<input name="Group1" type="radio"/>
							<span>Female</span>
						</label>
					</p>
				</td>
			</tr>
			<tr>
				<td>Email<br><i><span class="email">Email</span></i></td>
				<td><b>:</b></td>
				<td>
					<input id="Email" placeholder="ex. example@gmail.com" type="email" size="25" name="email_student" class="validate" required>
				</td>
			</tr>
			<tr>
				<td>Line ID<br><i><span class="line_id">ID Line</span></i></td>
				<td><b>:</b></td>
				<td>
					<input id="Line_ID" placeholder="ex. mariolemon45" type="text" size="25" name="LINE_ID" class="validate" required>
				</td>
			</tr>
			<tr>
				<td>Date of Birth<br><i><span class="dob">Tanggal Lahir</span></i></td>
				<td><b>:</b></td>
				<td>
					<input id="DoB" type="text" size="25" name="DOB" class="datepicker" required>
				</td>
			</tr>
			<tr>
				<td>Phone Number<br><i><span class="phone">Nomor Telepon</span></i></td>
				<td><b>:</b></td>
				<td>
					<input id="Phone" placeholder="Ex. 081874892014" type="text" size="25" name="student_phone" class="validate" required>
				</td>
			</tr>
		</table>
		<div class="col-md-4">
			<p>
				<label for="TOEFL Test Shift">TOEFL Test Shift</label>
				<p>
					<label for="27 August 2018">27 August 2018</label>
					<p>
						<label>
							<input name="Group2" type="radio"/>
							<span>08:00 - 11:00 (0/70)</span>
						</label>
					</p>
				</p>
			</p>
			<p>
				<label>
					<input name="Group2" type="radio"/>
					<span>13:00 - 16:00 (0/70)</span>
				</label>
			</p>
			<p>
				<label for="28 August 2018">28 August 2018</label>
				<p>
					<label>
						<input name="Group2" type="radio"/>
						<span>08:00 - 11:00 (0/70)</span>
					</label>
				</p>
			</p>
			<p>
				<label>
					<input name="Group2" type="radio"/>
					<span>13:00 - 16:00 (0/70)</span>
				</label>
			</p>
			<p>
				<label for="29 August 2018">29 August 2018</label>
				<p>
					<label>
						<input name="Group2" type="radio"/>
						<span>08:00 - 11:00 (0/70)</span>
					</label>
				</p>
			</p>
			<p>
				<label>
					<input name="Group2" type="radio"/>
					<span>13:00 - 16:00 (0/70)</span>
				</label>
			</p>
			<p>
				<label for="30 August 2018">30 August 2018</label>
				<p>
					<label>
					<input name="Group2" type="radio"/>
					<span>08:00 - 11:00 (0/70)</span>
				</label>
				</p>
			</p>
			<p>
				<label>
					<input name="Group2" type="radio"/>
					<span>13:00 - 16:00 (0/70)</span>
				</label>
			</p>
			<p>
				<label for="31 August 2018">31 August 2018</label>
				<p>
					<label>
						<input name="Group2" type="radio"/>
						<span>08:00 - 11:00 (0/70)</span>
					</label>
				</p>
			</p>
			<p>
				<label>
					<input name="Group2" type="radio"/>
					<span>13:00 - 16:00 (0/70)</span>
				</label>
			</p>
			<script type="text/javascript">
				$(document).ready(function(){
					$('select').formSelect();
					$('.datepicker').datepicker({
						yearRange: [1995, 2018],
						format: "dd mmmm yyyy"
					});
				});
			</script>
			<div class="container">
			  <!-- Trigger the modal with a button -->
			  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Submit</button>

			  <!-- Modal -->
			  <div class="modal fade" id="myModal" role="dialog">
			    <div class="modal-dialog">
			    
			      <!-- Modal content-->
			      <div class="modal-content">
			        <div class="modal-header">
			          <button type="button" class="close" data-dismiss="modal">&times;</button>
			        </div>
			        <div class="modal-body">
			          <p align="center">
			            <script type="text/javascript">
			            	function validate(){
								var name = document.getElementsById("Name").value;
								document.getElementsById("name").innerHTML = name;
								var Student_id = document.getElementsById("student_id");
								document.getElementsById("student_id").innerHTML = Student_id;
								var major = document.getElementsById("Major");
								document.getElementsById("Major").innerHTML = major;
								var gender = document.getElementsByTagName("group1");
								document.getElementsById("group1").innerHTML = gender;
								var email = document.getElementsById("Email");
								document.getElementsById("Email").innerHTML = email;
								var line_ID = document.getElementsById("Line_ID");
								document.getElementsById("Line_ID").innerHTML = line_ID;
								var dob = document.getElementsById("DoB");
								document.getElementsById("DoB").innerHTML = dob;
								var phone = document.getElementsById("phone");
								document.getElementsById("phone").innerHTML = phone;
								var TOEFL = document.getElementsById("group2");
								document.getElementsById("group2").innerHTML = TOEFL;
							}
			            </script>
			            You will submit:
			            <br>
			            Name: <span id="name"></span>
			            <br>
			            NIM: <span id="student_id"></span>
			          </p>
			        </div>
			        <div class="modal-footer">
			          <p align="center">
			            <button style="background-color: #1fbaa2; color: white;" type="submit" class="btn btn-default" data-dismiss="modal"><b>Submit</b></button>
			            <button style="background-color: #f6841f; color: white;" type="button" class="btn btn-default" data-dismiss="modal"><b>Cancel</b></button>
			          </p>
			        </div>
			      </div>
			      
			    </div>
		  	</div>
	
		</div>
	</form>
	
</body>

</html>