<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

defined('BASEPATH') OR exit('No direct script access allowed');

class Registration_model extends CI_Model {

	public function __construct() 
	{
		parent::__construct();
	}

	/*INSERT into table registration_new_members*/
	public function insert_data_regist($obj)
	{
		//Query from database
		$queryString = "INSERT INTO `registration_new_members`(`name`, `nim`, `major`, `email`, `gender`, `price`, `line_id`, `dob`, `phone`, `ip`, `toefl_test_id`,`timestamp`,`batch`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		//Objects take from controller and passing them into model
		/*From batch 1 until 5 you must changes the parameter value manually*/
		$query = $this->db->query($queryString, array($obj->name, $obj->nim, $obj->major, $obj->email, $obj->gender, $obj->price, $obj->line_id, $obj->dob, $obj->phone, $obj->ip, $obj->toefl, date("Y-m-d H:i:s"),4));
		
		if($this->db->affected_rows()>0)
		{
			$queryString = "SELECT LAST_INSERT_ID() AS last_id";
			$query = $this->db->query($queryString);
			return $query->row(0)->last_id;
		}

		else
		{
			return false;
		}
	}

	//SELECT all data from table registration_new_members
	public function select_data_regist()
	{
		$queryString = "SELECT * FROM registration_new_members";
		$query = $this->db->query($queryString);
		$result = [];
		for ($i=0; $i < $query->num_rows(); $i++)
		{ 
			$temp = $query->row($i);
			array_push($result, $temp);
		}

		return $result;
		
	}
	//Change toefl_test_id  for the TOEFL shift that you want to select the data
	public function select_data_regist_per_shift()
	{
		$queryString = "SELECT * FROM `registration_new_members` WHERE toefl_test_id = 1";
		$query = $this->db->query($queryString);
		$result = [];
		for ($i=0; $i < $query->num_rows(); $i++)
		{ 
			$temp = $query->row($i);
			array_push($result, $temp);
		}

		return $result;
	}


	/*UPDATE data registration_new_members*/
	 /*public function update_new_members()
	{
		$queryString="";
	}*/
}