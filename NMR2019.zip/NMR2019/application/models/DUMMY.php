<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

defined('BASEPATH') OR exit('No direct script access allowed');

class Student_model extends CI_Model {

	public function __construct() 
	{
		parent::__construct();
	}

	public function foo()
	{
		$queryString = "SELECT * FROM `registrants` WHERE 1";
		$query = $this->db->query($queryString);
		$result = [];
		for ($i=0; $i < $query->num_rows(); $i++)
		{ 
			$temp = $query->row($i);
			array_push($result, $temp);
		}

		return $result;
	}

}