<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

defined('BASEPATH') OR exit('No direct script access allowed');

class Statistical_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
	}

	public function get_count_by_major()
	{
		$queryString = "SELECT major, count(nim) AS count_ FROM registration_new_members WHERE 1 GROUP BY major ORDER BY count_ DESC";
		$query = $this->db->query($queryString);

		$result = [];
		for($i = 0; $i < $query->num_rows(); $i++)
		{
			$temp = $query->row($i);
			array_push($result, $temp);
		}
		if($query->num_rows() > 0)
			return $result;
		else
			return false;
	}

	public function get_count_by_major_by_batch($batch)
	{
		$queryString = "SELECT major, count(nim) AS count_ FROM registration_new_members WHERE batch = ? GROUP BY major ORDER BY count_ DESC";
		$query = $this->db->query($queryString, [$batch]);

		$result = [];
		for($i = 0; $i < $query->num_rows(); $i++)
		{
			$temp = $query->row($i);
			array_push($result, $temp);
		}
		if($query->num_rows() > 0)
			return $result;
		else
			return false;
	}

	public function get_count_by_gender()
	{
		$queryString = "SELECT gender, count(nim) AS count FROM registration_new_members GROUP BY gender";
		$query = $this->db->query($queryString);

		$result = [];
		for($i = 0; $i < $query->num_rows(); $i++)
		{
			$temp = $query->row($i);
			array_push($result, $temp);
		}
		if($query->num_rows() > 0)
			return $result;
		else
			return false;
	}

	public function get_count_by_gender_by_batch($batch)
	{
		$queryString = "SELECT gender, count(nim) AS count FROM registration_new_members WHERE batch = ? AND nim LIKE '22%' GROUP BY gender";
		$query = $this->db->query($queryString, [$batch]);

		$result = [];
		for($i = 0; $i < $query->num_rows(); $i++)
		{
			$temp = $query->row($i);
			array_push($result, $temp);
		}
		if($query->num_rows() > 0)
			return $result;
		else
			return false;
	}

	public function get_count_by_price()
	{
		$queryString = "SELECT price, count(nim) AS count FROM registration_new_members GROUP BY price ORDER BY price desc";
		$query = $this->db->query($queryString);

		$result = [];
		for($i = 0; $i < $query->num_rows(); $i++)
		{
			$temp = $query->row($i);
			array_push($result, $temp);
		}
		if($query->num_rows() > 0)
			return $result;
		else
			return false;
	}

	public function get_count_by_time_each30()
	{
		$queryString = "SELECT batch, count(registration_new_members.nim) AS count, a.time_id AS time_id FROM registration_new_members, 
			(SELECT id, concat(substring(cast(timestamp AS integer), 9, 2), \":\", floor(substring(cast(timestamp AS integer), 11, 1)/3)*3, \"0\") AS time_id FROM `registration_new_members`) a 
			WHERE a.id = registration_new_members.id GROUP BY a.time_id, batch
		";
		$query = $this->db->query($queryString);

		$result = [];
		for($i = 0; $i < $query->num_rows(); $i++)
		{
			$temp = $query->row($i);
			$result[$temp->time_id][$temp->batch] = $temp;
		}
		if($query->num_rows() > 0)
			return $result;
		else
			return false;
	}

	public function get_sum_by_time_each30()
	{
		$queryString = "SELECT batch, sum(registration_new_members.price) AS sum, a.time_id AS time_id FROM registration_new_members, 
			(SELECT id, concat(substring(cast(timestamp AS integer), 9, 2), \":\", floor(substring(cast(timestamp AS integer), 11, 1)/3)*3, \"0\") AS time_id FROM `registration_new_members`) a 
			WHERE a.id = registration_new_members.id GROUP BY a.time_id, batch
		";
		$query = $this->db->query($queryString);

		$result = [];
		for($i = 0; $i < $query->num_rows(); $i++)
		{
			$temp = $query->row($i);
			$result[$temp->time_id][$temp->batch] = $temp;
		}
		if($query->num_rows() > 0)
			return $result;
		else
			return false;
	}

	public function get_count_by_time()
	{
		$queryString = "SELECT batch, count(registration_new_members.nim) AS count, a.time_id AS time_id FROM registration_new_members, 
			(SELECT id, concat(substring(cast(timestamp AS integer), 9, 2), \":\", floor(substring(cast(timestamp AS integer), 11, 1)/1)*1, \"0\") AS time_id FROM `registration_new_members`) a 
			WHERE a.id = registration_new_members.id GROUP BY a.time_id, batch
		";
		$query = $this->db->query($queryString);

		for($i = 9; $i <= 12; $i++)
		{
			for($j = 0; $j <= 5; $j+=1)
			{
				if($i == 9)
				{
					$result["0" . $i . ":" . $j . "0"][1] = 0;
					$result["0" . $i . ":" . $j . "0"][2] = 0;
					$result["0" . $i . ":" . $j . "0"][3] = 0;
					$result["0" . $i . ":" . $j . "0"][4] = 0;
					$result["0" . $i . ":" . $j . "0"][5] = 0;
				}

				else
				{
					$result[$i . ":" . $j . "0"][1] = 0;
					$result[$i . ":" . $j . "0"][2] = 0;
					$result[$i . ":" . $j . "0"][3] = 0;
					$result[$i . ":" . $j . "0"][4] = 0;
					$result[$i . ":" . $j . "0"][5] = 0;
				}
			}
		}
		for($i = 0; $i < $query->num_rows(); $i++)
		{
			$temp = $query->row($i);
			$result[$temp->time_id][$temp->batch] = $temp;
		}
		if($query->num_rows() > 0)
			return $result;
		else
			return false;
	}

	public function get_sum_by_time()
	{
		$queryString = "SELECT batch, sum(registration_new_members.price) AS sum, a.time_id AS time_id FROM registration_new_members, 
			(SELECT id, concat(substring(cast(timestamp AS integer), 9, 2), \":\", floor(substring(cast(timestamp AS integer), 11, 1)/1)*1, \"0\") AS time_id FROM `registration_new_members`) a 
			WHERE a.id = registration_new_members.id GROUP BY a.time_id, batch
		";
		$query = $this->db->query($queryString);

		for($i = 9; $i <= 12; $i++)
		{
			for($j = 0; $j <= 5; $j+=1)
			{
				if($i == 9)
				{
					$result["0" . $i . ":" . $j . "0"][1] = 0;
					$result["0" . $i . ":" . $j . "0"][2] = 0;
					$result["0" . $i . ":" . $j . "0"][3] = 0;
					$result["0" . $i . ":" . $j . "0"][4] = 0;
					$result["0" . $i . ":" . $j . "0"][5] = 0;
				}

				else
				{
					$result[$i . ":" . $j . "0"][1] = 0;
					$result[$i . ":" . $j . "0"][2] = 0;
					$result[$i . ":" . $j . "0"][3] = 0;
					$result[$i . ":" . $j . "0"][4] = 0;
					$result[$i . ":" . $j . "0"][5] = 0;
				}
			}
		}
		for($i = 0; $i < $query->num_rows(); $i++)
		{
			$temp = $query->row($i);
			$result[$temp->time_id][$temp->batch] = $temp;
		}
		if($query->num_rows() > 0)
			return $result;
		else
			return false;
	}

	public function get_count_by_batch()
	{
		$queryString = "SELECT batch, count(nim) AS count FROM `registration_new_members` WHERE 1 GROUP BY batch";
		$query = $this->db->query($queryString);

		for($i = 1; $i <= 5; $i++)
		{
			$result[$i] = new stdClass();
			$result[$i]->curr = 0;
			$result[$i]->pres5 = 0;
			$result[$i]->pres4 = 0;
		}
		for($i = 0; $i < $query->num_rows(); $i++)
		{
			// $result[$query->row($i)->batch] = new stdClass();
			$result[$query->row($i)->batch]->curr = $query->row($i)->count;
			// $result[$query->row($i)->batch]->pres5 = $query->row($i)->count;
		}
		$result[1]->pres5 = 105;
		$result[2]->pres5 = 77;
		$result[3]->pres5 = 51;
		$result[4]->pres5 = 118;
		$result[5]->pres5 = 177;

		$result[1]->pres4 = 69;
		$result[2]->pres4 = 80;
		$result[3]->pres4 = 57;
		$result[4]->pres4 = 111;
		$result[5]->pres4 = 49;
		return $result;
	}

	public function get_count_by_shift()
	{
		$queryString = "SELECT toefl_test_id AS shift, count(nim) AS count FROM `registration_new_members` WHERE 1 GROUP BY `toefl_test_id`";
		$query = $this->db->query($queryString);
		for($i = 1; $i <= 9; $i++)
			$result[$i] = 0;
		for($i = 0; $i < $query->num_rows(); $i++)
		{
			
			$result[$query->row($i)->shift] = $query->row($i)->count;
		}



		return $result;
	}

	public function get_count_by_zodiac()
	{
		$queryString = "
			SELECT t.zodiac as zodiac, count(dob) as count, zodiac_id
			FROM (
				SELECT x.dob, case  
					when x.dob between 321 and 420 then 'Aries'
					when x.dob between 421 and 521 then 'Taurus'
					when x.dob between 522 and 621 then 'Gemini'
					when x.dob between 622 and 722 then 'Cancer'
					when x.dob between 723 and 822 then 'Leo'
					when x.dob between 823 and 923 then 'Virgo'
					when x.dob between 924 and 1023 then 'Libra'
					when x.dob between 1024 and 1122 then 'Scorpius'
					when x.dob between 1123 and 1221 then 'Sagittarius'
					when x.dob between 1222 and 1231 then 'Capricornus'
					when x.dob between 101 and 120 then 'Capricornus'
					when x.dob between 121 and 219 then 'Aquarius'
					when x.dob between 220 and 320 then 'Pisces'
					else '20-99' end as zodiac, 
				case  
					when x.dob between 321 and 420 then '01'
					when x.dob between 421 and 521 then '02'
					when x.dob between 522 and 621 then '03'
					when x.dob between 622 and 722 then '04'
					when x.dob between 723 and 822 then '05'
					when x.dob between 823 and 923 then '06'
					when x.dob between 924 and 1023 then '07'
					when x.dob between 1024 and 1122 then '08'
					when x.dob between 1123 and 1221 then '09'
					when x.dob between 1222 and 1231 then '10'
					when x.dob between 101 and 120 then '10'
					when x.dob between 121 and 219 then '11'
					when x.dob between 220 and 320 then '12'
					else '20-99' end as zodiac_id
				FROM  (
					SELECT nim, cast(replace(substr(dob, 6), \"-\", \"\") AS integer) AS dob FROM `registration_new_members` WHERE 1) x) t
			GROUP BY t.zodiac ORDER BY zodiac_id
		";
		$query = $this->db->query($queryString);
		$result = [];
		for($i = 0; $i < $query->num_rows(); $i++)
		{
			array_push($result, $query->row($i));
		}
		return $result;
	}
}