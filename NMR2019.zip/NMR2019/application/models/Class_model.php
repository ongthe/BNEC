<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

defined('BASEPATH') OR exit('No direct script access allowed');

class Class_model extends CI_Model {

	public function __construct() 
	{
		parent::__construct();
	}

	public function insert_class($date)
	{
		$queryString = "INSERT INTO `class_schedule`(`date`) VALUES (?)";
		$query = $this->db->query($queryString,[$date]);
	}

	public function update_class($date, $id)
	{
		$queryString = "UPDATE `class_schedule` SET `date`= ? WHERE id = ?";
		$query = $this->db->query($queryString,[$date, $id]);
	}

	public function select_all_class()
	{
		$queryString = "SELECT * FROM `class_schedule` WHERE 1";
		$query = $this->db->query($queryString);
		$result = [];
		for ($i=0; $i < $query->num_rows(); $i++)
		{ 
			$temp = $query->row($i);
			array_push($result, $temp);
		}
		return $result;
	}

	public function get_total()
	{
		$queryString = "SELECT count(`registration_new_members`.`id` ) AS count FROM `registration_new_members` RIGHT JOIN `class_schedule` ON `registration_new_members`.`toefl_test_id` = `class_schedule`.`id` GROUP BY `class_schedule`.`id`";
		$query = $this->db->query($queryString);
		$result = [];
		for ($i=0; $i < $query->num_rows(); $i++)
		{ 
			$temp = $query->row($i);
			array_push($result, $temp);
		}
		return $result;
	}

}