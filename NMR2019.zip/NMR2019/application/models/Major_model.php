<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

defined('BASEPATH') OR exit('No direct script access allowed');

class Major_model extends CI_Model {

	public function __construct() 
	{
		parent::__construct();
	}

	public function insert_major($major, $major_short)
	{
		$queryString = "INSERT INTO `major`(`major`, `major_short`) VALUES (?,?)";
		$query = $this->db->query($queryString,[$major, $major_short]);
	}

	public function update_major($major, $major_short, $id)
	{
		$queryString = "UPDATE `major` SET `major`=?,`major_short`=? WHERE id = ?";
		$query = $this->db->query($queryString,[$major, $major_short, $id]);
	}

	public function select_all_major()
	{
		$queryString = "SELECT * FROM `major` ORDER BY major.major";
		$query = $this->db->query($queryString);
		$result = [];
		for ($i=0; $i < $query->num_rows(); $i++)
		{ 
			$temp = $query->row($i);
			array_push($result, $temp);
		}
		return $result;
	}

}