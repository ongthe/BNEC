<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		//kalau mau berhubungan database

		//template:
		$this->load->model("Model_name", "variable");

		//jalanin function
		$this->variable->function1($param1, $param2);

		//param function berupa object
		$obj = new stdClass();
		$obj->attr1 = $value1;
		$obj->attr2 = $value2;
		$this->variable->function2($obj);



		//untuk buka tampilan
		$this->load->view('welcome_message');

		//buka tampilan dengan data
		$this->load->view("view_name", [
			// => is = ----- $var_in_view = $value
			"var_in_view" => $value
		]);



		//buka tampilan dengan header
		$body = $this->load->view("content",  [ 
			//some data
		], true); //true = view masuk dalam variable
		$this->load->view("header", [
			"body" => $body
		], false); //false = view langsung ditampilkan



	}
	public function submit_data()
	{
		$name = $this->input->post("name");
		$this->input->post("nim");

		//flashdata
		$this->session->set_flashdata("name", $name);
		//let's say data salah
		redirect(base_url() . "Welcome", "refresh");

	}

	public function validasi()
	{
		$name = $this->input->post("name");
		if($name == null || strlen($name) == 0)
		{
			//false
		}

	}

	public function ambil_flash_data()
	{
		$name = $this->session->flashdata("name");
	}
}
