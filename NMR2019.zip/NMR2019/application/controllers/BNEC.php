<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BNEC extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	/*
	Controller secara umum(X)
		1. Load model
		2. Load helper
		3. Ambil input
		4. Validasi
		5. Jalankan function model
		6. Load view / Redirect

	Controller tampilan(selesai)
		1. Load model
		2. Jalankan function model
		3. load view

	Controller submit data
		1. Load model
		2. Ambil input
		3. Validasi
		4. jalankan function model
		5. Redirect
	*/


	public function index()
	{
		$this->load->view("home");
	}

	public function login()
	{
		$list = "";
		$ip = $this->input->post("ip");
		$name = $this->input->post("name");
		$ip_list = fopen("ip_list.txt", "r");
		while(!feof($ip_list))
		{
			// array_push($list, trim(fgets($ip_list)));
			$list = $list . trim(fgets($ip_list)) . "\n";
		}
		fclose($ip_list);
		$ip_list = fopen("ip_list.txt", "w");
		// array_push($list, $ip . "\n");
		$list = $list . $ip;
		fwrite($ip_list, $list);
		fclose($ip_list);

		$send = '{' .
			'"name"   : "", ' .
			'"nim"    : "", ' .
			'"major"  : "", ' .
			'"email"  : "", ' .
			'"gender" : "", ' .
			'"line_id": "", ' .
			'"dob"    : "", ' .
			'"phone"  : "", ' .
			'"shift"  : "", ' .
			'"price"  : ""},';

		$test = fopen($ip . ".txt", "w") or die("Unable to open file!");
		fwrite($test, $send);
		fclose($test);

		return redirect(base_url() . "BNEC", "refresh");
	}

	public function form($no)
	{
		$this->load->model("Major_model", "major");
		$major_query = $this->major->select_all_major();
		

		$price;
		switch ($no) {
			case 1:
				$price = 85000;
				break;

			case 3:
				$price = 75000;
				break;

			/*case 5:
			 	$price = 55000;
			 	break;*/

			case 0:
				$price = 65000;
				break;
			
			default:
				# code...
				break;
		}

		if($no == 0)
			$no = 1;

		$this->load->model("Class_model", "class");
		$class_query = $this->class->select_all_class();
		$count_query = $this->class->get_total();

		$body = $this->load->view("NMR_Registration",[
			"majors" => $major_query,
			"classes" => $class_query,
			"count" => $count_query,
			"datacount" => 1,
			"price" => $price
		], false);
	}	

	public function submit_data()
	{
		//================Load Model================
		$this->load->model("Major_model", "major");
		$this->load->model("Class_model", "class");

		//====================Pengambilan Data==================

		$obj = [];
		// for ($i=0; $i < $this->input->post("data_count"); $i++) { 
			$temp = new stdClass();
			$temp->name = $this->input->post("name");
			$temp->nim = $this->input->post("student_id");
			$temp->major = $this->input->post("major");
			$temp->email = $this->input->post("email");
			$temp->gender = $this->input->post("gender");
			$temp->line_id = $this->input->post("line_id");
			$temp->dob = date("Y-m-d", strtotime($this->input->post("d-dob") . 
				" " . 
				$this->input->post("m-dob") . 
				" " . 
				$this->input->post("y-dob")
			));
			$temp->phone = "" . $this->input->post("phone");
			$temp->toefl = $this->input->post("toefl");
			$temp->price = $this->input->post("price");
			$temp->ip = $this->input->post("file");
			// array_push($obj, $temp);
		// }

		$this->load->model("Registration_model", "regist");
		$this->regist->insert_data_regist($temp);

		$send = '{' .
			'"name"   : "", ' .
			'"nim"    : "", ' .
			'"major"  : "", ' .
			'"email"  : "", ' .
			'"gender" : "", ' .
			'"line_id": "", ' .
			'"dob"    : "", ' .
			'"phone"  : "", ' .
			'"shift"  : "", ' .
			'"price"  : ""},';

		$test = fopen($this->input->post("file") . ".txt", "w") or die("Unable to open file!");
		fwrite($test, $send);
		fclose($test);

		return redirect(base_url() . "/..");
	}
	//Refresh rate data every 500
	public function table($update_rate = 500)
	{
		$this->load->model("Registration_model", "regist");
		// $query = $this->regist->select_data_regist();
		$this->load->view("table", [
			// "data" => $query,
			"update_rate" => $update_rate
		], false);
	}
	//List have 2 parameter mode: toefl and batch
	public function lists($mode)
	{
		$this->load->model("Registration_model", "regist");
		if($mode == "toefl")
			$query = $this->regist->select_data_regist_per_shift();
		else if($mode == "batch")
			$query = $this->regist->select_data_regist();
		$this->load->view("table_static", [
			"data" => $query,
			"mode" => $mode
		], false);
	}

	public function req()
	{
		$this->load->model("Registration_model", "regist");
		$query = $this->regist->select_data_regist();

		//JSON contain class dan object 
		$result = '{ "member": [';
		foreach ($query as $key => $value) {
			//attribute
			$result = $result . '{' .
			'"no"     : "' . $value->id .            '", ' .
			'"name"   : "' . $value->name .          '", '.
			'"nim"    : "' . $value->nim .           '", ' .
			'"major"  : "' . $value->major .         '", ' .
			'"email"  : "' . $value->email .         '", ' .
			'"gender" : "' . $value->gender .        '", ' .
			'"price"  : "' . $value->price .         '", ' .
			'"line_id": "' . $value->line_id .       '", ' .
			'"dob"    : "' . $value->dob .           '", ' .
			'"phone"  : "' . $value->phone .         '", ' .
			'"toefl"  : "' . $value->toefl_test_id . '", ' .
			'"ip"     : "' . $value->ip . '", ' .
			'"batch"  : "' . $value->batch . '"},';
		}
		// echo count($query);
		if(count($query) > 0)
		{
			$result = substr($result, 0, strlen($result) - 1);
		}
		// {
		date_default_timezone_set("Asia/Jakarta");
			$result = $result . '], "date": "' . date("H:i:s") . '", "inc": ';
		// }

		$list = [];
		$ip_list = fopen("ip_list.txt", "r");
		while(!feof($ip_list))
		{
			array_push($list, trim(fgets($ip_list)));

		}
		fclose($ip_list);
		$members = "[";
		for($i = 0; $i < count($list); $i++)
		{
			$incomplete = fopen(explode("#", $list[$i])[0] . ".txt", "r");
			while(!feof($incomplete))
			{
				$string = fgets($incomplete);
				// $members = $members . $string;
				// echo $members . "<br><br>";
				// $members = $members . substr($string, 0, 1) . '"computer": "' . $list[$i] . '", ' . substr($string, 1);
				if(substr($string, 0, 1) == "{")
					$members = $members . substr($string, 0, 1) . '"computer": "' . explode(".", $list[$i])[3] . '", ' . substr($string, 1);
				// echo "a" . $string . "<br>";
			}
			fclose($incomplete);
		}
		$members = substr($members, 0, strlen($members) - 1) . "";
		$result = $result . $members . "]}";

		echo $result;
		// echo explode("#", $list[1])[0];
	}

	public function send()
	{
		$send = "";
		
		$send = $send . '{' .
		'"name"   : "' . $this->input->get("name")                              . '", ' .
		'"nim"    : "' . $this->input->get("nim")                               . '", ' .
		'"major"  : "' . $this->input->get("major")                             . '", ' .
		'"email"  : "' . $this->input->get("email")                             . '", ' .
		'"gender" : "' . $this->input->get("gender")                            . '", ' .
		'"line_id": "' . $this->input->get("line_id")                           . '", ' .
		'"dob"    : "' . date("Y-m-d", strtotime($this->input->get("dob")) )    . '", ' .
		// '"dob"    : "' . $this->input->get("dob")    . '", ' .
		'"phone"  : "' . $this->input->get("phone")                             . '", ' .
		'"shift"  : "' . $this->input->get("shift")                             . '", ' .
		'"price"  : "' . $this->input->get("price")                             . '"},';
		
		
		$test = fopen($this->input->get("file") . ".txt", "w") or die("Unable to open file!");
		fwrite($test, $send);
		fclose($test);
	}

	public function statistics($admin = 0)
	{
		$this->load->model("Statistical_model", "stat");
		$count_major = $this->stat->get_count_by_major();
		$count_gender = $this->stat->get_count_by_gender();
		$count_zodiac = $this->stat->get_count_by_zodiac();
		$count_price = $this->stat->get_count_by_price();
		$count_time = $this->stat->get_count_by_time_each30();
		$count_time_cumulative = $this->stat->get_count_by_time();

		$sum_time = $this->stat->get_sum_by_time_each30();
		$sum_time_cumulative = $this->stat->get_sum_by_time();

		$count_batch = $this->stat->get_count_by_batch();

		$count_major_batch = [];
		$count_gender_batch = [];

		for($i = 1; $i <= 5; $i++)
		{
			$count_major_batch[$i] = $this->stat->get_count_by_major_by_batch($i);
			$count_gender_batch[$i] = $this->stat->get_count_by_gender_by_batch($i);
		}

		$count_shift = $this->stat->get_count_by_shift();

		$this->load->view("statistics", [
			"admin" => $admin,
			"count_major" => $count_major,
			"count_gender" => $count_gender,
			"count_zodiac" => $count_zodiac,
			"count_price" => $count_price,
			"count_time" => $count_time,
			"count_time_cumulative" => $count_time_cumulative,
			"sum_time" => $sum_time,
			"sum_time_cumulative" => $sum_time_cumulative,
			"count_batch" => $count_batch,
			"count_major_batch" => $count_major_batch,
			"count_gender_batch" => $count_gender_batch,
			"count_shift" => $count_shift
		], false);
	}
}