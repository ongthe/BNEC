$(document).ready(function(){
	$(".name").change(function(e){

		$(this).val($(this).val().toLowerCase());
		$(this).val($(this).val().replace(/  /g," "));
		$(this).val($(this).val().replace(/^ /g,""));
		$(this).val($(this).val().replace(/ $/g,""));
		if($(this).val().search(/^[a-z]/) != -1)
		{
			$(this).val(
				$(this).val().slice(0, 1).toUpperCase() + 
				$(this).val().slice(1)
			);
		}
		
		// alert($(this).val().search(/ [a-z]/));
		var upper = $(this).val().search(/ [a-z]/)
		if(upper != -1)
		{
			$(this).val(
				$(this).val().slice(0, upper + 1) + 
				$(this).val().slice(upper + 1, upper + 2).toUpperCase() + 
				$(this).val().slice(upper + 2)
			);
			
		}

	});

	$(".nim").keyup(function(){
		$(this).val($(this).val().replace(/[^0-9]/g, ""));
	});

	$(".email").keyup(function(){
		$(this).val($(this).val().replace(/\,/g, ""));
		$(this).val($(this).val().replace(/\.\./g, "."));
		$(this).val($(this).val().replace(/@@/g, "@"));
		$(this).val($(this).val().replace(/^@/g, ""));
		$(this).val($(this).val().toLowerCase());
	});

	$(".phone").keyup(function() {

	// alert($("#phone").val().replace(/ - /g,"").length);
		$(this).val($(this).val().replace(/[a-zA-Z!@#$%^&*_]/g, ""));
		$(this).val($(this).val().replace(/  /g, " "));
		$(this).val($(this).val().replace(/^ /g, ""));
		var phoneVal;
		if($(this).val().search(/^0/) != -1)
		{
			phoneVal = $(this).val().replace(/ - /g, "");
		}
		else if($(this).val().search(/^\(\+62\) /) != -1)
		{
			phoneVal = $(this).val().slice(5).replace(/ - /g,"");
			// alert("a");
		}

		// var phoneVal = $("#phone").val().slice(1).replace(/ - /g,"");
		var phoneLength = phoneVal.length;

		if(phoneLength < 7)
		{
			$(this).val("(+62) " + phoneVal.slice(1));
		}
		else if(phoneLength < 9 && phoneLength > 6)
		{
			$(this).val("(+62) " + (phoneVal.slice(0,Math.ceil(phoneLength/2)) + " - " + phoneVal.slice(Math.ceil(phoneLength/2))).slice(1))
		}
		else if(phoneLength >= 9)
		{
			var string = "";
			for(var i = 1; i <= 3 ; i++)
			{
				string = string + phoneVal.slice(Math.ceil(phoneLength*(i-1)/3), Math.ceil(phoneLength*i/3));
				if(i != 3)
					string = string + " - ";
			}
			$(this).val("(+62) " + string.slice(1));
		}
	});
});

