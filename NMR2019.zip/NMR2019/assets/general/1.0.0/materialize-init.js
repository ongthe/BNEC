$(document).ready(function() {
	$("select").formSelect();

	$('.tap-target').tapTarget({
		onClose: function(){
			$("#not-found-2020").css({"opacity": "0"});
		},
		onOpen: function(){
			$("#not-found-2020").css({"opacity": "1"});

		}
	});
});