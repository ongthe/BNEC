-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 12 Feb 2019 pada 20.33
-- Versi server: 10.2.21-MariaDB
-- Versi PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `k5442245_neo2018`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `about_us`
--

CREATE TABLE `about_us` (
  `about_us_id` int(11) NOT NULL,
  `content` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `accommodation`
--

CREATE TABLE `accommodation` (
  `accommodation_id` int(11) NOT NULL,
  `hotel` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `competition`
--

CREATE TABLE `competition` (
  `competition_id` int(11) NOT NULL,
  `competition_name` varchar(33) NOT NULL,
  `competition_price` int(11) NOT NULL,
  `competition_early` int(11) NOT NULL,
  `competition_img` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `competition`
--

INSERT INTO `competition` (`competition_id`, `competition_name`, `competition_price`, `competition_early`, `competition_img`) VALUES
(1, 'Scrabble', 300000, 250000, 'scrabble.svg'),
(2, 'Storytelling', 350000, 300000, 'storytelling.svg'),
(4, 'Speech', 350000, 300000, 'speech.svg'),
(5, 'Newscasting', 350000, 300000, 'newscasting.svg'),
(6, 'Observer', 200000, 200000, 'observer.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `confirm`
--

CREATE TABLE `confirm` (
  `confirm_id` int(11) NOT NULL,
  `no_rek` varchar(12) NOT NULL,
  `atas_nama` varchar(90) NOT NULL,
  `nominal` int(11) NOT NULL,
  `transfer_date` date NOT NULL,
  `transaction_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `confirm`
--

INSERT INTO `confirm` (`confirm_id`, `no_rek`, `atas_nama`, `nominal`, `transfer_date`, `transaction_id`) VALUES
(27, 'zzza', 'za', 2, '0000-00-00', 4),
(32, 'Nurfaizah', 'BritAma', 350000, '0000-00-00', 42);

-- --------------------------------------------------------

--
-- Struktur dari tabel `confirm_people`
--

CREATE TABLE `confirm_people` (
  `confirm_people_id` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `people_name` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `confirm_people`
--

INSERT INTO `confirm_people` (`confirm_people_id`, `transaction_id`, `people_name`) VALUES
(1, 3, 'grace'),
(2, 16, 'grace'),
(3, 7, 'lia'),
(4, 10, 'lia'),
(5, 11, 'lia'),
(6, 8, 'lia'),
(7, 13, 'lia'),
(8, 12, 'lia'),
(9, 14, 'lia'),
(10, 15, 'lia'),
(11, 18, 'lia'),
(12, 19, 'lia'),
(13, 21, 'lia'),
(14, 22, 'lia'),
(15, 20, 'lia'),
(16, 26, 'lia'),
(17, 25, 'lia'),
(18, 29, 'lia'),
(19, 28, 'lia'),
(20, 27, 'lia'),
(21, 9, 'lia'),
(22, 23, 'lia'),
(23, 6, 'grace'),
(24, 30, 'grace'),
(25, 32, 'lia'),
(26, 33, 'lia'),
(27, 36, 'lia'),
(28, 40, 'lia'),
(29, 41, 'lia'),
(30, 37, 'lia'),
(31, 39, 'lia'),
(32, 44, 'lia'),
(33, 47, 'lia'),
(34, 48, 'lia'),
(35, 49, 'lia'),
(36, 50, 'lia'),
(37, 51, 'lia'),
(38, 52, 'lia'),
(39, 64, 'lia'),
(40, 65, 'lia'),
(41, 62, 'lia'),
(42, 63, 'lia'),
(43, 54, 'lia'),
(44, 46, 'lia'),
(45, 66, 'lia'),
(46, 68, 'Lia'),
(47, 69, 'Lia'),
(48, 72, 'Lia'),
(49, 71, 'Lia'),
(50, 45, 'Lia'),
(51, 70, 'Lia'),
(52, 73, 'Lia'),
(53, 75, 'Lia'),
(54, 78, 'Lia'),
(55, 77, 'Lia'),
(56, 76, 'Lia'),
(57, 81, 'Lia'),
(58, 82, 'Lia');

-- --------------------------------------------------------

--
-- Struktur dari tabel `contact`
--

CREATE TABLE `contact` (
  `contact_id` int(11) NOT NULL,
  `contact_name` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `subject` varchar(256) NOT NULL,
  `message` varchar(2048) NOT NULL,
  `replied` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `elimination`
--

CREATE TABLE `elimination` (
  `elimination_id` int(11) NOT NULL,
  `student_name` varchar(64) NOT NULL,
  `school_name` varchar(64) NOT NULL,
  `field` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `participants`
--

CREATE TABLE `participants` (
  `participant_id` int(11) NOT NULL,
  `shs_id` int(11) NOT NULL,
  `participant_name` varchar(64) NOT NULL,
  `participant_phone` varchar(16) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(1) NOT NULL,
  `participant_email` varchar(90) NOT NULL,
  `vegetarian` tinyint(1) DEFAULT NULL,
  `transaction_id` int(11) NOT NULL,
  `team` varchar(2) NOT NULL,
  `debater_numb` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `participants`
--

INSERT INTO `participants` (`participant_id`, `shs_id`, `participant_name`, `participant_phone`, `dob`, `gender`, `participant_email`, `vegetarian`, `transaction_id`, `team`, `debater_numb`) VALUES
(1, 13, 'Tokisaki Kurumi', '089125326134', '1999-11-13', 'F', 'kurumi@gmail.com', 1, 3, '', 0),
(3, 21, 'Muhammad Rafly Raihandy', '081293760598', '2002-02-05', 'M', 'raihandyrafly@gmail.com', NULL, 18, '', 0),
(4, 21, 'Ferlita Ananda Monica', '081351311950', '2003-07-21', 'F', 'caferon127@gmail.com', NULL, 20, '', 0),
(5, 21, 'Maria Catherina', '081347490373', '2002-04-30', 'F', 'mcthrna30@gmail.com', NULL, 19, '', 0),
(6, 21, 'Naila Permata Chair', '081250064576', '2002-04-09', 'F', 'nailaachair@gmail.com', NULL, 21, '', 0),
(7, 21, 'Rusninda Astuti', '081256298485', '2003-11-07', 'F', 'rusninda07@gmail.com', NULL, 22, '', 0),
(8, 21, 'Sutiati', '08557169421', '1967-12-14', 'F', 'rajasalmanbocah@gmail.com', 1, 23, '', 0),
(9, 25, 'Harry Darwis', '081287456106', '1996-12-02', 'M', 'harrydarwis@gmail.com', NULL, 32, '', 0),
(10, 25, 'Olivia Audrey ', '087888080896', '1996-08-08', 'F', 'oliviaaudreyy@gmail.com', NULL, 33, '', 0),
(11, 25, 'Kezia Valentchia', '081273574628', '2000-09-06', 'F', 'keziavalentchia@gmail.com', NULL, 36, '', 0),
(12, 16, 'Josephine Madeleine', '08129549429', '2002-01-04', 'F', 'josephine.madeleine@student.sph.ac.id', NULL, 14, '', 0),
(13, 29, 'Kevin Tanuwijaya', '081908854199', '1998-05-01', 'M', 'kevintanuwijaya98@gmail.com', NULL, 40, '', 0),
(14, 23, 'M Rafi Soemadidjaja', '081381600660', '2003-02-28', 'M', 'bagusguruku@gmail.com', NULL, 25, '', 0),
(15, 23, 'Ahmad Rafi Sagoro', '081381600660', '2002-05-29', 'M', 'bagusguruku@gmail.com', NULL, 28, '', 0),
(16, 23, 'Rozan Dzaky Johansyah', '081381600660', '2003-01-19', 'M', 'bagusguruku@gmail.com', NULL, 26, '', 0),
(17, 23, 'Arsyaddhia Edra Rustam', '081381600660', '2002-03-04', 'M', 'bagusguruku@gmail.com', NULL, 27, '', 0),
(18, 29, 'Cassius Hidayat', '085798998890', '1998-04-28', 'M', 'cassiushidayat@gmail.com', NULL, 41, '', 0),
(19, 28, 'Joni Rolis', '089611307530', '1992-07-24', 'M', 'jonirollis@gmail.com', NULL, 39, '', 0),
(20, 23, 'Fabio Rayhan Kurniawan', '081381600660', '2001-08-23', 'M', 'bagusguruku@gmail.com', NULL, 47, '', 0),
(21, 23, 'Bagus Rizky Pangestu', '081381600660', '1993-02-12', 'M', 'bagusguruku@gmail.com', NULL, 48, '', 0),
(22, 31, 'Yasmine Adzkia', '081310848526', '2003-03-11', 'F', 'nvmifoundme@gmail.com', NULL, 44, '', 0),
(23, 34, 'David Noah Lizal', '087873836108', '2000-09-27', 'M', 'davidnoahl27@gmail.com', NULL, 49, '', 0),
(24, 35, 'Melvin Hendronoto', '081284596786', '1999-01-06', 'M', 'melvin.hendronoto@student.umn.ac.id', NULL, 50, '', 0),
(25, 35, 'Muhammad Faiz Abdurrahman', '6281295672103', '2000-05-08', 'M', 'mfaizabd44@gmail.com', NULL, 51, '', 0),
(26, 35, 'Paramita Tanarya', '6285214901188', '2000-08-19', 'F', 'paramita.tan19@gmail.com', NULL, 52, '', 0),
(27, 16, 'Adrian Francis Irawan', '081934127721', '2002-12-18', 'M', 'adrian.irawan@student.sph.ac.id', NULL, 10, '', 0),
(28, 16, 'Nicolas Axel Likjono', '081919337744', '2003-07-15', 'M', 'nicolas.likjono@student.sph.ac.id', NULL, 7, '', 0),
(29, 16, 'Stephanie Sinaga', '081919337744', '1986-09-16', 'F', 'stephanie.sinaga@sph.ac.id', NULL, 9, '', 0),
(30, 16, 'Dhira Vidhea', '081316179958', '2002-08-17', 'F', 'dhira.vidhea@student.sph.ac.id', NULL, 11, '', 0),
(31, 16, 'Chisierra Gracia Yanusyallah Sihotang', '081282424343', '2003-01-31', 'F', 'chisierra.sihotang@student.sph.ac.id', NULL, 15, '', 0),
(32, 16, 'Charlize Forlani Nurmawan', '081919337744', '2001-08-21', 'F', 'charlize.nurmawan@student.sph.ac.id', NULL, 12, '', 0),
(33, 38, 'Fatih Darielma Gaizta', '081281813775', '2002-06-21', 'M', 'fdarielma25@gmail.com', NULL, 62, '', 0),
(34, 38, 'Hosia Josindra Saragih', '081315496082', '2002-08-02', 'M', 'hosia.saragih@gmail.com', NULL, 63, '', 0),
(35, 10, 'Tri Prasetyo', '081379523955', '2002-11-04', 'M', 'ecrisaka@yahoo.com', NULL, 46, '', 0),
(36, 10, 'Zulyaden', '081379523955', '2002-11-23', 'M', 'ecrisaka@yahoo.com', NULL, 66, '', 0),
(37, 16, 'Catherine Guswidi Putri', '087780804556', '2001-07-18', 'F', 'catherine.g.putri@student.sph.ac.id', NULL, 54, '', 0),
(38, 36, 'Anthonius Christian Zega', '087786600869', '2000-12-17', 'M', 'anthonius717@gmail.com', 1, 73, '', 0),
(39, 21, 'Syifa Awaliah Hamdiyani', '085388724128', '2002-03-14', 'F', 'syifaa1416@gmail.com', NULL, 64, '', 0),
(40, 21, 'Chella Defa Anjelina', '081250136172', '2001-10-28', 'F', 'chelladefaa@gmail.com', NULL, 65, '', 0),
(41, 40, 'Yahya Ahmet Guvercin', '08111023355', '2006-09-06', 'M', 'yahya.guvercin@sampoernaacademy.net', NULL, 76, '', 0),
(42, 40, 'Naira Saniya Nazara', '081219194514', '2006-09-19', 'F', 'kremetized@gmail.com', NULL, 78, '', 0),
(43, 40, 'Naira Saniya Nazara', '081219194514', '2006-09-19', 'F', 'kremetized@gmail.com', NULL, 78, '', 0),
(44, 40, 'Julian Nathaniel Patrick Simandjuntak', '0816777151', '2005-01-24', 'M', 'julian_simanjuntak@yahoo.com', NULL, 77, '', 0),
(45, 40, 'Jessica Alexandria Wahyudi', '087885106649', '2005-07-31', 'F', 'jessica.wahyudi@sampoernaacademy.net', NULL, 75, '', 0),
(46, 36, 'Asttian Pratama Herdiman', '082183490557', '1999-05-05', 'M', 'yuko0shimaa@gmail.com', 1, 81, '', 0),
(47, 28, 'Riki Hanafy', '089638787211', '1996-06-22', 'M', 'rikihanafy@gmail.com', NULL, 82, '', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `re_regist`
--

CREATE TABLE `re_regist` (
  `re_regist_id` int(11) NOT NULL,
  `participant_id` int(11) NOT NULL,
  `attend` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `rules`
--

CREATE TABLE `rules` (
  `rules_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `shs`
--

CREATE TABLE `shs` (
  `shs_id` int(11) NOT NULL,
  `shs_name` varchar(120) NOT NULL,
  `shs_address` varchar(240) NOT NULL,
  `shs_email` varchar(120) NOT NULL,
  `cp_name` varchar(64) NOT NULL,
  `cp_phone` varchar(16) NOT NULL,
  `password` varchar(48) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `shs`
--

INSERT INTO `shs` (`shs_id`, `shs_name`, `shs_address`, `shs_email`, `cp_name`, `cp_phone`, `password`) VALUES
(5, 'testing', 'anywhere', 'kirishima@kancolle.com', 'Kirishima', '081234567890', 'Wa2h/XFQMFBvhecqM4UVH.anreu6182tNrDFlEMoog.'),
(6, 'SMA pepen', 'pepen', 'pepen123@gmail.com', 'mrs pepen', '0812457877', 'vJm23H3Bbck.s5n9e30WsDhwQIyvLaQiWdcKpEltmx.'),
(7, 'dsa', 'ds\r\n\r\nds', 'asdfghjkl@asdfghjkl', 'ds', 'ds', '9DIkNuV23vfCOMFZDUSYZvSC2O/RVoQW7hh8RaErYWB'),
(8, 'binusbinus', 'binusbinus', 'binus@binus.binus', 'binus', 'binus', '2LmPz5cKVj56hN3Oa/Q853AL8h7eaBpbStciuHf4Y/7'),
(9, 'test', 'test', 'huhu@test.com', 'test', '081234567892', 'ngA4mcyLOA8k34uBFqA8v6ZAQYU1tK9aWiuEVauEbBA'),
(10, 'SMA N 1 SEMAKA', 'Jl alim ulama, pekon Karang rejo, kec. Semaka kab. Tanggamus Lampung', 'ecrisaka@yahoo.com', 'Mrandi', '081379523955', 'aT0tmTGP/o365xHUP9TmUVcHLxqCZA3vlMjO96ExYc2'),
(11, 'Stella Maris School', 'Vatican Cluster, Sektor 8A, Gading Serpong', 'arsenia.lotivo@stella-maris.sch.id', 'Arsenia Avila Lotivo', '085758784539', '1q9ah.qbAqrN.Vbqbg59EvpKo24jk3QLG4XfVDmNnu0'),
(12, 'SMA Kristen Tunas Harapan', 'Jln Pahlawan no 140 Bogor Selatan 16132', 'lestari.bernike@gmail.com', 'Tiurma Lestari', '081282822088', 'Y1kqgeLtoQnWH0jdkcAEwePs0dVkHS1vfe8e2VDdD49'),
(13, 'testing', 'testing', 'dhjsksks.bs@yahoo.com', 'testing', '0873738292', '/Pjaz0aL7qFOGg5D3A9UVJsDqHoxh2WOXz7Wk3wB2C9'),
(14, 'dsds', 'd', 'school.school@yahoo.com', 'qwerty', '08976476848', 'iRYF7Dm/fJl2yETfCN6t7zp/x0LVdWEHd3qzGcMg/sD'),
(15, 'Smpit As Syifa Boarding School Subang', 'Jl. Raya Subang - Bandung Km 12 Desa Tambakmekar Jalancagak Subang', 'smpit@assyifa-boardingschool.sch.id', 'Asbosch', '(0260) 471041', 'HKoBeb2w7RMX1OORcFyP62LsDfbMXvSaMMSg7Bmb0F4'),
(16, 'Sekolah Pelita Harapan Sentul City', 'Jl. Babakan Madang Sentul City, Kab. Bogor', 'stephanie.sinaga@sph.ac.id', 'Stephanie Sinaga', '081919337744', 'l7u6jnkqRJjhgyo0SCfESCu5AgAd4cH3r1pWYu0hPQ5'),
(17, 'UPH College', 'UPH College Building E - UPH Campus\r\nJl. MH Thamrin Boulevard 1100 Lippo Village \r\nTangerang 15811 Banten\r\n', 'timothy.tumutod@uphcollege.com', 'Timothy Tumutod', '082112026263', '607unaGdPad0rV0sb8xMeEZd3lkv/ljSwD/M75515i.'),
(18, 'SMAN 47 Jakarta ', 'Jl. Delman Utama I, RT.1/RW.11, Kby. Lama Utara, Kby. Lama, Selatan, Daerah Khusus Ibukota Jakarta 12240', 'info@smun47-jkt.sch.id', 'Khairunnisa8103@gmail.com ', '081380295952 ', 'kNTQP6LhFPcHrVvxHyYoDT8cdDmVw1eicEveGDk9ePA'),
(19, 'Smpit As Syifa Boarding School Subang', 'Jl.raya Subang -Bandung km 12 Desa Tambakmekar jalan cagak Subang', 'smpit@assyifa-boardingschool.sch.id', 'Asbosch', '(0260) 471046', 'HKoBeb2w7RMX1OORcFyP62LsDfbMXvSaMMSg7Bmb0F4'),
(20, 'SMAN 3 SAMARINDA', 'Jl. Ir. H. Juanda No.20, Air Hitam, Samarinda Ulu, Kota Samarinda, Kalimantan Timur 75243', 'sea.samarinda@gmail.com', 'Sutiati', '08557169421', 'A7Tq1Demir1QQT3MPoKundeszDmhdb87BML6KCfY4P5'),
(21, 'SMAN 3 SAMARINDA', 'Jl. Ir. H. Juanda No.20, Air Hitam, Samarinda Ulu, Kota Samarinda, Kalimantan Timur 75243', 'sea.samarinda@gmail.com', 'Sutiati', '08557169421', 'U0avDGFcPTT43hAsT0lkZC4YDnSviyiL5wzwpk1s/s0'),
(22, 'SMAN 3 SAMARINDA', 'Jl. Ir. H. Juanda No.20, Air Hitam, Samarinda Ulu, Kota Samarinda, Kalimantan Timur 75243', 'sea.samarinda@gmail.com', 'Sutiati', '08557169421', 'U0avDGFcPTT43hAsT0lkZC4YDnSviyiL5wzwpk1s/s0'),
(23, 'FIWA (Fitrah Islamic World Academy)', 'Jl. H. Miing No.67, Karihkil, Ciseeng, Bogor, Jawa Barat 16120', 'bagusguruku@gmail.com', 'Bagus Pangestu', '081381600660', 'R.C8WZTfM14IR.OyB.4r30ax./guBeZFLstQ7Fn5ga4'),
(24, 'Stella Maris School', 'Vatican Cluster Sektor 8A Gading Serpong, Tangerang', 'arsenia.lotivo@stella-maris.sch.id', 'Arsenia Avila Lotivo', '085758784539', '1q9ah.qbAqrN.Vbqbg59EvpKo24jk3QLG4XfVDmNnu0'),
(25, 'Universitas Tarumanagara', 'Jl. Letjen S. Parman No.1, RT.11/RW.1, Tanjung Duren Utara, Grogol petamburan, RT.11/RW.1, Tj. Duren Utara, Grogol petamburan, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11470', 'shabirazsy@gmail.com', 'Shabira Zasya ', '081632281173', 'WMtH7J/r.FHdj/8nxM5pwDr.Itlw.9OIqIjYD99mZA2'),
(26, 'SMA NEGERI 6 SURABAYA', 'Jl. Gubernur Suryo no.11 Surabaya, Jawa Timur', 'vyo.p.trivia@gmail.com', 'Vyo Putri Trivia', '081216549046', 'BshcVsjCSkpINGJ5EG6D77wkJENvVlIJc56MZ5i2X9B'),
(27, 'SMAN 3 TANGERANG', 'Jalan Kyai Haji Hasyim Ashari No.6, Karang Tengah, Kota Tangerang, Banten 15151', 'sman3tgr@yahoo.com', 'Veronica Endang Martuti', '081382567090', 'MuS.HqtIh0Mw3WdA01SuYTDoOPe9LLQm7kFXoprRJS1'),
(28, 'Syarif Hidayatullah State Islamic University Jakarta', 'Jl. Ir. H. Djuanda No.95, Cemp. Putih, Ciputat, Kota Tangerang Selatan, Banten 15412', 'humas@uinjkt.ac.id', 'Joni Rolis', '089611307530', '4xbUYIcR.ArD.PJQmz9tUe7vT5DwyxYJ9czIL/kymk.'),
(29, 'Unika Atma Jaya', 'Jl. Jend. Sudirman No.51, RT.5/RW.4, Karet Semanggi, Kecamatan Setiabudi, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12930', 'pbiuaj@atmajaya.ac.id', 'Tia Xenia', '085729795840', 'xtr6wlTn6OOGQzZ7OxXefaDIRnvlMYVaODU2.IgYYYA'),
(30, 'SMA Negeri 1 Tangerang', 'Jl. Daan Mogot No.50, Sukarasa, Kec. Tangerang, Kota Tangerang, Banten 15111', 'smanitra_tangerang@yahoo.com', 'Fatih Darielma', '081281813775', 'mZJ1Gi3ZVYDINJiyY04JLgi6zveQSFiKYmxxVTbHZj8'),
(31, 'SMAN 3 Tangerang', 'Jl. K.H. Hasyim Ashari No 6, Karang Tengah, Tangerang', 'sman3tangerang@gmail.com', 'Yasmine Adzkia', '081310848526', 'L1nL7OfNSbv1NXiRxPwsGlDNVp2LyTUj1uxtPDaiFbD'),
(32, 'Telkom University', 'Jl. Telekomunikasi no.1, Bandung', 'annisahumairani@outlook.com', 'Annisa Humairani', '087779295584', 'pa98bGIaFH6P5RQIvwpDMpTC/UcVSR0AjZ2t.Scfxl3'),
(33, 'SMA IIHS (International Islamic High School)', 'Palma One, Jl. Hr. Rasuna Said No.4th floor, RT.8/RW.4, Kuningan Tim., Setia Budi, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12950', 'candra.dwiirawan@iiec-edu.com', 'Candra Dwi Irawan', '085655546282', 'rGoO7o8zaVGN7YHBpbz1s75o/FHV567dsRwk5u0EEV6'),
(34, 'Sekolah Tinggi Pariwisata Trisakti', 'Tanah Kusir, Jl. IKPN Bintaro No.1, RT.4/RW.10, Bintaro, Pesanggrahan, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12330', 'Kemahasiswaan@stptrisakti.ac.id', 'David Noah Lizal', '087873836108', 'PFaobynfOZK5I6rZXSk0DUt3ceOJLr9zZVl7LsStDk7'),
(35, 'Universitas Multimedia Nusantara', 'Jl. Scientia Boulevard, Gading Serpong, Tangerang, Banten-15811 Indonesia', 'melvin.hendronoto@student.umn.ac.id', 'Melvin Hendronoto', '081284596786', 'B0.Q3HAzPidta7Ea3xhdc5vDlmD12qHz52LIzEbwx.A'),
(36, 'Universitas Mercu Buana', 'Jl. Meruya Selatan No.1, RT.4/RW.1, Meruya Sel., Kembangan, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11650', 'adeline.raphani@gmail.com', 'Adeline ', '081318823129', '/Fat0dc2cfeW4d7HDbsN9ImdFePISnFdR7LZv.h.3.9'),
(37, 'Universitas Pelita Harapan College', 'Jl. MH Thamrin Boulevard 1100 Lippo Village, Tangerang 15811', 'erika.rodriguez@uphcollege.com', 'Erika Rodriguez', '087786484543', 'tvOWoyk1JCYyIAjxcXswF.a9pohaU08K7FGp60ClK/0'),
(38, 'SMA Negeri 1 Tangerang', 'Jl. Daan Mogot No.50, Sukarasa, Kec. Tangerang, Kota Tangerang, Banten 15111', 'fdarielma25@gmail.com', 'Fatih Darielma', '081281813775', 'mZJ1Gi3ZVYDINJiyY04JLgi6zveQSFiKYmxxVTbHZj8'),
(39, 'SMP negeri 19 serpong', 'ciater', 'irapuspitasari84@gmail.com', 'syifa', '081312925890', 'EAVXRMDS8eBa4YiyLJZyiBwYG4xuHJWv/KqcKIvno8D'),
(40, 'Sampoerna Academy, L\'Avenue campus', 'L\'Avenue Office Tower, jl. Raya Pasar Minggu kav.16, Pancoran, Jakarta Selatan.', 'azamatdzh@gmail.com', 'Azamat Dzhumanazarov', '08111023355', 'uoWcGghXOTjntecyg8gZMVhhuIbn01NFht/4pZ6wm01'),
(41, 'Universitas Mercu Buana', 'Jl. Meruya Selatan No.1, RT.4/RW.1, Meruya Sel., Kembangan, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11650', 'yuko0shimaa@gmail.com', 'Asttian Pratama Herdiman', '082183490557', '.oIVcb5JXmTlYpAXE.EDrn4cwAmRH02SVX7DfdC9UR/');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL,
  `transaction_date` date NOT NULL,
  `shs_id` int(11) NOT NULL,
  `competition_id` tinyint(4) NOT NULL,
  `status` varchar(24) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `transaction_date`, `shs_id`, `competition_id`, `status`) VALUES
(1, '2018-10-03', 5, 1, 'regisField'),
(2, '2018-10-03', 8, 1, 'regisField'),
(3, '2018-10-18', 13, 1, 'ready'),
(4, '2018-10-24', 14, 2, 'Confirm'),
(5, '2018-10-29', 14, 1, 'regisField'),
(6, '2018-10-29', 13, 1, 'ready'),
(7, '2018-10-30', 16, 2, 'ready'),
(8, '2018-10-31', 16, 3, 'registParticipant'),
(9, '2018-10-31', 16, 6, 'ready'),
(10, '2018-10-31', 16, 2, 'ready'),
(11, '2018-10-31', 16, 2, 'ready'),
(12, '2018-10-31', 16, 4, 'ready'),
(13, '2018-10-31', 16, 3, 'registParticipant'),
(14, '2018-10-31', 16, 5, 'ready'),
(15, '2018-10-31', 16, 5, 'ready'),
(16, '2018-11-02', 5, 6, 'registParticipant'),
(17, '2018-11-04', 15, 1, 'regisField'),
(18, '2018-11-07', 21, 1, 'ready'),
(19, '2018-11-07', 21, 4, 'ready'),
(20, '2018-11-07', 21, 5, 'ready'),
(21, '2018-11-07', 21, 4, 'ready'),
(22, '2018-11-07', 21, 4, 'ready'),
(23, '2018-11-07', 21, 6, 'ready'),
(24, '2018-11-08', 23, 1, 'regisField'),
(25, '2018-11-08', 23, 1, 'ready'),
(26, '2018-11-08', 23, 4, 'ready'),
(27, '2018-11-08', 23, 4, 'ready'),
(28, '2018-11-08', 23, 2, 'ready'),
(29, '2018-11-08', 23, 2, 'registParticipant'),
(30, '2018-11-10', 13, 1, 'registParticipant'),
(31, '2018-11-10', 13, 6, 'regisField'),
(32, '2018-11-10', 25, 5, 'ready'),
(33, '2018-11-12', 25, 4, 'ready'),
(34, '2018-11-12', 14, 2, 'regisField'),
(35, '2018-11-12', 14, 3, 'regisField'),
(36, '2018-11-12', 25, 4, 'ready'),
(37, '2018-11-13', 23, 4, 'registParticipant'),
(38, '2018-11-13', 27, 1, 'regisField'),
(39, '2018-11-14', 28, 1, 'ready'),
(40, '2018-11-14', 29, 1, 'ready'),
(41, '2018-11-14', 29, 1, 'ready'),
(42, '2018-11-15', 27, 5, 'Confirm'),
(43, '2018-11-15', 30, 1, 'regisField'),
(44, '2018-11-15', 31, 5, 'ready'),
(45, '2018-11-16', 32, 4, 'registParticipant'),
(46, '2018-11-16', 10, 1, 'ready'),
(47, '2018-11-16', 23, 5, 'ready'),
(48, '2018-11-16', 23, 6, 'ready'),
(49, '2018-11-16', 34, 4, 'ready'),
(50, '2018-11-16', 35, 1, 'ready'),
(51, '2018-11-16', 35, 1, 'ready'),
(52, '2018-11-16', 35, 1, 'ready'),
(53, '2018-11-16', 30, 1, 'regisField'),
(54, '2018-11-16', 16, 5, 'ready'),
(55, '2018-11-16', 33, 4, 'regisField'),
(56, '2018-11-16', 33, 4, 'regisField'),
(57, '2018-11-16', 33, 6, 'regisField'),
(58, '2018-11-16', 38, 1, 'regisField'),
(59, '2018-11-16', 38, 1, 'regisField'),
(60, '2018-11-16', 38, 1, 'regisField'),
(61, '2018-11-16', 36, 4, 'regisField'),
(62, '2018-11-16', 38, 1, 'ready'),
(63, '2018-11-16', 38, 1, 'ready'),
(64, '2018-11-16', 21, 2, 'ready'),
(65, '2018-11-16', 21, 5, 'ready'),
(66, '2018-11-16', 10, 1, 'ready'),
(67, '2018-11-18', 32, 1, 'regisField'),
(68, '2018-11-18', 32, 1, 'registParticipant'),
(69, '2018-11-18', 32, 2, 'registParticipant'),
(70, '2018-11-18', 32, 2, 'registParticipant'),
(71, '2018-11-18', 32, 5, 'registParticipant'),
(72, '2018-11-18', 32, 5, 'registParticipant'),
(73, '2018-11-18', 36, 4, 'ready'),
(74, '2018-11-19', 13, 4, 'regisField'),
(75, '2018-11-19', 40, 5, 'ready'),
(76, '2018-11-19', 40, 2, 'ready'),
(77, '2018-11-19', 40, 2, 'ready'),
(78, '2018-11-19', 40, 2, 'ready'),
(79, '2018-11-20', 41, 1, 'regisField'),
(80, '2018-11-20', 41, 1, 'regisField'),
(81, '2018-11-20', 36, 1, 'ready'),
(82, '2018-11-20', 28, 1, 'ready'),
(83, '2018-11-20', 28, 1, 'regisField'),
(84, '2018-11-20', 28, 1, 'regisField');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `about_us`
--
ALTER TABLE `about_us`
  ADD PRIMARY KEY (`about_us_id`);

--
-- Indeks untuk tabel `accommodation`
--
ALTER TABLE `accommodation`
  ADD PRIMARY KEY (`accommodation_id`);

--
-- Indeks untuk tabel `competition`
--
ALTER TABLE `competition`
  ADD PRIMARY KEY (`competition_id`);

--
-- Indeks untuk tabel `confirm`
--
ALTER TABLE `confirm`
  ADD PRIMARY KEY (`confirm_id`);

--
-- Indeks untuk tabel `confirm_people`
--
ALTER TABLE `confirm_people`
  ADD PRIMARY KEY (`confirm_people_id`);

--
-- Indeks untuk tabel `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indeks untuk tabel `elimination`
--
ALTER TABLE `elimination`
  ADD PRIMARY KEY (`elimination_id`);

--
-- Indeks untuk tabel `participants`
--
ALTER TABLE `participants`
  ADD PRIMARY KEY (`participant_id`);

--
-- Indeks untuk tabel `re_regist`
--
ALTER TABLE `re_regist`
  ADD PRIMARY KEY (`re_regist_id`);

--
-- Indeks untuk tabel `shs`
--
ALTER TABLE `shs`
  ADD PRIMARY KEY (`shs_id`);

--
-- Indeks untuk tabel `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `competition`
--
ALTER TABLE `competition`
  MODIFY `competition_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `confirm`
--
ALTER TABLE `confirm`
  MODIFY `confirm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT untuk tabel `confirm_people`
--
ALTER TABLE `confirm_people`
  MODIFY `confirm_people_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT untuk tabel `participants`
--
ALTER TABLE `participants`
  MODIFY `participant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT untuk tabel `shs`
--
ALTER TABLE `shs`
  MODIFY `shs_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT untuk tabel `transaction`
--
ALTER TABLE `transaction`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
