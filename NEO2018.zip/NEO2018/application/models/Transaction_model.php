<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

defined('BASEPATH') OR exit('No direct script access allowed');

class Transaction_model extends CI_Model {

	function __construct() 
	{
		parent::__construct();
	}
/*
	function getTransactionNumber(){	
		$temp = new stdClass();	
		$queryString = "SELECT IDTransaksi FROM transaksi ORDER BY IDTransaksi DESC LIMIT 1 ";
		$query = $this->db->query($queryString);
		$row = $query->row();
		if (isset($row))
		{return $row->IDTransaksi;}
		else{return 0; }
	}*/
	
	function addTransaction($shs_id,$field_id){
		$queryString = "INSERT INTO transaction VALUES (null,CURRENT_TIMESTAMP,?,?,'regisField')";
		$query = $this->db->query($queryString, [$shs_id, $field_id]);
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

	function confirm($transaction_id, $no_rek, $atas_nama, $nominal, $transfer_date){
		$queryString = " UPDATE transaction 
						SET status = 'Confirm'
						WHERE transaction_id = ? ";
		$query = $this->db->query($queryString,array($transaction_id));

		$queryString2 = "INSERT INTO confirm VALUES (null, ?, ?, ?, ?, ?)";
		$query2 = $this->db->query($queryString2,array($no_rek, $atas_nama, $nominal, $transfer_date, $transaction_id));

		return true;
	}

	function getConfirm($transaction_id)
	{
		$result = array();
		$queryString = "SELECT * FROM transaction join confirm on transaction.transaction_id = confirm.transaction_id WHERE confirm.transaction_id = ?";
		$query = $this->db->query($queryString,array($transaction_id));
		for($i=0; $i < $query->num_rows(); $i++)
		{
			$temp = new stdClass();
			/*$temp->no_rek = $query->row($i)->no_rek;
			$temp->atas_nama = $query->row($i)->atas_nama;
			$temp->nominal = $query->row($i)->nominal;
			$temp->transfer_date = $query->row($i)->transfer_date;*/
			$temp= $query->row($i);
			array_push($result, $temp);
		}
		return $result;
	}

	function getTransByShs($id){
		$result = [];
		$queryString = "SELECT `transaction`.`transaction_id`, transaction_date, `transaction`.`competition_id` , competition_name, competition_price, participant_id, status FROM `transaction` join competition ON transaction.competition_id = competition.competition_id LEFT JOIN participants ON transaction.transaction_id = participants.transaction_id WHERE `transaction`.`shs_id` = ? ORDER BY transaction.transaction_id";
		$query = $this->db->query($queryString, [$id]);
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new stdClass();
			$temp=$query->row($i);
			array_push($result, $temp);
		}
		return $result;
	}
	function getTransByShsNotConfirm($id){
		$result = array();
		$queryString = "SELECT * FROM transaction join competition on transaction.competition_id = competition.competition_id WHERE shs_id=? AND status='regisField'";
		$query = $this->db->query($queryString, [$id]);
		for($i=0;$i<$query->num_rows();$i++){
			$temp = new stdClass();
			$temp=$query->row($i);
			array_push($result, $temp);
		}
		return $result;
	}
	function getAllConfirm(){
		$result = array();
		$queryString = "SELECT shs_name, cp_name, cp_phone,transfer_date, no_rek, atas_nama, nominal, transaction.transaction_id AS transaction_id, competition_name, competition_price FROM confirm JOIN transaction on transaction.transaction_id = confirm.transaction_id join shs on shs.shs_id = transaction.shs_id join competition on competition.competition_id = transaction.competition_id WHERE status='confirm' ORDER BY confirm.confirm_id";
		$query = $this->db->query($queryString);
		for($i=0; $i<$query->num_rows(); $i++)
		{
			$temp = new stdClass();
			/*$temp->shs_name = $query->row($i)->shs_name;
            $temp->cp_name = $query->row($i)->cp_name;
            $temp->cp_phone = $query->row($i)->cp_phone;
			$temp->transfer_date = $query->row($i)->transfer_date;
			$temp->no_rek = $query->row($i)->no_rek;
			$temp->atas_nama = $query->row($i)->atas_nama;
			$temp->nominal = $query->row($i)->nominal;
			$temp->transaction_id =$query->row($i)->transaction_id;
            $temp->competition_name = $query->row($i)->competition_name;
			$temp->competition_price =$query->row($i)->competition_price;*/
			$temp=$query->row($i);
			array_push($result, $temp);
		}
		return $result;
	}
	function adminConfirm($transaction_id,$confirm_people){
		$queryString = "UPDATE transaction SET status='registParticipant' WHERE transaction_id=?";
		$query = $this->db->query($queryString,array($transaction_id));
		if($this->db->affected_rows() > 0){
			$queryString = "DELETE FROM confirm WHERE transaction_id=?";
			$query = $this->db->query($queryString,array($transaction_id));
			if($this->db->affected_rows() > 0){
				$queryString="INSERT INTO confirm_people VALUES(null,?,?)";
				$query=$this->db->query($queryString,array($transaction_id,$confirm_people));
				if($this->db->affected_rows() > 0){
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
}