<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

defined('BASEPATH') OR exit('No direct script access allowed');

class Participant_model extends CI_Model {

	function __construct() 
	{
		parent::__construct();
	}

	function addParticipant($obj){
		$queryString="INSERT INTO participants(`shs_id`,`participant_name`, `participant_phone`, `dob`, `gender`, `participant_email`, `vegetarian`, `transaction_id`, `team`, `debater_numb`) VALUES (?,?,?,?,?,?,?,?,?,?)";
		$query=$this->db->query($queryString,array($obj->shs_id, $obj->participant_name, $obj->participant_phone, $obj->dob, $obj->gender, $obj->participant_email, $obj->vegetarian, $obj->transaction_id, $obj->team, $obj->debater_numb));
		

		if($this->db->affected_rows() > 0){
			//if already regist become 'ready'
			$queryString = "UPDATE transaction SET status = 'ready' WHERE transaction_id = ?";
			$query = $this->db->query($queryString,array($obj->transaction_id));
			if($this->db->affected_rows() > 0){
				return true;
			}
			else{
				return false;
			}
		}else{
			return false;
		}
	}

	/*function addParticipantDB1($shs_id, $fullNameDB1, $genderDB1, $phoneDB1, $dobDB1, $emailDB1, $vegetarianDB1, $IDTrans, $teamName){
		if($vegetarianDB1 != 1) $vegetarianDB1 = 0;
		$queryString = "INSERT INTO participants VALUES (?,?,?,?,?,?,?,?,?)";
		$query = $this->db->query($queryString,array($shs_id, $fullNameDB1,$genderDB1, $phoneDB1, $dobDB1, $emailDB1, $vegetarianDB1, $IDTrans, $teamName , 1));
		if($this->db->affected_rows() > 0){
			$queryString = "UPDATE transaction SET status = 'ready' WHERE transaction_id = ?";
			$query = $this->db->query($queryString,array($IDTrans));
			if($this->db->affected_rows() > 0){
				return true;
			}
			else{
				return false;
			}
		}else{
			return false;
		}
	}*/

	function addMessage($obj){
		$queryString = "INSERT INTO contact(`contact_name`, `email`, `subject`, `message`, `replied`) VALUES (?,?,?,?,?)";
		$query = $this->db->query($queryString,array($obj->contact_name, $obj->email, $obj->subject, $obj->message, $obj->replied));
		// $query = $this->db->query($queryString,array($data['contact_name'],$data['email'],$data['subject'],$data['message']));
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}

	function getParticipantByField($id){
		$queryString = "SELECT * FROM participants WHERE transaction_id=?";
		$query = $this->db->query($queryString,array($id));
		$temp = new stdClass();
		/*$temp->participant_id = $query->row($i)->participant_id;
		$temp->participant_name = $query->row($i)->participant_name;
		$temp->participant_phone =$query->row($i)->participant_phone;			
		$temp->participant_email = $query->row($i)->participant_email;
		$temp->dob = $query->row($i)->dob;
		$temp->gender =$query->row($i)->gender;	
		$temp->vegetarian = $query->row($i)->vegetarian;
		$temp->transaction_id = $query->row($i)->transaction_id;
		$temp->team =$query->row($i)->team;*/
		$temp=$query->row(0);	
		return $temp;
	}

	function getDebateParticipant($id){
		$result = array();
		$queryString = "SELECT * FROM participants WHERE transaction_id=?";
		$query = $this->db->query($queryString,array($id));
		for($i = 0; $i < $query->num_rows(); $i++)
		{
			$temp = new stdClass();
			/*$temp->participant_id = $query->row($i)->participant_id;
			$temp->participant_name = $query->row($i)->participant_name;
			$temp->participant_phone =$query->row($i)->participant_phone;			
			$temp->participant_email = $query->row($i)->participant_email;
			$temp->dob = $query->row($i)->dob;
			$temp->gender =$query->row($i)->gender;	
			$temp->vegetarian = $query->row($i)->vegetarian;
			$temp->transaction_id = $query->row($i)->transaction_id;
			$temp->team =$query->row($i)->team;*/
			$temp = $query->row($i);
			array_push($result, $temp);
		}
		return $result;
	}

	function editParticipant($participant_name, $participant_phone, $participant_email ,$dob, $gender , $vegetarian, $transaction_id){
		$queryString = "UPDATE participants SET participant_name=?,participant_phone=?,participant_email=?,dob=?,gender=?,vegetarian=? WHERE transaction_id=?";
		$query = $this->db->query($queryString,array($participant_name, $participant_phone, $participant_email ,$dob, $gender , $vegetarian, $transaction_id));

		if($this->db->affected_rows() > 0){
			return true;			
		}else{
		 	return false;
		 }
	}

	/*function editParticipantDB1($fullNameDB, $genderDB, $phoneDB, $dobDB, $emailDB, $vegetarianDB, $IDTrans, $teamName){
		$queryString = "UPDATE participants SET participant_name=?,participant_phone=?,participant_email=?,dob=?,gender=?,vegetarian=? WHERE transaction_id=?";
		$query = $this->db->query($queryString,array($participant_name, $participant_phone, $participant_email ,$dob, $gender , $vegetarian, $transaction_id,1));

		if($this->db->affected_rows() > 0){
			return true;			
		}else{
		 	return false;
		 }
	}*/

	function getAllParticipantByShs(){
		$result = array();
		$queryString = "SELECT participant_id, shs_name, participant_name, participant_phone, dob, gender, participant_email, vegetarian, transaction_id, team, competition_name FROM participants join transaction on transaction_id join competition on competition_id join shs on shs_id";
		$query = $this->db->query($queryString);
		for($i=0; $i<$query->num_rows(); $i++)
		{
			$temp = new stdClass();
			/*$temp->participant_id = $query->row($i)->participant_id;
            $temp->shs_name =$query->row($i)->shs_name;
			$temp->participant_name = $query->row($i)->participant_name;
			$temp->participant_phone =$query->row($i)->participant_phone;			
			$temp->participant_email = $query->row($i)->participant_email;
			$temp->dob = $query->row($i)->dob;
			$temp->gender =$query->row($i)->gender;	
			$temp->vegetarian = $query->row($i)->vegetarian;
			$temp->transaction_id = $query->row($i)->transaction_id;
			$temp->team =$query->row($i)->team;
			$temp->competition_name =$query->row($i)->competition_name;*/
			$temp=$query->row($i);
			array_push($result, $temp);
		}
		return $result;
	}

	function getAllParticipant(){
		$result = array();
		$queryString = "SELECT participant_id, shs_name, participant_name, participant_phone, dob, gender, participant_email, vegetarian, transaction_id, team, competition_name, attend FROM participants join transaction on transaction_id join competition on competition_id join shs on shs left join re_regist on participant_id";
		$query = $this->db->query($queryString);
		for($i=0; $i<$query->num_rows(); $i++)
		{
			$temp = new stdClass();
			/*$temp->participant_id = $query->row($i)->participant_id;
            $temp->shs_name =$query->row($i)->shs_name;
			$temp->participant_name = $query->row($i)->participant_name;
			$temp->participant_phone =$query->row($i)->participant_phone;			
			$temp->participant_email = $query->row($i)->participant_email;
			$temp->dob = $query->row($i)->dob;
			$temp->gender =$query->row($i)->gender;	
			$temp->vegetarian = $query->row($i)->vegetarian;
			$temp->transaction_id = $query->row($i)->transaction_id;
			$temp->team =$query->row($i)->team;
			$temp->competition_name =$query->row($i)->competition_name;
			$temp->attend=$query->row($i)->attend;*/
			$temp=$query->row($i);
			array_push($result, $temp);
		}
		return $result;
	}

	function attend($id){
		$queryString = "INSERT INTO re_regist VALUES (null,?,?)";
		$query = $this->db->query($queryString,array($id,true));
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}
	function getParticipantById($id){
		$queryString="SELECT * FROM participants WHERE participant_id=?";
		$query=$this->db->query($queryString,array($id));
		$i=0;
		$temp = new stdClass();
		/*$temp->participant_id = $query->row($i)->participant_id;
		$temp->participant_name = $query->row($i)->participant_name;
		$temp->participant_phone =$query->row($i)->participant_phone;			
		$temp->participant_email = $query->row($i)->participant_email;
		$temp->dob = $query->row($i)->dob;
		$temp->gender =$query->row($i)->gender;	
		$temp->vegetarian = $query->row($i)->vegetarian;
		$temp->transaction_id = $query->row($i)->transaction_id;
		$temp->team =$query->row($i)->team;*/
		$temp=$query->row(i);	
		return $temp;
	}
	function editParticipantById($participant_name, $gender, $participant_phone, $dob, $participant_email, $vegetarian, $participant_id){
		$queryString = "UPDATE participants SET participant_name=?, gender=?, participant_phone=?, dob=?, participant_email=?,vegetarian=? WHERE participant_id=?";
		$query = $this->db->query($queryString,array($participant_name, $gender, $participant_phone, $dob, $participant_email, $vegetarian, $participant_id));
		if($this->db->affected_rows() > 0){
			return true;			
		}else{
			return false;
		}
	}
}