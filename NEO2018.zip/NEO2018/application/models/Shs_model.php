<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

defined('BASEPATH') OR exit('No direct script access allowed');

class shs_model extends CI_Model {

	function __construct() 
	{
		parent::__construct();
	}

	function login($userID,$password){
		$queryString = "SELECT * FROM shs WHERE shs_email=? AND password=?";
		$query = $this->db->query($queryString,[$userID,substr(crypt($password, "\$5\$rounds=5000\$kirishimaXharuna$"), 32)]);
		if ($query != null && $query->num_rows() > 0) {
			return $query;
		}
		else 
			return false;
	}
	function addSchool($obj){
		$queryString = "INSERT INTO shs(`shs_name`, `shs_address`, `shs_email`, `cp_name`, `cp_phone`, `password`) VALUES (?,?,?,?,?,?)";
		$query = $this->db->query($queryString,[$obj->shs_name, $obj->shs_address, $obj->shs_email, $obj->cp_name, $obj->cp_phone, substr(crypt($obj->password, "\$5\$rounds=5000\$kirishimaXharuna$"), 32)] );
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}
	function getAllShs(){
		$result = array();
		$queryString = "SELECT * FROM shs";
		$query = $this->db->query($queryString);
		for($i=0; $i < $query->num_rows(); $i++)
		{
			$temp = new stdClass();
			/*$temp->shs_id = $query->row($i)->shs_id;
			$temp->shs_name = $query->row($i)->shs_name;
			$temp->shs_address =$query->row($i)->shs_address;			
			$temp->shs_email = $query->row($i)->shs_email;
			$temp->cp_name = $query->row($i)->cp_name;
			$temp->cp_phone =$query->row($i)->cp_phone;*/
			$temp=$query->row($i);
			array_push($result, $temp);
		}
		return $result;
	}
	function getAllShsUnpaid(){
		$result = array();
		$queryString = "SELECT shs_name, transaction_id, competition_name FROM shs join transaction on transaction.shs_id = shs.shs_id join competition on competition.competition_id = transaction.competition_id WHERE status='regisField'";
		$query = $this->db->query($queryString);
		for($i=0; $i < $query->num_rows(); $i++){
			$temp = new stdClass();
			/*$temp->shs_name = $query->row($i)->shs_name;
			$temp->transaction_id = $query->row($i)->transaction_id;
			$temp->competition_name =$query->row($i)->competition_name;*/
			$temp=$query->row(i);
			array_push($result, $temp);
		}
		return $result;
	}
	function getAllShsPaid(){
		$result = array();
		$queryString = "SELECT people_name, shs_name, cp_name, cp_phone, competition_name, status FROM shs join transaction on shs_id join competition  on competition_id left join comfirm_people  on transaction_id WHERE status='regisParticipant' OR status='ready'";
		$query = $this->db->query($queryString);
		for($i=0; $i < $query->num_rows(); $i++)
		{
			$temp = new stdClass();
			/*$temp->namaSMA = $query->row($i)->namaSMA;
			$temp->namaCP = $query->row($i)->namaCP;
			$temp->telpCP =$query->row($i)->telpCP;
			$temp->namaKompetisi = $query->row($i)->namaKompetisi;
			$temp->namaOrang = $query->row($i)->namaOrang;
			$temp->status =$query->row($i)->status;*/
			$temp=$query->row(i);
			array_push($result, $temp);
		}
		return $result;
	}
}