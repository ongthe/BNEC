<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

defined('BASEPATH') OR exit('No direct script access allowed');

class sma_model extends CI_Model {

	function __construct() 
	{
		parent::__construct();
	}

	function login($userID,$password){
		$queryString = "SELECT * FROM sma WHERE emailSMA=? AND password=?";
		$query = $this->db->query($queryString,array($userID,md5($password)));
		if ($query != null && $query->num_rows() > 0) {
			return $query;
		}
		else 
			return false;
	}
	function addSchool($schoolName,$address,$email,$picName,$phone,$password){
		$queryString = "INSERT INTO sma VALUES (null,?,?,?,?,?,?)";
		$query = $this->db->query($queryString,array($schoolName,$address,$email,$picName,$phone,md5($password)));
		if($this->db->affected_rows() > 0){
			return true;
		}else{
			return false;
		}
	}
	function getAllSMA(){
		$result = array();
		$queryString = "SELECT * FROM sma";
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new stdClass();
			$temp->IDSMA = $query->row($i)->IDSMA;
			$temp->namaSMA = $query->row($i)->namaSMA;
			$temp->alamatSMA =$query->row($i)->alamatSMA;			
			$temp->emailSMA = $query->row($i)->emailSMA;
			$temp->namaCP = $query->row($i)->namaCP;
			$temp->telpCP =$query->row($i)->telpCP;
			
			array_push($result, $temp);
		}
		return $result;
	}
	function getAllSMAUnpaid(){
		$result = array();
		$queryString = "SELECT namaSMA,IDTransaksi,namaKompetisi FROM sma a join transaksi b on a.IDSMA=b.IDSMA join kompetisi c on b.IDKompetisi=c.IDKompetisi WHERE status='regisField'";
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new stdClass();
			$temp->namaSMA = $query->row($i)->namaSMA;
			$temp->IDTransaksi = $query->row($i)->IDTransaksi;
			$temp->namaKompetisi =$query->row($i)->namaKompetisi;
			
			array_push($result, $temp);
		}
		return $result;
	}
	function getAllSMAPaid(){
		$result = array();
		$queryString = "SELECT namaOrang,namaSMA,namaCP,telpCP,namaKompetisi,status FROM sma a join transaksi b on a.IDSMA=b.IDSMA join kompetisi c on b.IDKompetisi=c.IDKompetisi left join konfirmorang d on b.IDTransaksi=d.IDTransaksi WHERE status='regisParticipant' OR status='ready'";
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new stdClass();
			$temp->namaSMA = $query->row($i)->namaSMA;
			$temp->namaCP = $query->row($i)->namaCP;
			$temp->telpCP =$query->row($i)->telpCP;
			$temp->namaKompetisi = $query->row($i)->namaKompetisi;
			$temp->namaOrang = $query->row($i)->namaOrang;
			$temp->status =$query->row($i)->status;
			
			array_push($result, $temp);
		}
		return $result;
	}
}