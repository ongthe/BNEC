<!-- TAMBAHAN JEVON -->
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

defined('BASEPATH') OR exit('No direct script access allowed');

class Contact_model extends CI_Model {

	function __construct() 
	{
		parent::__construct();
	}

	function getMessage(){
		$result = array();
		$queryString = "SELECT * FROM contact";
		$query = $this->db->query($queryString);
		for($i=0; $i < $query->num_rows(); $i++){
			$temp = new stdClass();
			/*$temp->contact_name = $query->row($i)->contact_name;
			$temp->email =$query->row($i)->email;
			$temp->subject = $query->row($i)->subject;
			$temp->message =$query->row($i)->message;
			$temp->replied =$query->row($i)->replied;*/
			$temp=$query->row($i);
			array_push($result, $temp);
		}
		return $result;
	}

	function editReplied($id,$replied){
	
		if($replied != 1)
			$replied = 0;
		$queryString = "UPDATE contact SET replied=? WHERE contact_id=?";
		$query = $this->db->query($queryString,array($replied, $id));
		if($this->db->affected_rows() > 0){			
			return true;			
		}else{
			return false;
		}
	}
}