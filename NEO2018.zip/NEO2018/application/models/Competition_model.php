<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

defined('BASEPATH') OR exit('No direct script access allowed');

class Competition_model extends CI_Model {

	function __construct() 
	{
		parent::__construct();
	}

	function getAllCompetition(){
		$result = array();
		$queryString = "SELECT * FROM competition";
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++){
			$temp = $query->row($i);
			/*$temp->competition_id = $query->row($i)->competition_id;
			$temp->competition_name = $query->row($i)->competition_name;
			$temp->competition_price =$query->row($i)->competition_price;*/
			array_push($result, $temp);
		}
		return $result;
	}
	function getCompetitionByID($id){
		$result = new stdClass();
		$queryString="SELECT * FROM competition WHERE competition_id=?";
		$query=$this->db->query($queryString, [$id]);
			/*$temp->competition_id = $query->row($i)->competition_id;
			$temp->competition_name = $query->row($i)->competition_name;
			$temp->competition_price =$query->row($i)->competition_price;*/
			$result=$query->row(0);
		return $result;
	}
	function getAllFieldByShs($id){
		$result = array();
		/*gracia*/
		$queryString = "SELECT competition_name, status, participant_id, transaction.transaction_id FROM transaction  join competition  on transaction.competition_id = competition.competition_id LEFT JOIN participants on participants.transaction_id = transaction.transaction_id where transaction.shs_id=? AND status IN('Confirm','registParticipant','ready')";
		/*end gracia*/
		$query = $this->db->query($queryString,array($id));
		for($i=0;$i<$query->num_rows();$i++){
			$temp=$query->row($i);
			/*$temp->competition_name = $query->row($i)->competition_name;
			$temp->status =$query->row($i)->status;
			$temp->participant_id =$query->row($i)->participant_id;
			$temp->transaction_id =$query->row($i)->transaction_id;*/
			array_push($result, $temp);
			
		}
		return $result;
	}
}