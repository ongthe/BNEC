<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();
		isAdmin();
		$this->load->model('shs_model','shs');
		$this->load->model('transaction_model','transaction');
	}

	public function index()
	{
		$data1['allShs']=$this->shs->getAllShs();
		$data1['page']='All Schools - National English Olympics 2018';
		$data['content'] = $this->load->view('admin/allShs',$data1,true);
		$this->load->view('admin/header',$data);
	}

	public function unpaid(){
		$data1['allShs']=$this->shs->getAllShsUnpaid();
		$data1['page']='Unpaid - National English Olympics 2018';
		$data['content'] = $this->load->view('admin/unpaid',$data1,true);
		$this->load->view('admin/header',$data);
	}

	public function confirm(){
		$data1['allShs']=$this->transaction->getAllConfirm();
		$data1['page']='Confirm Payment - National English Olympics 2018';
		$data['content'] = $this->load->view('admin/confirm',$data1,true);
		$this->load->view('admin/header',$data);
	}

	public function paid(){
		$data1['allShs']=$this->shs->getAllShsPaid();
		$data1['page']='Paid - National English Olympics 2018';
		$data['content'] = $this->load->view('admin/paid',$data1,true);
		$this->load->view('admin/header',$data);
	}

	public function adminConfirm($transaction_id){		
		$this->load->model('transaction_model','transaction');
		$success=$this->transaction->adminConfirm($transaction_id,$this->session->userdata('userID'));
		if($success){
                        $this->session->set_flashdata('confirmAdmin', "Confirm Payment Success!");
			redirect('Admin/confirm', 'refresh');
		}else{
                        $this->session->set_flashdata('failedConfirmAdmin', "Confirm Payment Failed!");
			redirect('Admin/confirm', 'refresh');
		}
	}

        public function followup($shs_id)
        {
            $this->load->model('transaction_model','transaction');
	    $success=$this->transaction->followup($this->session->userdata('userID'), $shs_id);
            if($success){
                $this->session->set_flashdata('followup', "Follow Up Success!");
	        redirect('Admin/index', 'refresh');
	    }else{
                $this->session->set_flashdata('failedFollowup', "Follow Up Failed!");
		redirect('Admin/index', 'refresh');
	    }
        }

	public function viewParticipant(){	
		$this->load->model('participant_model','participant');
		$data1['participant']=$this->participant->getAllParticipantByShs();
		$data1['page']='All Participants - National English Olympics 2018';
		$data['content'] = $this->load->view('admin/viewParticipant',$data1,true);
		$this->load->view('admin/header',$data);		
	}

	public function view_message(){	
		$this->load->model('Contact_model','msg');
		$data1['msg']=$this->msg->getMessage();
		$data1['page']='All Message - National English Olympics 2018';
		$data['content'] = $this->load->view('admin/viewMsg',$data1,true);
		$this->load->view('admin/header',$data);		
	}

	public function editReplyMsg($id)
	{
		$this->load->model('Contact_model','massage');
		$replied = $this->input->post('reply');
		$success = $this->massage->editReply($id,$replied);
		if($success){
			$this->session->set_flashdata('editReply', "Update Reply Status Success");
			redirect('Admin/view_message', 'refresh');
		}
		else
		{
			$this->session->set_flashdata('failedEditReply', "Failed to Update Reply Status. Please try again!");
			redirect('Admin/view_message', 'refresh');
		}
	}

	public function reregistList(){
		$this->load->model('participant_model','participant');
		$data1['participant']=$this->participant->getAllParticipant();
		$data1['page']='reregis';
		$data['content'] = $this->load->view('admin/reregistList',$data1,true);
		$this->load->view('admin/header',$data);	
	}
	public function attend($id){
		$this->load->model('participant_model','participant');
		$success=$this->participant->attend($id);
		$data1['page']='reregis';
		if($success){
			$this->session->set_flashdata('attendSuccess', "Reregistration Success!");
			redirect('Admin/reregistList', 'refresh');
		}
		else
		{
			$this->session->set_flashdata('attendFailed', "Reregistration Failed!");
			redirect('Admin/reregistList', 'refresh');
		}
	}
	public function editParticipant($id){
		$this->load->model('participant_model','participant');
		$data1['participant']=$this->participant->getParticipantById($id);
		$data1['page']='fields';
		$data['content'] = $this->load->view('admin/editParticipant',$data1,true);
		$this->load->view('admin/header',$data);
	}
	public function editParticipant1($id){
		$this->load->model('participant_model','participant');
		$fullName = $this->input->post('participant_name');
		$gender = $this->input->post('gender');
		$phone = $this->input->post('phone');
		$dob = $this->input->post('dob');
		$email = $this->input->post('email');
		$vegetarian = $this->input->post('vegetarian');
		
		$success = $this->participant->editParticipant($participant_name, $gender, $phone, $dob, $email, $vegetarian, $participant_id);

		if($success){
			$this->session->set_flashdata('editParticipant', "Edit Participant Success!");
			redirect('Admin/reregistList', 'refresh');
		}
		else
		{
			$this->session->set_flashdata('failedEditParticipant', "Failed to Edit Participant. Please try again!");
			redirect('Admin/reregistList', 'refresh');
		}
	}
}