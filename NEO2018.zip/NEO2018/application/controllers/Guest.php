<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Guest extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function index()
	{
		$body = $this->load->view('guest/home', [
			//
		], true);
		$this->load->view('guest/header', [
			"content" => $body,
			"title"   => "National English Olympics 2018 - Shaping Notions"
		], false);
	}

	public function contact()
	{
		$body = $this->load->view('contact', [
			//
		], true);
		$this->load->view('guest/header', [
			"content" => $body,
			"title"   => "Contact Us"
		]);
	}

	public function competition()
	{
		$body = $this->load->view('competition', [
			//
		], true);
		$this->load->view('guest/header',[
			"content" => $body,
			"title"   => "Competition"
		]);	
	}

	public function accommodation()
	{
		$body = $this->load->view('accommodation', [
			//
		],true);
		$this->load->view('guest/header', [
			"content" => $body,
			"title"   => "Accommodation"
		]);	
	}

	public function faq()
	{
		$body = $this->load->view('faq', [
			//
		], true);
		$this->load->view('guest/header', [
			"content" => $body,
			"title"   => "FAQ"
		]);	
	}

	public function registration()
	{
		$body = $this->load->view('guest/registration', [
			//
		], true);
		$this->load->view('guest/header', [
			"content" => $body,
			"title"   => "Registration"
		]);	
	}

	public function about()
	{
		$body = $this->load->view('about', [
			//
		], true);
		$this->load->view('guest/header', [
			"content" => $body,
			"title"   => "About Us"
		]);	
	}

	public function addSchool(){
		$obj = new stdClass;
		$obj->shs_name = $this->input->post("schoolName");
		$obj->shs_address     = $this->input->post("address");
		$obj->shs_email       = $this->input->post("email");
		$obj->cp_name     = $this->input->post("picName");
		$obj->cp_phone       = $this->input->post("phone");
		$obj->password    = $this->input->post("password");
		$this->load->model('shs_model','shs');

		//this model returns true/false
		$success = $this->shs->addSchool($obj);

		if($success)
		{
			$this->session->set_flashdata('addSchool', "Add School Success!");
			// redirect('Guest/index', 'refresh');
		}
		else
		{
			$this->session->set_flashdata('failedAddSchool', "Failed to Add School. Please try again!");
			// redirect('Guest/registration', 'refresh');
		}
	}

	public function sendMessage()
	{
		$msg          = new stdClass();
		$msg->name    = $this->input->post('name');
		$msg->email   = $this->input->post('email');
		$msg->subject = $this->input->post('subject');
		$msg->message = $this->input->post('message');

		$this->load->model('Participant_model','participant');

		//this model returns true/false
		$success = $this->participant->addMessage($msg);

		if($success)
		{
			$this->session->set_flashdata('addMessage', "Send Message Success!");
			redirect('Guest/contact', 'refresh');
		}
		else
		{
			$this->session->set_flashdata('failedAddMessage', "Failed to Send Message. Please try again!");
			redirect('Guest/contact', 'refresh');
		}
	}

	public function announcement()
	{
		$body = $this->load->view('guest/semifinal', [
			//
		],true);
		$this->load->view('guest/header', [
			"content" => $body,
			"title"   => "Announcement"
		]);
	}
}
