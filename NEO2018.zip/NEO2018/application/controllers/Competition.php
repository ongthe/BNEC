<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Competition extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();
		$this->early_bid = mktime(0,0,0,10,20,2018);
		$this->load->model('competition_model','competition');
		isLoggedIn();
	}

	public function index()
	{
		$data1['comps']=$this->competition->getAllCompetition();
		$data1['page']='Fields Registration - National English Olympics 2018';
		$data1['early_bid']=$this->early_bid;
		$data['content'] = $this->load->view('participant/regisField',$data1,true);
		$this->load->view('participant/header',$data);
	}
	public function my_fields(){
		$data1['fields']=$this->competition->getAllFieldByShs($this->session->userdata('shs_id'));
		$data1['page']='My Fields - National English Olympics 2018';
		$data['content'] = $this->load->view('participant/myField',$data1,true);
		$this->load->view('participant/header',$data);
	}
	public function view_participant($id,$fieldsName){	
		if($fieldsName != 'Debate')
		{	
			$this->load->model('participant_model','participant');
			$data1['participant']=$this->participant->getParticipantByField($id);
			$data1['page']='fields';
			$data1['fieldsName']=$fieldsName;

			/*$data1['early_bid']=$this->early_bid;*/
			$data['content'] = $this->load->view('participant/viewParticipant',$data1,true);
			$this->load->view('participant/header',$data);
		}
		else{
			$this->load->model('participant_model','participant');
			$data1['participant']=$this->participant->getDebateParticipant($id);
			$data1['page']='fields';
			$data1['fieldsName']=$fieldsName;

			/*$data1['early_bid']=$this->early_bid;*/
			$data['content'] = $this->load->view('participant/viewParticipant',$data1,true);
			$this->load->view('participant/header',$data);
		}
	}
}
