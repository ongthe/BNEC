<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Participant extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();
		$this->load->model('shs_model','shs');	
		$this->load->model('participant_model', 'participant');
		$this->load->model('transaction_model', 'transaction');
		isLoggedIn();	
	}

	public function index()
	{
		$data1['page']='National English Olympics 2018';
		$data1['user']=$this->session->userdata('shs_name');
		$data['content'] = $this->load->view('participant/home',$data1,true);
		$this->load->view('participant/header',$data);
	}

	public function accommodation()
	{
		$data1['page']='Accommodation - National English Olympics 2018';
		$data['content'] = $this->load->view('accommodation',$data1,true);
		$this->load->view('participant/header',$data);	
	}

	public function send_email()
	{
		$data1['page']='Confirm Email - National English Olympics 2018';
		$data['content'] = $this->load->view('participant/email',$data1,true);
		$this->load->view('participant/header',$data);	
	}

	public function faq()
	{
		$data1['page']='FAQ - National English Olympics 2018';
		$data['content'] = $this->load->view('faq',$data1,true);
		$this->load->view('participant/header',$data);	
	}

	public function competition()
	{
		$data1['page']='Competition - National English Olympics 2018';
		$data1['early_bid']= $this->early_bid;
		$data['content'] = $this->load->view('competition',$data1,true);
		$this->load->view('participant/header',$data);	
	}
	public function contact()
	{
		$data1['page']='Contact Us - National English Olympics 2018';
		$data['content'] = $this->load->view('contact',$data1,true);
		$this->load->view('participant/header',$data);
	}
	public function about(){
		$data1['page']='About Us - National English Olympics 2018';
		$data['content'] = $this->load->view('about',$data1,true);
		$this->load->view('participant/header',$data);	
	}
	public function regis_participant($transaction_id, $fields_name){
		$data1['page'] = 'Participant Registration - National English Olympics 2018';
		$data1['transaction_id'] = $transaction_id;
		$data1['fields_name'] = $fields_name;
		$data['content'] = $this->load->view('participant/regisParticipant',$data1,true);
		$this->load->view('participant/header',$data);
	}
	
	public function add_participant($transaction_id, $fields_name){
		$shs_id = $this->session->userdata('shs_id');
		//NOT DEBATE
		if($fields_name != 'Debate')
		{
			$obj = new stdCLass();
			$obj->shs_id = $shs_id;
			$obj->participant_name = $this->input->post('FullName');
			$obj->gender = $this->input->post('gender');
			$obj->participant_phone = $this->input->post('phone');
			$obj->dob = $this->input->post('dob');
			$obj->participant_email = $this->input->post('email');
			$obj->vegetarian = $this->input->post('vegetarian');
			$obj->transaction_id = $transaction_id;
			$obj->team = "";
			$obj->debater_numb = "";


			$success = $this->participant->addParticipant($obj);
		}
		//DEBATE
		else
		{
			$fullNameDB1 = $this->input->post('FullNameDB1');
			$genderDB1 = $this->input->post('genderDB1');
			$phoneDB1 = $this->input->post('phoneDB1');
			$dobDB1 = $this->input->post('dobDB1');
			$emailDB1 = $this->input->post('emailDB1');
			$vegetarianDB1 = $this->input->post('vegetarianDB1');

			$fullNameDB2 = $this->input->post('FullNameDB2');
			$genderDB2 = $this->input->post('genderDB2');
			$phoneDB2 = $this->input->post('phoneDB2');
			$dobDB2 = $this->input->post('dobDB2');
			$emailDB2 = $this->input->post('emailDB2');
			$vegetarianDB2 = $this->input->post('vegetarianDB2');

			$fullNameDB3 = $this->input->post('FullNameDB3');
			$genderDB3 = $this->input->post('genderDB3');
			$phoneDB3 = $this->input->post('phoneDB3');
			$dobDB3 = $this->input->post('dobDB3');
			$emailDB3 = $this->input->post('emailDB3');
			$vegetarianDB3 = $this->input->post('vegetarianDB3');

			$teamName = $this->input->post('teamName');

			$success = $this->participant->addParticipantDB1($IDSMA, $fullNameDB1, $genderDB1, $phoneDB1, $dobDB1, $emailDB1, $vegetarianDB1, $IDTrans, $teamName);
			$success2 = $this->participant->addParticipantDB2($IDSMA, $fullNameDB2, $genderDB2, $phoneDB2, $dobDB2, $emailDB2, $vegetarianDB2, $IDTrans, $teamName);
			$success3 = $this->participant->addParticipantDB3($IDSMA, $fullNameDB3, $genderDB3, $phoneDB3, $dobDB3, $emailDB3, $vegetarianDB3, $IDTrans, $teamName);
		}
		
		if($success || $success2 || $success3){
			$this->session->set_flashdata('addParticipant', "Add Participant Success!");
			redirect('Competition/my_fields', 'refresh');
		}
		else
		{
			$this->session->set_flashdata('failedAddParticipant', "Failed to Add Participant. Please try again!");
			redirect('Competition/my_fields', 'refresh');
		}
	}
	public function edit_participant($IDTrans, $fieldsName){
		if($fieldsName != 'Debate')
		{
			$fullName = $this->input->post('fullName');
			$gender = $this->input->post('gender');
			$phone = $this->input->post('phone');
			$dob = $this->input->post('dob');
			$email = $this->input->post('email');
			$vegetarian = $this->input->post('vegetarian');
			
			$success = $this->participant->editParticipant($fullName, $gender, $phone, $dob, $email, $vegetarian, $IDTrans);
		}else{
			$fullNameDB1 = $this->input->post('FullNameDB1');
			$genderDB1 = $this->input->post('genderDB1');
			$phoneDB1 = $this->input->post('phoneDB1');
			$dobDB1 = $this->input->post('dobDB1');
			$emailDB1 = $this->input->post('emailDB1');
			$vegetarianDB1 = $this->input->post('vegetarianDB1');

			$fullNameDB2 = $this->input->post('FullNameDB2');
			$genderDB2 = $this->input->post('genderDB2');
			$phoneDB2 = $this->input->post('phoneDB2');
			$dobDB2 = $this->input->post('dobDB2');
			$emailDB2 = $this->input->post('emailDB2');
			$vegetarianDB2 = $this->input->post('vegetarianDB2');

			$fullNameDB3 = $this->input->post('FullNameDB3');
			$genderDB3 = $this->input->post('genderDB3');
			$phoneDB3 = $this->input->post('phoneDB3');
			$dobDB3 = $this->input->post('dobDB3');
			$emailDB3 = $this->input->post('emailDB3');
			$vegetarianDB3 = $this->input->post('vegetarianDB3');

			$teamName = $this->input->post('teamName');

			$success = $this->participant->editParticipantDB1($fullNameDB1, $genderDB1, $phoneDB1, $dobDB1, $emailDB1, $vegetarianDB1, $IDTrans, $teamName);
			$success2 = $this->participant->editParticipantDB2($fullNameDB2, $genderDB2, $phoneDB2, $dobDB2, $emailDB2, $vegetarianDB2, $IDTrans, $teamName);
			$success3 = $this->participant->editParticipantDB3($fullNameDB3, $genderDB3, $phoneDB3, $dobDB3, $emailDB3, $vegetarianDB3, $IDTrans, $teamName);
		}

		if($success || $success2 || $success3){
			$this->session->set_flashdata('editParticipant', "Edit Participant Success!");
			redirect('Competition/my_fields', 'refresh');
		}
		else
		{
			$this->session->set_flashdata('failedEditParticipant', "Failed to Edit Participant. Please try again!");
			redirect('Competition/my_fields', 'refresh');
		}
	}
}
