<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();
		$this->load->model('shs_model','shs');
	}

	// public function index()
	// {

	// }

	public function login(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$query = $this->shs->login($username,$password);

		if(!$query)
		{
			$this->session->set_flashdata('failedLogin', "Invalid username or password");
			return redirect(base_url(), "refresh");
		}		
		else{
			$data = array (
					'shs_id' => $query->row(0)->shs_id,
					'namaSMA' => $query->row(0)->shs_name,
					'alamatSMA' => $query->row(0)->shs_address,
					'emailSMA' => $query->row(0)->shs_email,
					'namaCP' => $query->row(0)->cp_name,
					'telpCP' => $query->row(0)->cp_phone
				);
			$this->session->set_userdata($data);
			if($this->session->userdata('shs_id') != null && $this->session->userdata('shs_id') !="")
			{
				redirect('Participant','refresh');
			}
		}
	}

	public function logout(){	
		isLoggedIn();	
		$this->session->sess_destroy();
		redirect(base_url(),'refresh');
	}


	public function admin(){
		$this->load->view('admin/login');
		if($this->session->userdata('userID') != null && $this->session->userdata('userID') !="" )
		{
			redirect('Admin','refresh');
		}
	}

	public function checkLoginAdmin(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		if($username=='carvin101' && $password='senkanKirishima'){
			$data = array (
					'userID' => 'carvin101'
				);
			$this->session->set_userdata($data);
			if($this->session->userdata('userID') != null && $this->session->userdata('userID') !="" )
			{
				redirect('Admin','refresh');
			}
		}		
		else if($username=='ongthe' && $password='mashiro01'){
			$data = array (
					'userID' => 'grace'
				);
			$this->session->set_userdata($data);
			if($this->session->userdata('userID') != null && $this->session->userdata('userID') !="" )
			{
				redirect('Admin','refresh');
			}
		}
		else if($username=='calvin' && $password='scneo2018'){
			$data = array (
					'userID' => 'leon'
				);
			$this->session->set_userdata($data);
			if($this->session->userdata('userID') != null && $this->session->userdata('userID') !="" )
			{
				redirect('Admin','refresh');
			}
		}
		else if($username=='veni' && $password='scneo2018'){
			$data = array (
					'userID' => 'owen'
				);
			$this->session->set_userdata($data);
			if($this->session->userdata('userID') != null && $this->session->userdata('userID') !="" )
			{
				redirect('Admin','refresh');
			}
		}
		else if($username=='joice' && $password='scneo2018'){
			$data = array (
					'userID' => 'kiky'
				);
			$this->session->set_userdata($data);
			if($this->session->userdata('userID') != null && $this->session->userdata('userID') !="" )
			{
				redirect('Admin','refresh');
			}
		}
		else if($username=='williamJ' && $password='neo2018'){
			$data = array (
					'userID' => 'rehan'
				);
			$this->session->set_userdata($data);
			if($this->session->userdata('userID') != null && $this->session->userdata('userID') !="" )
			{
				redirect('Admin','refresh');
			}
		}
		else if($username=='williamHans' && $password='neo2018'){
			$data = array (
					'userID' => 'helen'
				);
			$this->session->set_userdata($data);
			if($this->session->userdata('userID') != null && $this->session->userdata('userID') !="" )
			{
				redirect('Admin','refresh');
			}
		}
		
		
		else{			
			$error['err'] = 'Invalid UserID or Password';
			$this->load->view('admin/login',$error);
		}
	}
}