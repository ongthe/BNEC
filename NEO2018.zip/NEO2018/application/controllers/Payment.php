<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();
		date_default_timezone_set("Asia/jakarta");
		isLoggedIn();	
		$this->load->model('transaction_model','transaction');
		$this->load->model('competition_model','competition');
	}

	public function index()
	{	

	}

	public function invoices_list(){
		$data1['page']='Invoices - National English Olympics 2018';
		$data1['transaction']=$this->transaction->getTransByShs($this->session->userdata('shs_id'));
		$data['content'] = $this->load->view('participant/invoicesList',$data1,true);
		$this->load->view('participant/header',$data);
	}

	public function confirmList(){
		$data1['page']='Confirm Payment - National English Olympics 2018';
		$data['content'] = $this->load->view('participant/confirmList',$data1,true);
		$this->load->view('participant/header',$data);
	}

	public function payment1($fieldID){
		$data1['page']='Payment - National English Olympics 2018';
		$data1['field']=$this->competition->getCompetitionByID($fieldID);		
		$data['content'] = $this->load->view('participant/payment',$data1,true);
		$this->load->view('participant/header',$data);
	}

	public function acceptTrans($fieldID/*,$qty*/){
		$data1['page']='Payment - National English Olympics 2018';
		$success=$this->transaction->addTransaction($this->session->userdata('shs_id'),$fieldID/*,$qty*/);
		if($success){
			$data2['addTrans']=true;
			$data2['comps']=$this->competition->getAllCompetition();
			$data2['page']='competition';
			$data['content'] = $this->load->view('participant/regisField',$data2,true);
			$this->session->set_flashdata('addTrans', "Add Transaction Success!");
			redirect('Payment/confirm_payment', 'refresh');
		}else{
			$data1['failedTrans']=true;
			$data['content'] = $this->load->view('participant/regisField',$data1,true);
			$this->session->set_flashdata('failedAddTrans', "Failed to Add Transaction. Please try again!");
			redirect('Competition', 'refresh');
		}
	}
	
	public function confirm_payment(){
		$data1['page'] = 'Confirm Payment - National English Olympics 2018';
		$data1['allTrans'] = $this->transaction->getTransByShsNotConfirm($this->session->userdata('shs_id'));
		if(!empty($data1['allTrans']))
		{
			$data1['confirm'] = $this->transaction->getConfirm($data1['allTrans'][0]->transaction_id);
		}
		$data['content'] = $this->load->view('participant/confirm',$data1,true);
		$this->load->view('participant/header',$data);
	}

	public function confirm_payment1()
	{
		$data1['page'] = 'Confirm Payment - National English Olympics 2018';

		foreach($this->input->post('chkTrsNo') as $check) 
		{
			$success = $this->transaction->confirm($check, $this->input->post('noRek'), $this->input->post('atas_nama'), $this->input->post('nominal'), $this->input->post('transfer_date'));
    	}

		if($success)
		{
			$data1['allTrans'] = $this->transaction->getTransByShs($this->session->userdata('shs_id'));
			$data1['confirmPayment'] = true;
			$data['content'] = $this->load->view('participant/confirm',$data1,true);
			$this->session->set_flashdata('confirmPayment', "Confirm Payment Success!");
			//$this->load->view('participant/header',$data);
			redirect('Payment/invoices_list', 'refresh');
		}
		else
		{
			$data1['allTrans'] = $this->transaction->getTransByShs($this->session->userdata('shs_id'));
			$data1['confirmPayment'] = false;
			$data['content'] = $this->load->view('participant/confirm',$data1,true);
			$this->session->set_flashdata('failedConfirmPayment', "Failed to confirm payment. Please Try again!");
			//$this->load->view('participant/header',$data);
			redirect('Payment/invoices_list', 'refresh');
		}
	}
}