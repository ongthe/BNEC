<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('isLoggedIn'))
{
    function isLoggedIn()
    {
        $CI =& get_instance();
    	$checkLogin = $CI->session->userdata('shs_id');
       	if(!isset($checkLogin) || $checkLogin != true)
       	{
        	redirect('Guest','refresh');
    	}
    }  
    function isAdmin()
    {
        $CI =& get_instance();
    	$checkLogin = $CI->session->userdata('userID');
       	if(!isset($checkLogin) || $checkLogin != true)
       	{
        	redirect('Guest','refresh');
    	}
    }   
}