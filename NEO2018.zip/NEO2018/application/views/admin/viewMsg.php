<div class="page-banner no-subtitle" style="margin-top:8em;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="white">All Message</h1>
            </div>
        </div>
    </div>
</div>

<div class="container" id="invoices-list">
    <table class="table" id="tblShow">
        <thead>
            <tr>
                <th>No.</th>
                <th>Name</th>
                <th>Email</th>
                <th>Title</th>
                <th>Message</th>
                <th></th>
            </tr>
        </thead>
        <tbody>         
            <?php for($i=0;$i<count($msg);$i++)
            { 
                $j = $i+1;
                if(substr($msg[$i]->subject, 0 , 7) != "http://")
                    { ?>
                <tr>
                    <td><?php echo $i+1; ?></td>
                    <td><?php echo $msg[$i]->nama; ?></td>

                    <td><?php echo $msg[$i]->email; ?></td>
                    <td><?php echo $msg[$i]->subject; ?></td>
                    <td><?php echo $msg[$i]->message; ?></td>
                    <td>
                        <a href="https://mail.google.com/mail/?view=cm&fs=1&to=<?php echo $msg[$i]->email; ?>&su=<?php echo 'Re:' . $msg[$i]->subject; ?>&body=" ><button type='button' class="btn-system btn-large" >Reply</button></a>
                        <form role="form" id='checkbox-reply<?php echo $j; ?>' method='post' action="<?php echo base_url(); ?>Admin/editReplyMsg/<?php echo $j?>">
                            <?php
                                
                                if($msg[$i]->replied == 1)
                                    echo "<input class='reply' type='checkbox' name='reply' value='1' checked onclick='submitCheck($j);'>";
                                else
                                    echo "<input class='reply' type='checkbox' name='reply' value='1' onclick='submitCheck($j);'>";
                            ?>
                            Replied
                        </form>
                    </td>
                </tr>
            <?php }} ?>
        </tbody>
    </table>
    <script type="text/javascript">
        function submitCheck(x)
        {
            var stringVar = "#checkbox-reply" + x;
            $(stringVar).submit();
        }
    </script>
</div>