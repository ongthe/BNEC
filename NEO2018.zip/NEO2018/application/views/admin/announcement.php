<div class="page-banner no-subtitle" style="margin-top:8em;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="white">Announcement Editor</h1>
            </div>
        </div>
    </div>
</div>

<style type="text/css">
    input
    {
        height: 22px;
        margin: 0;
    }
</style>

<div class="container" id="invoices-list">
    <table class="table" id="tblShow">
        <thead>
            <tr>
                <th>No.</th>
                <th>Entry ID</th>
                <th>Name</th>
                <th>School</th>
                <th>Field</th>
                <th></th>
            </tr>
        </thead>
        <tbody>         
            <?php for($i=0;$i<count($anoun);$i++)
            { 
                $j = $i+1; ?>
                <tr>
                    <td><?php echo $i+1; ?></td>
                    <td><?php echo $anoun[$i]->id; ?></td>
                    <td><?php echo $anoun[$i]->nama; ?></td>
                    <td><?php echo $anoun[$i]->sekolah; ?></td>
                    <td><?php echo $anoun[$i]->field; ?></td>
                    <td>[Edit]&ensp;[Del]</td>
                </tr> 
            <?php } ?>
            <tr>
                <td></td>
                <td></td>
                <td><input type="text" name='nama'></td>
                <td><input type='text' name='sekolah'></td>
                <td>
                    <select name='field'>
                        <option value='1'>Newscasting</option>
                        <option value='2'>Scrabble</option>
                        <option value='3'>Speech</option>
                        <option value='4'>Debate</option>
                        <option value='5'>Storytelling</option>
                    </select>
                </td>
                <td>ADD</td>
            </tr>
            <tr></tr>
        </tbody>
    </table>
    <script type="text/javascript">
    </script>
</div>
