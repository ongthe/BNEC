<div class="page-banner no-subtitle" style="margin-top:8em;"> 
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="white">Paid Schools</h1>
			</div>
		</div>
	</div>
</div>

<div class="container" id="invoices-list">
	<table class="table" id="tblShow">
		<thead>
			<tr>
				<th>No.</th>
				<th>SMA Name</th>
		        <th>CP Name</th>
		        <th>CP Telp</th>
		        <th>Competition Name</th>
		        <th>Admin</th>
		        <th>Status</th>
			</tr>
		</thead>
		<tbody>			
	    	<?php for($i=0;$i<count($allSMA);$i++){ ?>
		    <tr>
				<td><?php echo $i+1; ?></td>
				<td><?php echo $allSMA[$i]->namaSMA; ?></td>
				<td><?php echo $allSMA[$i]->namaCP; ?></td>
				<td><?php echo $allSMA[$i]->telpCP; ?></td>					
				<td><?php echo $allSMA[$i]->namaKompetisi; ?></td>	
				<td><?php echo $allSMA[$i]->namaOrang; ?></td>	
				<td <?php if($allSMA[$i]->status=='ready'){ ?>
		    	class="ready"
		    	<?php }else{ ?>
		    	class="not-ready"
		    	<?php } ?>><?php echo $allSMA[$i]->status; ?></td>
			</tr>
			<?php } ?>
		</tbody>
	</table>
</div>