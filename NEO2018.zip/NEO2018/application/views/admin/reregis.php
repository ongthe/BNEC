<div class="page-banner no-subtitle">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="white">Edit Profile</h1>
            </div>
        </div>
    </div>
</div>

<div class="container call-action call-action-boxed call-action-style1 no-descripton clearfix" id="regis-Participant">
    <form role="form" class="contact-form" id="confirm-form" method="post" <?php if($fieldsName != "Debate"){ ?>action="<?php echo base_url().'Participant/editParticipant/'.$participant->IDTransaksi.'/'.$fieldsName; ?>"<?php }else{ ?> action="<?php echo base_url().'Participant/editParticipant/'.$participant[0]->IDTransaksi.'/'.$fieldsName; ?>" <?php } ?>>
        <?php if($fieldsName != "Debate") { ?>
        <div class="checkbox">
            <div class="col-md-3" style="margin-top: 7.5px;">
                <label>Full Name :</label>
            </div>
            <div class="col-md-9">                
               <input type="text" placeholder="Full Name" name="fullName" required value="<?php echo $participant->namaPeserta; ?>">
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3">
                    <label>Gender :</label>
                </div>
                <div class="col-md-9">
                    <input type="radio" name="gender" id="male" value="M" required <?php if($participant->gender=='M'){echo 'checked';} ?>/>
                    <label for="male" style="padding-left: 5px !important;">Male</label>
                    <input type="radio" name="gender" id="female" value="F" style="margin-left: 10px;" required <?php if($participant->gender=='F'){echo 'checked';} ?>/>
                    <label for="female" style="padding-left: 5px !important;">Female</label>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3" style="margin-top: 20px;">
                    <label>Phone Number :</label>
                </div>
                <div class="col-md-9" style="margin-top: 10px;">
                    <input type="number" placeholder="Phone Number" name="phone" required value="<?php echo $participant->telpPeserta; ?>">
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3" style="margin-top: 10px;">
                    <label>Date of Birth :</label>
                </div>
                <div class="col-md-9">
                    <input type="date" placeholder="Date of Birth" name="dob" required value="<?php echo $participant->DOB; ?>">
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3" style="margin-top: 5px;">
                    <label>Email :</label>
                </div>
                <div class="col-md-9">
                    <input type="email" placeholder="Email" name="email" required value="<?php echo $participant->emailPeserta; ?>">
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3">
                    <label>Vegetarian :</label>
                </div>
                <div class="col-md-9">
                    <input type="radio" name="vegetarian" id="vegetarian" value="1" <?php if($participant->vege==true){echo 'checked';} ?>/>
                    <label for="vegetarian" style="padding-left: 5px !important;">Vegetarian</label>
                    <input type="radio" name="vegetarian" id="nonVegetarian" value="0" style="margin-left: 10px;" <?php if($participant->vege==false){echo 'checked';} ?>/>
                    <label for="nonVegetarian" style="padding-left: 5px !important;">Non Vegetarian</label>
                </div>
            </div>
        </div>
        <div class="button-side btn-form" style="margin-top: 20px;">        
            <button type="submit" id="submit" class="btn-system btn-large">Edit</button>
        </div>
        <?php } else { ?>
        <div>
            <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
                <li class="active"><a href="#debater1" data-toggle="tab">Debater 1</a></li>
                <li><a href="#debater2" data-toggle="tab">Debater 2</a></li>
                <li><a href="#debater3" data-toggle="tab">Debater 3</a></li>
                <li><a href="#team" data-toggle="tab">Team</a></li>
            </ul>
            <div id="my-tab-content" class="tab-content">
                <div class="tab-pane active" id="debater1">
                    <div class="col-md-12" style="margin-left: -50px;">
                        <div class="checkbox">
                            <div class="col-md-4" style="margin-top: 7.5px;">
                                <label>Full Name :</label>
                            </div>
                            <div class="col-md-8">                
                               <input type="text" placeholder="Full Name" name="FullNameDB1" required value="<?php echo $participant[0]->namaPeserta; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4">
                                    <label>Gender :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="radio" name="genderDB1" id="male" value="M" <?php if($participant[0]->gender == "M"){echo "checked";} ?>/>
                                    <label for="male" style="padding-left: 5px !important;">Male</label>
                                    <input type="radio" name="genderDB1" id="female" value="F" style="margin-left: 10px;" <?php if($participant[0]->gender == "F"){echo "checked";} ?>/>
                                    <label for="female" style="padding-left: 5px !important;">Female</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 20px;">
                                    <label>Phone Number :</label>
                                </div>
                                <div class="col-md-8" style="margin-top: 10px;">
                                    <input type="number" placeholder="Phone Number" name="phoneDB1" required value="<?php echo $participant[0]->telpPeserta; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 10px;">
                                    <label>Date of Birth :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="date" placeholder="Date of Birth" name="dobDB1" required value="<?php echo $participant[0]->DOB; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 5px;">
                                    <label>Email :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="email" placeholder="Email" name="emailDB1" required value="<?php echo $participant[0]->emailPeserta; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4">
                                    <label>Vegetarian :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="radio" name="vegetarianDB1" id="vegetarian" value="1" <?php if($participant[0]->vege == true){echo "checked";} ?>/>
                                    <label for="vegetarian" style="padding-left: 5px !important;">Vegetarian</label>
                                    <input type="radio" name="vegetarianDB1" id="nonVegetarian" value="0" style="margin-left: 10px;" <?php if($participant[0]->vege == false){echo "checked";} ?>/>
                                    <label for="nonVegetarian" style="padding-left: 5px !important;">Non Vegetarian</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="debater2">
                    <div class="col-md-12" style="margin-left: -50px;">
                        <div class="checkbox">
                            <div class="col-md-4" style="margin-top: 7.5px;">
                                <label>Full Name :</label>
                            </div>
                            <div class="col-md-8">                
                               <input type="text" placeholder="Full Name" name="FullNameDB2" required value="<?php echo $participant[1]->namaPeserta; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4">
                                    <label>Gender :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="radio" name="genderDB2" id="male" value="M" <?php if($participant[1]->gender == "M"){echo "checked";} ?>/>
                                    <label for="male" style="padding-left: 5px !important;">Male</label>
                                    <input type="radio" name="genderDB2" id="female" value="F" style="margin-left: 10px;" <?php if($participant[1]->gender == "F"){echo "checked";} ?>/>
                                    <label for="female" style="padding-left: 5px !important;">Female</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 20px;">
                                    <label>Phone Number :</label>
                                </div>
                                <div class="col-md-8" style="margin-top: 10px;">
                                    <input type="number" placeholder="Phone Number" name="phoneDB2" required value="<?php echo $participant[1]->telpPeserta; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 10px;">
                                    <label>Date of Birth :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="date" placeholder="Date of Birth" name="dobDB2" required value="<?php echo $participant[1]->DOB; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 5px;">
                                    <label>Email :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="email" placeholder="Email" name="emailDB2" required value="<?php echo $participant[1]->emailPeserta; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4">
                                    <label>Vegetarian :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="radio" name="vegetarianDB2" id="vegetarian" value="1" <?php if($participant[1]->vege == true){echo "checked";} ?>/>
                                    <label for="vegetarian" style="padding-left: 5px !important;">Vegetarian</label>
                                    <input type="radio" name="vegetarianDB2" id="nonVegetarian" value="0" style="margin-left: 10px;" <?php if($participant[1]->vege == false){echo "checked";} ?>/>
                                    <label for="nonVegetarian" style="padding-left: 5px !important;">Non Vegetarian</label>
                                </div>
                            </div>
                        </div>
                    </div> 
                </div>  
                <div class="tab-pane" id="debater3">
                    <div class="col-md-12" style="margin-left: -50px;">
                        <div class="checkbox">
                            <div class="col-md-4" style="margin-top: 7.5px;">
                                <label>Full Name :</label>
                            </div>
                            <div class="col-md-8">                
                               <input type="text" placeholder="Full Name" name="FullNameDB3" required value="<?php echo $participant[2]->namaPeserta; ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4">
                                    <label>Gender :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="radio" name="genderDB3" id="male" value="M" <?php if($participant[2]->gender == "M"){echo "checked";} ?>/>
                                    <label for="male" style="padding-left: 5px !important;">Male</label>
                                    <input type="radio" name="genderDB3" id="female" value="F" style="margin-left: 10px;" <?php if($participant[2]->gender == "F"){echo "checked";} ?>/>
                                    <label for="female" style="padding-left: 5px !important;">Female</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 20px;">
                                    <label>Phone Number :</label>
                                </div>
                                <div class="col-md-8" style="margin-top: 10px;">
                                    <input type="number" placeholder="Phone Number" name="phoneDB3" required value="<?php echo $participant[2]->telpPeserta; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 10px;">
                                    <label>Date of Birth :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="date" placeholder="Date of Birth" name="dobDB3" required value="<?php echo $participant[2]->DOB; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 5px;">
                                    <label>Email :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="email" placeholder="Email" name="emailDB3" required value="<?php echo $participant[2]->emailPeserta; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4">
                                    <label>Vegetarian :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="radio" name="vegetarianDB3" id="vegetarian" value="1" <?php if($participant[2]->vege == true){echo "checked";} ?>/>
                                    <label for="vegetarian" style="padding-left: 5px !important;">Vegetarian</label>
                                    <input type="radio" name="vegetarianDB3" id="nonVegetarian" value="0" style="margin-left: 10px;" <?php if($participant[2]->vege == false){echo "checked";} ?>/>
                                    <label for="nonVegetarian" style="padding-left: 5px !important;">Non Vegetarian</label>
                                </div>
                            </div>
                        </div>
                    </div> 
                </div> 
                <div class="tab-pane" id="team">
                    <div class="col-md-12" style="margin-left: -30px;">
                        <select class="form-control" name="teamName">
                            <option value="A" <?php if($participant[0]->tim == "A"){echo "selected";} ?>>Team A</option>
                            <option value="B" <?php if($participant[0]->tim == "B"){echo "selected";} ?>>Team B</option>
                            <option value="C" <?php if($participant[0]->tim == "C"){echo "selected";} ?>>Team C</option>
                            <option value="D" <?php if($participant[0]->tim == "D"){echo "selected";} ?>>Team D</option>
                            <option value="E" <?php if($participant[0]->tim == "E"){echo "selected";} ?>>Team E</option>
                            <option value="F" <?php if($participant[0]->tim == "F"){echo "selected";} ?>>Team F</option>
                            <option value="G" <?php if($participant[0]->tim == "G"){echo "selected";} ?>>Team G</option>
                            <option value="H" <?php if($participant[0]->tim == "H"){echo "selected";} ?>>Team H</option>
                         </select>
                    </div>
                    <div class="button-side btn-form" style="margin-top: 20px; margin-left: 45px;">        
                        <button type="submit" id="submit" class="btn-system btn-large">Edit</button>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
    </form>
</div>

