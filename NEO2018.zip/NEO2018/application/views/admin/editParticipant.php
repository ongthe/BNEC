<div class="page-banner no-subtitle">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="white">Participant Data</h1>
            </div>
        </div>
    </div>
</div>

<div class="container call-action call-action-boxed call-action-style1 no-descripton clearfix" id="regis-Participant">
    <form role="form" class="contact-form" id="confirm-form" method="post" action="<?php echo base_url().'Admin/editParticipant1/'.$participant->IDTransaksi; ?>">
        
        <div class="checkbox">
            <div class="col-md-3" style="margin-top: 7.5px;">
                <label>Full Name :</label>
            </div>
            <div class="col-md-9">                
               <input type="text" placeholder="Full Name" name="fullName" required value="<?php echo $participant->namaPeserta; ?>">
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3">
                    <label>Gender :</label>
                </div>
                <div class="col-md-9">
                    <input type="radio" name="gender" id="male" value="M" required <?php if($participant->gender=='M'){echo 'checked';} ?>/>
                    <label for="male" style="padding-left: 5px !important;">Male</label>
                    <input type="radio" name="gender" id="female" value="F" style="margin-left: 10px;" required <?php if($participant->gender=='F'){echo 'checked';} ?>/>
                    <label for="female" style="padding-left: 5px !important;">Female</label>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3" style="margin-top: 20px;">
                    <label>Phone Number :</label>
                </div>
                <div class="col-md-9" style="margin-top: 10px;">
                    <input type="number" placeholder="Phone Number" name="phone" required value="<?php echo $participant->telpPeserta; ?>">
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3" style="margin-top: 10px;">
                    <label>Date of Birth :</label>
                </div>
                <div class="col-md-9">
                    <input type="date" placeholder="Date of Birth" name="dob" required value="<?php echo $participant->DOB; ?>">
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3" style="margin-top: 5px;">
                    <label>Email :</label>
                </div>
                <div class="col-md-9">
                    <input type="email" placeholder="Email" name="email" required value="<?php echo $participant->emailPeserta; ?>">
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3">
                    <label>Vegetarian :</label>
                </div>
                <div class="col-md-9">
                    <input type="radio" name="vegetarian" id="vegetarian" value="1" <?php if($participant->vege==true){echo 'checked';} ?>/>
                    <label for="vegetarian" style="padding-left: 5px !important;">Vegetarian</label>
                    <input type="radio" name="vegetarian" id="nonVegetarian" value="0" style="margin-left: 10px;" <?php if($participant->vege==false){echo 'checked';} ?>/>
                    <label for="nonVegetarian" style="padding-left: 5px !important;">Non Vegetarian</label>
                </div>
            </div>
        </div>
        <div class="button-side btn-form" style="margin-top: 20px;">        
            <button type="submit" id="submit" class="btn-system btn-large">Edit</button>
        </div>
    </form>
</div>

