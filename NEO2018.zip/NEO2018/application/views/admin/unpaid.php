<div class="page-banner no-subtitle" style="margin-top:8em;">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="white">Unpaid Schools</h1>
			</div>
		</div>
	</div>
</div>

<div class="container" id="invoices-list">
	<table class="table" id="tblShow">
		<thead>
			<tr>
				<th>No.</th>
				<th>SMA Name</th>
				<th>Transaction Number</th>
				<th>Fields</th>
			</tr>
		</thead>
		<tbody>			
	    	<?php for($i=0;$i<count($allShs);$i++){ ?>
		    <tr>
				<td><?php echo $i+1; ?></td>
				<td><?php echo $allShs[$i]->shs_name; ?></td>
				<td><?php echo $allShs[$i]->IDTransaksi; ?></td>
				<td><?php echo $allShs[$i]->namaKompetisi; ?></td>
			</tr>
			<?php } ?>
		</tbody>
	</table>
</div>