<div class="page-banner no-subtitle" style="margin-top:8em;">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="white">All Registered Schools</h1>
			</div>
		</div>
	</div>
</div>

<div class="container" id="invoices-list">
	<table class="table" id="tblShow">
		<thead>
			<tr>
				<th>No.</th>
				<th>SMA Name</th>
				<th>SMA Address</th>
				<th>SMA Email</th>
		        <th>CP Name</th>
		        <th>CP Telp</th>
			</tr>
		</thead>
		<tbody>			
			<?php for($i=0;$i<count($allShs);$i++){ ?>
		    <tr class='clickable-row' data-href='<?php echo base_url().'Admin/viewParticipant/'.$allShs[$i]->shs_id;?>'>		    	
				<td><?php echo $i+1; ?></td>
				<td><?php echo $allShs[$i]->shs_name; ?></td>
				<td><?php echo $allShs[$i]->shs_address; ?></td>
				<td><?php echo $allShs[$i]->shs_email; ?></td>
				<td><?php echo $allShs[$i]->cp_name; ?></td>
				<td><?php echo $allShs[$i]->cp_phone; ?></td>
			</tr>
			<?php } ?>
		</tbody>
	</table>
</div>