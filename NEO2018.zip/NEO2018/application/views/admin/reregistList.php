<?php 
    if($this->session->flashdata('editParticipant') != '') {
     ?>
        <div class="alert alert-success alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('editParticipant'); ?></strong>
        </div>
    <?php
     }

    if($this->session->flashdata('failedEditParticipant') != '') {
     ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('failedEditParticipant'); ?></strong>
        </div>
    <?php
     }
     if($this->session->flashdata('attendSuccess') != '') {
     ?>
        <div class="alert alert-success alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('attendSuccess'); ?></strong>
        </div>
    <?php
     }
     if($this->session->flashdata('attendFailed') != '') {
     ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('attendFailed'); ?></strong>
        </div>
    <?php
     }
?>

<div class="page-banner no-subtitle" style="margin-top:8em;">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <h1 class="white">Reregistration List</h1>
   </div>
  </div>
 </div>
</div>

<div class="container" id="invoices-list">
 <table class="table" id="tblShow">
  <thead>
   <tr>
    <th>No.</th>
    <th>SMA Name</th>
    <th>Participant Name</th>
 
    <th>Attend</th>
    
    <th>Edit</th>
   </tr>
  </thead>
  <tbody> 
      <?php for($i=0;$i<count($participant);$i++){ 
?>
       <tr>
     <td><?php echo $i+1; ?></td>
     <td><?php echo $participant[$i]->namaSMA; ?></td>
     <td><?php echo $participant[$i]->namaPeserta; ?></td>    
     <td>
      <?php if(!is_null($participant[$i]->attend)){ ?>
            Attend
            <?php }else{
        ?>
        <a class="btn-system btn-large" href="<?php echo base_url().'/Admin/attend/'.$participant[$i]->IDPeserta; ?>">Attend</a>
        <?php
      } ?>
      </td> 
     <td>
      <a class="btn-system btn-large" href="<?php echo base_url().'/Admin/editParticipant/'.$participant[$i]->IDPeserta; ?>">Edit</a>
     </td>
    </tr>
    <?php } ?>
  </tbody>
 </table>
</div>