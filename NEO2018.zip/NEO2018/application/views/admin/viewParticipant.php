<div class="page-banner no-subtitle" style="margin-top:8em;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="white">All Registered Participants</h1>
            </div>
        </div>
    </div>
</div>

<div class="container" id="invoices-list">
    <table class="table" id="tblShow">
        <thead>
            <tr>
                <th>No.</th>
                <th>School Name</th>
                <th>Participant Name</th>
                <th>Participant Phone</th>
                <th>Participant DOB</th>
                <th>Gender</th>
                <th>Participant Email</th>                
                <th>Vege</th>
                <th>IDTransaksi</th>
                <th>Nama Kompetisi</th>
                <th>Tim</th>
            </tr>
        </thead>
        <tbody>         
            <?php for($i=0;$i<count($participant);$i++){ ?>
            <tr>                
                <td><?php echo $i+1; ?></td>
                <td><?php echo $participant[$i]->namaSMA; ?></td>
                <td><?php echo $participant[$i]->namaPeserta; ?></td>
                <td><?php echo $participant[$i]->telpPeserta; ?></td>
                <td><?php echo $participant[$i]->DOB; ?></td>
                <td><?php if($participant[$i]->gender == 'F') { echo "Female"; } else { echo "Male"; } ?></td>
                <td><?php echo $participant[$i]->emailPeserta; ?></td>
                <td><?php if(($participant[$i]->vege) == 0) { echo "Non Vege"; } else { echo "Vege"; } ?></td>
                <td><?php echo $participant[$i]->IDTransaksi; ?></td>
                <td><?php echo $participant[$i]->namaKompetisi; ?></td>
                <td><?php echo $participant[$i]->tim; ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>