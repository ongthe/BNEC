<?php 
    if($this->session->flashdata('confirmAdmin') != '') {
     ?>
        <div class="alert alert-success alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('confirmAdmin'); ?></strong>
        </div>
    <?php
     }

    if($this->session->flashdata('failedConfirmAdmin') != '') {
     ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('failedConfirmAdmin'); ?></strong>
        </div>
    <?php
     }
?>

<div class="page-banner no-subtitle" style="margin-top:8em;">
 <div class="container">
  <div class="row">
   <div class="col-md-12">
    <h1 class="white">Confirm Payment (Registered Fields by Schools)</h1>
   </div>
  </div>
 </div>
</div>

<div class="container" id="invoices-list">
 <table class="table" id="tblShow">
  <thead>
   <tr>
          <th style="text-align: center;">No.</th>
          <th style="text-align: center;">SMA Name</th>
          <th style="text-align: center;">CP Name</th>
          <th style="text-align: center;">Transfer Date</th>
          <th style="text-align: center;">Account Number</th>
          <th style="text-align: center;">Atas Nama</th>
          <th style="text-align: center;">Transaction Number</th>
          <th style="text-align: center;">Nominal</th>
          <th style="text-align: center;">Fields</th>
          <th style="text-align: center;">Mandatory Paid Price</th>
          <th style="text-align: center;">Confirm</th>
   </tr>
  </thead>
  <tbody> 
      <?php for($i=0;$i<count($allShs);$i++){ 
      //if($i==0){?>
       <tr>
     <td style="text-align: center;"><?php echo $i+1; ?></td>
     <td><?php echo $allShs[$i]->shs_name; ?></td>
     <td><?php echo $allShs[$i]->cp_name; ?></td>
     <td style="text-align: center;"><?php if($allShs[$i]->transfer_date == '0000-00-00') { echo '-'; } else { echo $allShs[$i]->transfer_date; } ?></td>
     <td><?php echo $allShs[$i]->no_rek; ?></td>
     <td><?php echo $allShs[$i]->atas_nama; ?></td>
     <td style="text-align: center;"><?php echo $allShs[$i]->transaction_id; ?></td>
     <td style="text-align: center;"><?php echo $allShs[$i]->nominal; ?></td>
     <td style="text-align: center;"><?php echo $allShs[$i]->competition_name; ?></td>      
     <td style="text-align: center;"><?php echo $allShs[$i]->competition_price; ?></td>      
     <td>
      <a class="btn-system btn-large" href="<?php echo base_url().'/Admin/adminConfirm/'.$allShs[$i]->transaction_id; ?>">Confirm</a>
     </td>
    </tr>
    <?php }?>
  </tbody>
 </table>
</div>