<div class="page-banner no-subtitle">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="white">Accommodation</h1>
			</div>
		</div>
	</div>
</div>

<div class="container">
	<h2 style="text-align: center; font-family: helvetica; font-weight: bold;" class="classic-title">Recommended Hotel</h2>
	<div class="col-md-12" style='margin-bottom: 30px;'>
		<h4 class="classic-title col-lg-12 col-md-12 col-sm-12 col-xs-12'"><span style="font-size:1.3em;">Starlet Hotel Gading Serpong</span></h4>
		<img class="img-responsive acom-img-front" src="<?php echo base_url(); ?>assets/2017/images/accommodation/starlet/Front.jpg">
		<p>During the period of The 2017 National English Olympics, participants are recommended to stay at Starlet Hotel Gading Serpong. Located at Gading Serpong Area with about 4 kilometre away from BINUS University Alam Sutera, BINUS Square offers a great mobility to and from campus. It provides free shuttle services for its residents, meaning that participants will not have to worry about transportation.</p>
		<div class='acom-det col-lg-5 col-md-5 col-sm-12 col-xs-12'>
			<p>Address : </p>
			<p>Jl. Raya Serpong No.37A,</p>
			<p>Pakualam, Serpong Utara,</p>
			<p>Tangerang Selatan, Banten 15320</p>
			<br>
			<p>Distance : </p>
			<p>To BINUS Alam Sutera : 5.3 km [<a href="https://www.google.co.id/maps/dir/Starlet+Hotel+Serpong,+Jl.+Raya+Serpong+No.37A,+Pakualam,+North+Serpong,+South+Tangerang+City,+Banten+15320/Binus+Alam+Sutra,+Tangerang+City,+Banten/@-6.2303902,106.6368359,15z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69fbe4d24de719:0xa8705fc670e81bab!2m2!1d106.641132!2d-6.230525!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262" target='_blank'>directions &#x226B;</a>]</p>
			<p>From BINUS Alam Sutera : 3.4 km [<a href="https://www.google.co.id/maps/dir/Binus+Alam+Sutra,+Tangerang+City,+Banten/Starlet+Hotel+Serpong,+Jl.+Raya+Serpong+No.37A,+Pakualam,+North+Serpong,+South+Tangerang+City,+Banten+15320/@-6.2284962,106.634112,15z/data=!4m13!4m12!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262!1m5!1m1!1s0x2e69fbe4d24de719:0xa8705fc670e81bab!2m2!1d106.641132!2d-6.230525" target='_blank'>directions &#x226B;</a>]</p>
			<p>Phone : (021) 53132222</p>
			<p>Nearby attractions : </p>
			<ol class="ol-number">
				<li>Summarecon Mall Serpong - 3.0 km [<a href="https://www.google.co.id/maps/dir/Starlet+Hotel+Serpong,+Jl.+Raya+Serpong+No.37A,+Pakualam,+North+Serpong,+South+Tangerang+City,+Banten+15320/Summarecon+Mal+Serpong,+West+Pakulonan,+Tangerang,+Banten/@-6.2360774,106.6259633,15z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69fbe4d24de719:0xa8705fc670e81bab!2m2!1d106.641132!2d-6.230525!1m5!1m1!1s0x2e69fc0a0f186afd:0x355ee4742c69b52c!2m2!1d106.6281724!2d-6.2412123" target='_blank'>directions &#x226B;</a>] </li>
				<li>Flavor Bliss - 3.5 km [<a href="https://www.google.co.id/maps/dir/Starlet+Hotel+Serpong,+Jl.+Raya+Serpong+No.37A,+Pakualam,+North+Serpong,+South+Tangerang+City,+Banten+15320/Flavor+Bliss+Sutra+Utama,+Pakulonan,+Serpong+Utara,+Kota+Tangerang+Selatan,+Banten/@-6.2346229,106.6368933,15z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69fbe4d24de719:0xa8705fc670e81bab!2m2!1d106.641132!2d-6.230525!1m5!1m1!1s0x2e69fbeaadfe76e3:0x507fa75d4d2e9636!2m2!1d106.6517336!2d-6.2428934" target='_blank'>directions &#x226B;</a>] </li>
				<li>OMNI Hospitals - 3.7 km [<a href="https://www.google.co.id/maps/dir/Starlet+Hotel+Serpong,+Jl.+Raya+Serpong+No.37A,+Pakualam,+North+Serpong,+South+Tangerang+City,+Banten+15320/OMNI+Hospitals+Alam+Sutera,+Pakulonan,+South+Tangerang+City,+Banten/@-6.2357701,106.6368416,15z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69fbe4d24de719:0xa8705fc670e81bab!2m2!1d106.641132!2d-6.230525!1m5!1m1!1s0x2e69fb95158c1e85:0x831b2975d8e5a793!2m2!1d106.6510832!2d-6.2449115" target='_blank'>directions &#x226B;</a>] </li>
				<li>Living World - 4.9 km [<a href="https://www.google.co.id/maps/dir/Starlet+Hotel+Serpong,+Jl.+Raya+Serpong+No.37A,+Pakualam,+North+Serpong,+South+Tangerang+City,+Banten+15320/Living+World,+Pakulonan,+South+Tangerang+City,+Banten/@-6.2357342,106.6430246,14.79z/data=!4m19!4m18!1m10!1m1!1s0x2e69fbe4d24de719:0xa8705fc670e81bab!2m2!1d106.641132!2d-6.230525!3m4!1m2!1d106.6530477!2d-6.2432984!3s0x2e69fbc000ec4fc3:0x1885f50e01f53b78!1m5!1m1!1s0x2e69fbbfddc33093:0x12783cb2371fb070!2m2!1d106.6535924!2d-6.2444311!3e0" target='_blank'>directions &#x226B;</a>] </li>
			</ol>
			<p>Facility : </p>
			<table class='acom-table'>
				<tr><td></td><td><i class='fa fa-wifi'></i></td><td>Wifi</td></tr>
				<tr><td></td><td><i class='fa fa-arrows-v'></i></td><td>Elevator</td></tr>
				<tr><td></td><td><b>P</b></td><td>Parking Lot</td></tr>
			</table>
			<br>
			<!-- <a href="https://www.traveloka.com/en/hotel/indonesia/starlet-hotel-gading-serpong-3000010010258?spec=30-11-2017.4-12-2017.3.1.HOTEL.3000010010258.Starlet%20Hotel%20Gading%20Serpong,%20Tangerang,%20Banten,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a> -->
			
			
		</div>
		<div class='acom-map col-lg-7 col-md-7 col-sm-12 col-xs-12'>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15864.978285158193!2d106.63498330795615!3d-6.2314550281953345!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69fbe4d24de719%3A0xa8705fc670e81bab!2sStarlet+Hotel+Serpong!5e0!3m2!1sen!2sid!4v1505059170194" width="1000px" height="900" frameborder="0" style="border:0; margin-top: -150px; margin-left: -300px;" allowfullscreen></iframe>
		</div>
		<p class='clear-float'>&nbsp;</p>
		<div 'acom-room col-lg-12 col-md-12 col-sm-12 col-xs-12'>
			<p align="justify" class="acom-room-title col-lg-12 col-md-12 col-sm-12 col-xs-12'">Superior Room</p>
			<!-- Slider -->
			<div class='acom-slider col-lg-7 col-md-7 col-sm-6 col-xs-12'>
				<div id="main-slideA1" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA1" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA1" data-slide-to="1"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/starlet/bedroom.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/starlet/bathroom.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA1" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA1" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
			<div class='acom-room-detail col-lg-5 col-md-5 col-sm-6 col-xs-12'>
				<p class='acom-price'>Price : <span class='acom-price-value'>IDR 288,000</span>/day</p>
				<p><sub>Price is based on Traveloka (Sep 19<sup>th</sup>), tax included</sub></p>
				<br>
				<p>Size : 15 m<sup>2</sup></p>
				<p>Max people : 2</p>
				<p>Bed type : 2 single beds</p>
				<p>Room Amenities :</p>
				<table class='acom-table'>
					<tr><td></td><td><i class='fa fa-snowflake-o'></i></td><td>Air Conditioner</td></tr>
					<tr><td></td><td><i class='fa fa-tint'></i></td><td>Complimentary bottled water</td></tr>
					<tr><td></td><td><i class='fa fa-exclamation-circle'></i></td><td>Non smoking room</td></tr>
				</table>
				<br><br>
				<!-- <a href="https://www.traveloka.com/en/hotel/indonesia/starlet-hotel-gading-serpong-3000010010258?spec=30-11-2017.4-12-2017.3.1.HOTEL.3000010010258.Starlet%20Hotel%20Gading%20Serpong,%20Tangerang,%20Banten,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a> -->
				
			</div>
			<p class='clear-float'>&nbsp;</p>
		</div>

	</div>
	<hr />
	<hr /> 
	<h2 style="text-align: center; font-family: helvetica; font-weight: bold;" class="classic-title">Other Hotels</h2>

	<div class="col-md-12" style='margin-bottom: 30px;'>
		<h4 class="classic-title col-lg-12 col-md-12 col-sm-12 col-xs-12'"><span style="font-size:1.3em;">Nite & Day Residences</span></h4>
		<img class="img-responsive acom-img-front" src="<?php echo base_url(); ?>assets/2017/images/accommodation/niteday/Front.jpg">
		<div class='acom-det col-lg-5 col-md-5 col-sm-12 col-xs-12'>
			<p>Address : </p>
			<p>Jl. Alam Utama, Kav. 10 No 1,</p>
			<p>Alam Sutera, Serpong Utara, Pakulonan,</p>
			<p>Tangerang, Banten 15325</p>
			<br>
			<p>Distance : </p>
			<p>To BINUS Alam Sutera : 2.8 km [<a href="https://www.google.co.id/maps/dir/Nite+%26+Day+Residence+Alam+Sutera,+Jl.+Alam+Utama,+Alam+Sutera+Town+Center+(astc),+Kav.+10+No+1,+Alam+Sutera,+Serpong+Utara,+Pakulonan,+Tangerang,+Banten+15325/Binus+Alam+Sutra,+Tangerang+City,+Banten/@-6.2316273,106.6419428,15z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69fbc028ee068f:0x590e35399c805fdf!2m2!1d106.653131!2d-6.241536!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262" target='_blank'>directions &#x226B;</a>]</p>
			<p>From BINUS Alam Sutera : 2.8 km [<a href="https://www.google.co.id/maps/dir/Binus+Alam+Sutra,+Tangerang+City,+Banten/Nite+%26+Day+Residence+Alam+Sutera,+Jl.+Alam+Utama,+Alam+Sutera+Town+Center+(astc),+Kav.+10+No+1,+Alam+Sutera,+Serpong+Utara,+Pakulonan,+Tangerang,+Banten+15325/@-6.2316273,106.6421074,15z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262!1m5!1m1!1s0x2e69fbc028ee068f:0x590e35399c805fdf!2m2!1d106.653131!2d-6.241536" target='_blank'>directions &#x226B;</a>]</p>
			<p>Phone : (021) 29779291</p>
			<p>Nearby attractions : </p>
			<ol class="ol-number">
				<li>Living World - 500 m [<a href="https://www.google.co.id/maps/dir/Nite+%26+Day+Residence+Alam+Sutera,+Jl.+Alam+Utama,+Alam+Sutera+Town+Center+(astc),+Kav.+10+No+1,+Alam+Sutera,+Serpong+Utara,+Pakulonan,+Tangerang,+Banten+15325/Living+World,+Pakulonan,+South+Tangerang+City,+Banten/@-6.242866,106.6518826,18z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fbc028ee068f:0x590e35399c805fdf!2m2!1d106.653131!2d-6.241536!1m5!1m1!1s0x2e69fbbfddc33093:0x12783cb2371fb070!2m2!1d106.6535924!2d-6.2444311!3e2" target='_blank'>directions &#x226B;</a>] </li>
				<li>OMNI Hospitals - 550 m [<a href="https://www.google.co.id/maps/dir/Nite+%26+Day+Residence+Alam+Sutera,+Jl.+Alam+Utama,+Alam+Sutera+Town+Center+(astc),+Kav.+10+No+1,+Alam+Sutera,+Serpong+Utara,+Pakulonan,+Tangerang,+Banten+15325/OMNI+Hospitals+Alam+Sutera,+Pakulonan,+South+Tangerang+City,+Banten/@-6.2431062,106.6498618,17z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fbc028ee068f:0x590e35399c805fdf!2m2!1d106.653131!2d-6.241536!1m5!1m1!1s0x2e69fb95158c1e85:0x831b2975d8e5a793!2m2!1d106.6510832!2d-6.2449115!3e2" target='_blank'>directions &#x226B;</a>] </li>
				<li>Flavor Bliss - 650 m [<a href="https://www.google.co.id/maps/dir/Nite+%26+Day+Residence+Alam+Sutera,+Jl.+Alam+Utama,+Alam+Sutera+Town+Center+(astc),+Kav.+10+No+1,+Alam+Sutera,+Serpong+Utara,+Pakulonan,+Tangerang,+Banten+15325/Flavor+Bliss+Sutra+Utama,+South+Tangerang+City,+Banten/@-6.2416961,106.6510614,18z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fbc028ee068f:0x590e35399c805fdf!2m2!1d106.653131!2d-6.241536!1m5!1m1!1s0x2e69fbeaadfe76e3:0x507fa75d4d2e9636!2m2!1d106.6517336!2d-6.2428934!3e2" target='_blank'>directions &#x226B;</a>] </li>
				<li>Mall @ Alam Sutera - 2.6 km [<a href="https://www.google.co.id/maps/dir/Nite+%26+Day+Residence+Alam+Sutera,+Pakulonan,+South+Tangerang+City,+Banten/Mall+@+Alam+Sutera,+East+Panunggangan,+Tangerang+City,+Banten/@-6.2314635,106.6453853,15z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69fbc028ee068f:0x590e35399c805fdf!2m2!1d106.653131!2d-6.241536!1m5!1m1!1s0x2e69f9600c2fdad1:0x34e189d2689a3517!2m2!1d106.6536289!2d-6.2225471" target='_blank'>directions &#x226B;</a>] </li>
			</ol>
			<p>Facility : </p>
			<table class='acom-table'>
				<tr><td></td><td><i class='fa fa-wifi'></i></td><td>Wifi</td></tr>
				<tr><td></td><td><i class='fa fa-cutlery'></i></td><td>Restaurant</td></tr>
				<tr><td></td><td><i class='fa fa-arrows-v'></i></td><td>Elevator</td></tr>
				<tr><td></td><td><b>P</b></td><td>Parking Lot</td></tr>
			</table>
			<br><br>
			<a href="https://www.traveloka.com/en/hotel/indonesia/nite--day-residence---alam-sutera-tangerang-3000010018637?spec=30-11-2017.4-12-2017.3.1.HOTEL.3000010018637.Nite%20&%20Day%20Residence%20-%20Alam%20Sutera,%20Tangerang,%20South%20Tangerang,%20Banten,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
		</div>
		<div class='acom-map col-lg-7 col-md-7 col-sm-12 col-xs-12'>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d39977.17273400275!2d106.63633925497881!3d-6.232333222429517!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69fbc028ee068f%3A0x590e35399c805fdf!2sNite+%26+Day+Residence+Alam+Sutera!5e0!3m2!1sen!2sid!4v1505050408244" width="600px" height="1550" frameborder="0" style="border:0; margin-top: -300px;" allowfullscreen></iframe>
		</div>
		<p class='clear-float'>&nbsp;</p>
		<div class='acom-room col-lg-12 col-md-12 col-sm-12 col-xs-12'>
			<p align="justify" class="acom-room-title col-lg-12 col-md-12 col-sm-12 col-xs-12'">Sunny Day Twin Room Only</p>
			
			<div class='acom-slider col-lg-7 col-md-7 col-sm-6 col-xs-12'>
				<div id="main-slideA21" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA21" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA21" data-slide-to="1"></li>
						<li data-target="#main-slideA21" data-slide-to="2"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/niteday/bedroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/niteday/bathroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/niteday/bathroom2.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA21" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA21" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
			<div class='acom-room-detail col-lg-5 col-md-5 col-sm-6 col-xs-12'>
				<p class='acom-price'>Price : <span class='acom-price-value'>IDR 331,667</span>/day*</p>
				<p><sub>Price is based on Traveloka (Sep 18<sup>th</sup>), tax included</sub></p>
				<br>
				<p>Size : 18 m<sup>2</sup></p>
				<p>Max people : 2</p>
				<p>Bed type : 2 single beds</p>
				<p>Room Amenities :</p>
				<table class='acom-table'>
					<tr><td></td><td><i class='fa fa-snowflake-o'></i></td><td>Air Conditioner</td></tr>
					<tr><td></td><td><i class='fa fa-television'></i></td><td>Television</td></tr>
					<tr><td></td><td><i class='fa fa-tint'></i></td><td>Complimentary bottled water</td></tr>
					<tr><td></td><td><i class='fa fa-check'></i></td><td>Desk</td></tr>
				</table>
				<br><br>
				<a href="https://www.traveloka.com/en/hotel/indonesia/nite--day-residence---alam-sutera-tangerang-3000010018637?spec=30-11-2017.4-12-2017.3.1.HOTEL.3000010018637.Nite%20&%20Day%20Residence%20-%20Alam%20Sutera,%20Tangerang,%20South%20Tangerang,%20Banten,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
			</div>
		</div>
		<p class='clear-float'>&nbsp;</p>
		<!-- <p class='clear-float'>&nbsp;</p><p class='clear'>&nbsp;</p><br><br> -->
		<div class='acom-room col-lg-12 col-md-12 col-sm-12 col-xs-12'>
			<p align="justify" class="acom-room-title col-lg-12 col-md-12 col-sm-12 col-xs-12'">Sunny Day Double Room Only</p>
			<!-- Slider -->
			<div class='acom-slider col-lg-7 col-md-7 col-sm-6 col-xs-12'>
				<div id="main-slideA22" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA22" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA22" data-slide-to="1"></li>
						<li data-target="#main-slideA22" data-slide-to="2"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/niteday/bedroom2.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/niteday/bathroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/niteday/bathroom2.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA22" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA22" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
			<div class='acom-room-detail col-lg-5 col-md-5 col-sm-6 col-xs-12'>
				<p class='acom-price'>Price : <span class='acom-price-value'>IDR 355,000</span>/day*</p>
				<p><sub>Price is based on Traveloka (Sep 18<sup>th</sup>), tax included</sub></p>
				<br>
				<p>Size : 18 m<sup>2</sup></p>
				<p>Max people : 2</p>
				<p>Bed type : Queen bed</p>
				<p>Room Amenities :</p>
				<table class='acom-table'>
					<tr><td></td><td><i class='fa fa-snowflake-o'></i></td><td>Air Conditioner</td></tr>
					<tr><td></td><td><i class='fa fa-television'></i></td><td>Television</td></tr>
					<tr><td></td><td><i class='fa fa-tint'></i></td><td>Complimentary bottled water</td></tr>
					<tr><td></td><td><i class='fa fa-check'></i></td><td>Desk</td></tr>
				</table>
				<br><br>
				<a href="https://www.traveloka.com/en/hotel/indonesia/nite--day-residence---alam-sutera-tangerang-3000010018637?spec=30-11-2017.4-12-2017.3.1.HOTEL.3000010018637.Nite%20&%20Day%20Residence%20-%20Alam%20Sutera,%20Tangerang,%20South%20Tangerang,%20Banten,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
			</div>
			<p class='clear-float'>&nbsp;</p>
		</div>
	</div>
	<div class="col-md-12" style='margin-bottom: 30px;'>
		<h4 class="classic-title col-lg-12 col-md-12 col-sm-12 col-xs-12'"><span style="font-size:1.3em;">Soll Marina Hotel</span></h4>
		<div class='acom-slider-a'>
				<div id="main-slideA3" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA3" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA3" data-slide-to="1"></li>
						<li data-target="#main-slideA3" data-slide-to="2"></li>
						<li data-target="#main-slideA3" data-slide-to="3"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/sollmarina/Front.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/sollmarina/lobby1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/sollmarina/lobby2.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/sollmarina/lobby3.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA3" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA3" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
		<div class='acom-det col-lg-5 col-md-5 col-sm-12 col-xs-12'>
			<p>Address : </p>
			<p>Jl. Raya Serpong KM 7,</p>
			<p>Pakualam, Serpong Utara, Pakulonan,</p>
			<p>Tangerang Selatan, Banten 15326</p>
			<br>
			<p>Distance : </p>
			<p>To BINUS Alam Sutera : 3.6 km [<a href="https://www.google.co.id/maps/dir/Soll+Marina+Hotel,+Jalan+Raya+Serpong+KM.7,+Pakualam,+Serpong+Utara,+Pakualam,+Serpong+Utara,+Kota+Tangerang+Selatan,+Banten+15326/Binus+Alam+Sutra,+Tangerang+City,+Banten/@-6.2303689,106.6368359,15z/data=!4m13!4m12!1m5!1m1!1s0x2e69fbeb47ea5803:0xd98b4e187671ec96!2m2!1d106.6448248!2d-6.2366954!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262" target='_blank'>directions &#x226B;</a>]</p>
			<p>From BINUS Alam Sutera : 3.0 km [<a href="https://www.google.co.id/maps/dir/Binus+Alam+Sutra,+Tangerang+City,+Banten/Soll+Marina+Hotel,+Jalan+Raya+Serpong+KM.7,+Pakualam,+Serpong+Utara,+Pakualam,+Serpong+Utara,+Kota+Tangerang+Selatan,+Banten+15326/@-6.2336172,106.6312915,14z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262!1m5!1m1!1s0x2e69fbeb47ea5803:0xd98b4e187671ec96!2m2!1d106.6448248!2d-6.2366954" target='_blank'>directions &#x226B;</a>]</p>
			<p>Phone : (021) 29667766</p>
			<p>Nearby attractions : </p>
			<ol class="ol-number">
				<li>Flavor Bliss - 1.9 km [<a href="https://www.google.co.id/maps/dir/Soll+Marina+Hotel,+Jalan+Raya+Serpong+KM.7,+Pakualam,+Serpong+Utara,+Pakualam,+Serpong+Utara,+Kota+Tangerang+Selatan,+Banten+15326/Flavor+Bliss+Sutra+Utama,+South+Tangerang+City,+Banten/@-6.2390553,106.6443668,16z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69fbeb47ea5803:0xd98b4e187671ec96!2m2!1d106.6448248!2d-6.2366954!1m5!1m1!1s0x2e69fbeaadfe76e3:0x507fa75d4d2e9636!2m2!1d106.6517336!2d-6.2428934" target='_blank'>directions &#x226B;</a>] </li>
				<li>OMNI Hospitals - 2.1 km [<a href="https://www.google.co.id/maps/dir/Soll+Marina+Hotel,+Jalan+Raya+Serpong+KM.7,+Pakualam,+Serpong+Utara,+Pakualam,+Serpong+Utara,+Kota+Tangerang+Selatan,+Banten+15326/OMNI+Hospitals+Alam+Sutera,+Pakulonan,+South+Tangerang+City,+Banten/@-6.2402024,106.6443151,16z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69fbeb47ea5803:0xd98b4e187671ec96!2m2!1d106.6448248!2d-6.2366954!1m5!1m1!1s0x2e69fb95158c1e85:0x831b2975d8e5a793!2m2!1d106.6510832!2d-6.2449115" target='_blank'>directions &#x226B;</a>] </li>
				<li>Living World - 3.3 km [<a href="https://www.google.co.id/maps/dir/Soll+Marina+Hotel,+Jalan+Raya+Serpong+KM.7,+Pakualam,+Serpong+Utara,+Pakualam,+Serpong+Utara,+Kota+Tangerang+Selatan,+Banten+15326/Living+World,+Pakulonan,+South+Tangerang+City,+Banten/@-6.2400931,106.6465299,16z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69fbeb47ea5803:0xd98b4e187671ec96!2m2!1d106.6448248!2d-6.2366954!1m5!1m1!1s0x2e69fbbfddc33093:0x12783cb2371fb070!2m2!1d106.6535924!2d-6.2444311" target='_blank'>directions &#x226B;</a>] </li>
				<li>Summarecon Mal Serpong - 3.8 km [<a href="https://www.google.co.id/maps/dir/Soll+Marina+Hotel,+Jalan+Raya+Serpong+KM.7,+Pakualam,+Serpong+Utara,+Pakualam,+Serpong+Utara,+Kota+Tangerang+Selatan,+Banten+15326/Summarecon+Mal+Serpong,+West+Pakulonan,+Tangerang,+Banten/@-6.236056,106.6280963,15z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69fbeb47ea5803:0xd98b4e187671ec96!2m2!1d106.6448248!2d-6.2366954!1m5!1m1!1s0x2e69fc0a0f186afd:0x355ee4742c69b52c!2m2!1d106.6281724!2d-6.2412123" target='_blank'>directions &#x226B;</a>] </li>
			</ol>
			<p>Facility : </p>
			<table class='acom-table'>
				<tr><td></td><td><i class='fa fa-wifi'></i></td><td>Wifi</td></tr>
				<tr><td></td><td><i class='fa fa-cutlery'></i></td><td>Restaurant</td></tr>
				<tr><td></td><td><i class='fa fa-arrows-v'></i></td><td>Elevator</td></tr>
				<tr><td></td><td><b>P</b></td><td>Parking Lot</td></tr>
			</table>
			<br><br>
			<a href="https://www.traveloka.com/en/hotel/indonesia/soll-marina-hotel-serpong-3000010000865?spec=30-11-2017.4-12-2017.3.1.HOTEL.3000010000865.Soll%20Marina%20Hotel%20Serpong,%20Serpong,%20South%20Tangerang,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
		</div>
		<div class='acom-map col-lg-7 col-md-7 col-sm-12 col-xs-12'>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d26681.510434311313!2d106.6347938791405!3d-6.233348659840432!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69fbeb47ea5803%3A0xd98b4e187671ec96!2sSoll+Marina+Hotel!5e0!3m2!1sen!2sid!4v1505078394716" width="600px" height="1150" frameborder="0" style="border:0; margin-top: -200px;" allowfullscreen></iframe>
		</div>
		<p class='clear-float'>&nbsp;</p>
		<div class='acom-room col-lg-12 col-md-12 col-sm-12 col-xs-12'>
			<p align="justify" class="acom-room-title col-lg-12 col-md-12 col-sm-12 col-xs-12'">Superior Room</p>
			
			<div class='acom-slider col-lg-7 col-md-7 col-sm-6 col-xs-12'>
				<div id="main-slideA31" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA31" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA31" data-slide-to="1"></li>
						<li data-target="#main-slideA31" data-slide-to="2"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/sollmarina/bedroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/sollmarina/bedroom2.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/sollmarina/bathroom.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA31" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA31" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
			<div class='acom-room-detail col-lg-5 col-md-5 col-sm-6 col-xs-12'>
				<p class='acom-price'>Price : <span class='acom-price-value'>IDR 528,000</span>/day*</p>
				<p><sub>Price is based on Traveloka (Sep 18<sup>th</sup>), tax included</sub></p>
				<br>
				<p>Size : 21 m<sup>2</sup></p>
				<p>Max people : 2</p>
				<p>Bed type : 2 single beds / 1 double bed</p>
				<p>Room Amenities :</p>
				<table class='acom-table'>
					<tr><td></td><td><i class='fa fa-snowflake-o'></i></td><td>Air Conditioner</td></tr>
					<tr><td></td><td><i class='fa fa-television'></i></td><td>Television</td></tr>
					<tr><td></td><td><i class='fa fa-tint'></i></td><td>Complimentary bottled water</td></tr>
					<tr><td></td><td><i class='fa fa-coffee'></i></td><td>Coffee / tea maker</td></tr>
					<tr><td></td><td><i class='fa fa-check'></i></td><td>Desk</td></tr>
					<tr><td></td><td><i class='fa fa-cutlery'></i></td><td>Breakfast (+ IDR 60,000)</td></tr>
				</table>
				<br><br>
				<a href="https://www.traveloka.com/en/hotel/indonesia/soll-marina-hotel-serpong-3000010000865?spec=30-11-2017.4-12-2017.3.1.HOTEL.3000010000865.Soll%20Marina%20Hotel%20Serpong,%20Serpong,%20South%20Tangerang,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
			</div>
			<p class='clear-float'>&nbsp;</p><br>
		</div>
		<p class='clear-float'>&nbsp;</p>
		<!-- <p class='clear-float'>&nbsp;</p><p class='clear'>&nbsp;</p><br><br> -->
	</div>
	<div class="col-md-12" style='margin-bottom: 30px;'>
		<h4 class="classic-title col-lg-12 col-md-12 col-sm-12 col-xs-12'"><span style="font-size:1.3em;">Mercure Serpong Alam Sutera</span></h4>
		<!-- <img class="img-responsive acom-img-front" src="<?php echo base_url(); ?>assets/2017/images/accommodation/niteday/Front.jpg"> -->
		<div class='acom-slider-a'>
				<div id="main-slideA4" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA4" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA4" data-slide-to="1"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/mercure/Front.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/mercure/lobby.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA4" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA4" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
		<div class='acom-det col-lg-5 col-md-5 col-sm-12 col-xs-12'>
			<p>Address : </p>
			<p>Jalan Alam Sutera Boulevard Kav. 23,</p>
			<p>Pakulonan, Serpong Utara,</p>
			<p>Tangerang Selatan, Banten 15325</p>
			<br>
			<p>Distance : </p>
			<p>To BINUS Alam Sutera : 3.7 km [<a href="https://www.google.co.id/maps/dir/Mercure+Serpong+Alam+Sutera,+Jalan+Alam+Sutera+Boulevard+Kav.+23,+Serpong,+Pakulonan,+Serpong+Utara,+Kota+Tangerang+Selatan,+Banten+15325/Binus+Alam+Sutra,+Tangerang+City,+Banten/@-6.2336277,106.6331879,14z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69fbeaa8af0e8b:0x52d53c7ba853d65!2m2!1d106.65192!2d-6.244555!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262" target='_blank'>directions &#x226B;</a>]</p>
			<p>From BINUS Alam Sutera : 3.2 km [<a href="https://www.google.co.id/maps/dir/Binus+Alam+Sutra,+Tangerang+City,+Banten/Mercure+Serpong+Alam+Sutera,+Jalan+Alam+Sutera+Boulevard+Kav.+23,+Serpong,+Pakulonan,+Serpong+Utara,+Kota+Tangerang+Selatan,+Banten+15325/@-6.2332017,106.6451533,15z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262!1m5!1m1!1s0x2e69fbeaa8af0e8b:0x52d53c7ba853d65!2m2!1d106.65192!2d-6.244555" target='_blank'>directions &#x226B;</a>]</p>
			<p>Phone : (021) 29668668</p>
			<p>Nearby attractions : </p>
			<ol class="ol-number">
				<li>OMNI Hospitals - 110 m (Adjacent) [<a href="https://www.google.co.id/maps/dir/Mercure+Serpong+Alam+Sutera,+Jalan+Alam+Sutera+Boulevard+Kav.+23,+Serpong,+Pakulonan,+Serpong+Utara,+Kota+Tangerang+Selatan,+Banten+15325/OMNI+Hospitals+Alam+Sutera,+Pakulonan,+South+Tangerang+City,+Banten/@-6.2446463,106.649249,17z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fbeaa8af0e8b:0x52d53c7ba853d65!2m2!1d106.65192!2d-6.244555!1m5!1m1!1s0x2e69fb95158c1e85:0x831b2975d8e5a793!2m2!1d106.6510832!2d-6.2449115!3e2" target='_blank'>directions &#x226B;</a>] </li>
				<li>Flavor Bliss - 200 m [<a href="https://www.google.co.id/maps/dir/Mercure+Serpong+Alam+Sutera,+Jalan+Alam+Sutera+Boulevard+Kav.+23,+Serpong,+Pakulonan,+Serpong+Utara,+Kota+Tangerang+Selatan,+Banten+15325/Flavor+Bliss+Sutra+Utama,+South+Tangerang+City,+Banten/@-6.2425181,106.6497545,17z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fbeaa8af0e8b:0x52d53c7ba853d65!2m2!1d106.65192!2d-6.244555!1m5!1m1!1s0x2e69fbeaadfe76e3:0x507fa75d4d2e9636!2m2!1d106.6517336!2d-6.2428934!3e2" target='_blank'>directions &#x226B;</a>] </li>
				<li>Living World - 400 m [<a href="https://www.google.co.id/maps/dir/Mercure+Serpong+Alam+Sutera,+Jalan+Alam+Sutera+Boulevard+Kav.+23,+Serpong,+Pakulonan,+Serpong+Utara,+Kota+Tangerang+Selatan,+Banten+15325/Living+World,+Pakulonan,+South+Tangerang+City,+Banten/@-6.2440662,106.6502695,17z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fbeaa8af0e8b:0x52d53c7ba853d65!2m2!1d106.65192!2d-6.244555!1m5!1m1!1s0x2e69fbbfddc33093:0x12783cb2371fb070!2m2!1d106.6535924!2d-6.2444311!3e2" target='_blank'>directions &#x226B;</a>] </li>
				<li>Mall @ Alam Sutera - 3.5 km [<a href="https://www.google.co.id/maps/dir/Mercure+Serpong+Alam+Sutera,+Jalan+Alam+Sutera+Boulevard+Kav.+23,+Serpong,+Pakulonan,+Serpong+Utara,+Kota+Tangerang+Selatan,+Banten+15325/Mall+@+Alam+Sutera,+East+Panunggangan,+Tangerang+City,+Banten/@-6.2335857,106.6350484,14z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fbeaa8af0e8b:0x52d53c7ba853d65!2m2!1d106.65192!2d-6.244555!1m5!1m1!1s0x2e69f9600c2fdad1:0x34e189d2689a3517!2m2!1d106.6536289!2d-6.2225471!3e0" target='_blank'>directions &#x226B;</a>] </li>
			</ol>
			<p>Facility : </p>
			<table class='acom-table'>
				<tr><td></td><td><i class='fa fa-wifi'></i></td><td>Wifi</td></tr>
				<tr><td></td><td><i class='fa fa-cutlery'></i></td><td>Restaurant</td></tr>
				<tr><td></td><td><i class='fa fa-arrows-v'></i></td><td>Elevator</td></tr>
				<tr><td></td><td><b>P</b></td><td>Parking Lot</td></tr>
			</table>
			<br><br>
			<a href="https://www.traveloka.com/en/hotel/indonesia/mercure-serpong-alam-sutera-488136?spec=30-11-2017.4-12-2017.3.1.HOTEL.488136.Mercure%20Serpong%20Alam%20Sutera,%20South%20Tangerang,%20Banten,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
		</div>
		<div class='acom-map col-lg-7 col-md-7 col-sm-12 col-xs-12'>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d44872.42646492323!2d106.63360431126362!3d-6.237397902202762!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x52d53c7ba853d65!2sMercure+Serpong+Alam+Sutera!5e0!3m2!1sen!2sid!4v1505084456809" width="600px" height="1350" frameborder="0" style="border:0; margin-top: -300px;" allowfullscreen></iframe>
		</div>
		<p class='clear-float'>&nbsp;</p>
		<div class='acom-room col-lg-12 col-md-12 col-sm-12 col-xs-12'>
			<p align="justify" class="acom-room-title col-lg-12 col-md-12 col-sm-12 col-xs-12'">Superior Room, 1 Queen Bed</p>
			
			<div class='acom-slider col-lg-7 col-md-7 col-sm-6 col-xs-12'>
				<div id="main-slideA41" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA41" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA41" data-slide-to="1"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/mercure/bedroom2.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/mercure/bathroom.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA41" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA41" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
			<div class='acom-room-detail col-lg-5 col-md-5 col-sm-6 col-xs-12'>
				<p class='acom-price'>Price : <span class='acom-price-value'>IDR 880,880</span>/day*</p>
				<p><sub>Price is based on Traveloka (Sep 18<sup>th</sup>), tax included</sub></p>
				<br>
				<p>Size : 26 m<sup>2</sup></p>
				<p>Max people : 2</p>
				<p>Bed type : 1 queen bed</p>
				<p>Room Amenities :</p>
				<table class='acom-table'>
					<tr><td></td><td><i class='fa fa-snowflake-o'></i></td><td>Air Conditioner</td></tr>
					<tr><td></td><td><i class='fa fa-television'></i></td><td>Television</td></tr>
					<tr><td></td><td><i class='fa fa-tint'></i></td><td>Complimentary bottled water</td></tr>
					<tr><td></td><td><i class='fa fa-coffee'></i></td><td>Coffee / tea maker</td></tr>
					<tr><td></td><td><i class='fa fa-check'></i></td><td>Desk</td></tr>
					<tr><td></td><td><i class='fa fa-glass'></i></td><td>Minibar</td></tr>
					<tr><td></td><td><img src="<?php echo base_url(); ?>assets/2017/images/ico/cloth.png" width="15"></td><td>Ironing</td></tr>
				</table>
				<br><br>
				<a href="https://www.traveloka.com/en/hotel/indonesia/mercure-serpong-alam-sutera-488136?spec=30-11-2017.4-12-2017.3.1.HOTEL.488136.Mercure%20Serpong%20Alam%20Sutera,%20South%20Tangerang,%20Banten,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
			</div>
			<p class='clear-float'>&nbsp;</p><br>
		</div>
		<p class='clear-float'>&nbsp;</p>
		<div class='acom-room col-lg-12 col-md-12 col-sm-12 col-xs-12'>
			<p align="justify" class="acom-room-title col-lg-12 col-md-12 col-sm-12 col-xs-12'">Superior Room, 2 Twin Beds</p>
			
			<div class='acom-slider col-lg-7 col-md-7 col-sm-6 col-xs-12'>
				<div id="main-slideA42" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA42" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA42" data-slide-to="1"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/mercure/bedroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/mercure/bathroom.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA42" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA42" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
			<div class='acom-room-detail col-lg-5 col-md-5 col-sm-6 col-xs-12'>
				<p class='acom-price'>Price : <span class='acom-price-value'>IDR 880,880</span>/day*</p>
				<p><sub>Price is based on Traveloka (Sep 18<sup>th</sup>), tax included</sub></p>
				<br>
				<p>Size : 26 m<sup>2</sup></p>
				<p>Max people : 2</p>
				<p>Bed type : 2 single beds</p>
				<p>Room Amenities :</p>
				<table class='acom-table'>
					<tr><td></td><td><i class='fa fa-snowflake-o'></i></td><td>Air Conditioner</td></tr>
					<tr><td></td><td><i class='fa fa-television'></i></td><td>Television</td></tr>
					<tr><td></td><td><i class='fa fa-tint'></i></td><td>Complimentary bottled water</td></tr>
					<tr><td></td><td><i class='fa fa-coffee'></i></td><td>Coffee / tea maker</td></tr>
					<tr><td></td><td><i class='fa fa-check'></i></td><td>Desk</td></tr>
					<tr><td></td><td><i class='fa fa-glass'></i></td><td>Minibar</td></tr>
					<tr><td></td><td><img src="<?php echo base_url(); ?>assets/2017/images/ico/cloth.png" width="15"></td><td>Ironing</td></tr>
				</table>
				<br><br>
				<a href="https://www.traveloka.com/en/hotel/indonesia/mercure-serpong-alam-sutera-488136?spec=30-11-2017.4-12-2017.3.1.HOTEL.488136.Mercure%20Serpong%20Alam%20Sutera,%20South%20Tangerang,%20Banten,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
			</div>
			<p class='clear-float'>&nbsp;</p><br>
		</div>
		<p class='clear-float'>&nbsp;</p>
	</div>
	<div class="col-md-12" style='margin-bottom: 30px;'>
		<h4 class="classic-title col-lg-12 col-md-12 col-sm-12 col-xs-12'"><span style="font-size:1.3em;">Ara Hotel Gading Serpong</span></h4>
		<img class="img-responsive acom-img-front" src="<?php echo base_url(); ?>assets/2017/images/accommodation/ara/Front.jpg">
		<div class='acom-det col-lg-5 col-md-5 col-sm-12 col-xs-12'>
			<p>Address : </p>
			<p>Ara Center, Jalan CBD Barat Kav. 1,</p>
			<p>Gading Serpong, Curug Sangereng, Kelapa Dua,</p>
			<p>Tangerang, Banten 15836</p>
			<br>
			<p>Distance : </p>
			<p>To BINUS Alam Sutera : 9.4 km [<a href="https://www.google.co.id/maps/dir/Ara+Hotel+Gading+Serpong,+Ara+Center,+Jalan+CBD+Barat+Kav.+1,+Gading+Serpong,+Curug+Sangereng,+Kelapa+Dua,+Curug+Sangereng,+Klp.+Dua,+Tangerang,+Banten+15836/Binus+Alam+Sutra,+Tangerang+City,+Banten/@-6.231061,106.6039234,13z/data=!4m14!4m13!1m5!1m1!1s0x2decf7524e0d41b7:0xcfe11dbbb2a1bb57!2m2!1d106.6246574!2d-6.2444952!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262!3e0" target='_blank'>directions &#x226B;</a>]</p>
			<p>From BINUS Alam Sutera : 5.4 km [<a href="https://www.google.co.id/maps/dir/Binus+Alam+Sutra,+Tangerang+City,+Banten/Ara+Hotel+Gading+Serpong,+Ara+Center,+Jalan+CBD+Barat+Kav.+1,+Gading+Serpong,+Curug+Sangereng,+Kelapa+Dua,+Curug+Sangereng,+Klp.+Dua,+Tangerang,+Banten+15836/@-6.2334568,106.6274645,15z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262!1m5!1m1!1s0x2decf7524e0d41b7:0xcfe11dbbb2a1bb57!2m2!1d106.6246574!2d-6.2444952!3e0" target='_blank'>directions &#x226B;</a>]</p>
			<p>Phone : (021) 29205999</p>
			<p>Nearby attractions : </p>
			<ol class="ol-number">
				<li>Summarecon Mal Serpong - 900 m [<a href="https://www.google.co.id/maps/dir/Ara+Hotel+Gading+Serpong,+Ara+Center,+Jalan+CBD+Barat+Kav.+1,+Gading+Serpong,+Curug+Sangereng,+Kelapa+Dua,+Curug+Sangereng,+Klp.+Dua,+Tangerang,+Banten+15836/Summarecon+Mal+Serpong,+West+Pakulonan,+Tangerang,+Banten/@-6.2441443,106.624577,17z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2decf7524e0d41b7:0xcfe11dbbb2a1bb57!2m2!1d106.6246574!2d-6.2444952!1m5!1m1!1s0x2e69fc0a0f186afd:0x355ee4742c69b52c!2m2!1d106.6281724!2d-6.2412123!3e0?hl=en" target='_blank'>directions &#x226B;</a>] </li>
				<li>Bethsaida Hospitals - 1.4 km [<a href="https://www.google.co.id/maps/dir/Ara+Hotel+Gading+Serpong,+Ara+Center,+Jalan+CBD+Barat+Kav.+1,+Gading+Serpong,+Curug+Sangereng,+Kelapa+Dua,+Curug+Sangereng,+Klp.+Dua,+Tangerang,+Banten+15836/Bethsaida+Hospitals,+Curug+Sangereng,+Tangerang,+Banten/@-6.249628,106.61977,16z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2decf7524e0d41b7:0xcfe11dbbb2a1bb57!2m2!1d106.6246574!2d-6.2444952!1m5!1m1!1s0x2e69fc7a082d017f:0x212d083e3a5e9c49!2m2!1d106.6225519!2d-6.2547608?hl=en" target='_blank'>directions &#x226B;</a>] </li>
				<li>Scientia Square Park & Summ. Digital Center - 2.1 km [<a href="https://www.google.co.id/maps/dir/Ara+Hotel+Gading+Serpong,+Ara+Center,+Jalan+CBD+Barat+Kav.+1,+Gading+Serpong,+Curug+Sangereng,+Kelapa+Dua,+Curug+Sangereng,+Klp.+Dua,+Tangerang,+Banten+15836/Scientia+Square+Park,+Curug+Sangereng,+Tangerang,+Banten/@-6.2509104,106.6125484,15z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2decf7524e0d41b7:0xcfe11dbbb2a1bb57!2m2!1d106.6246574!2d-6.2444952!1m5!1m1!1s0x2e69fc651e649223:0x3b96f2ef67285cd9!2m2!1d106.6165475!2d-6.2571747?hl=en" target='_blank'>directions &#x226B;</a>] </li>
				<li>Supermall Karawaci & Benton Junction - 4.8 km [<a href="https://www.google.co.id/maps/dir/Ara+Hotel+Gading+Serpong,+Ara+Center,+Jalan+CBD+Barat+Kav.+1,+Gading+Serpong,+Curug+Sangereng,+Kelapa+Dua,+Curug+Sangereng,+Klp.+Dua,+Tangerang,+Banten+15836/-6.228425,106.6070695/@-6.2351414,106.608824,15z/data=!4m9!4m8!1m5!1m1!1s0x2decf7524e0d41b7:0xcfe11dbbb2a1bb57!2m2!1d106.6246574!2d-6.2444952!1m0!3e0?hl=en" target='_blank'>directions &#x226B;</a>] </li>
			</ol>
			<p>Facility : </p>
			<table class='acom-table'>
				<tr><td></td><td><i class='fa fa-wifi'></i></td><td>Wifi</td></tr>
				<tr><td></td><td><i class='fa fa-cutlery'></i></td><td>Restaurant</td></tr>
				<tr><td></td><td><i class='fa fa-arrows-v'></i></td><td>Elevator</td></tr>
				<tr><td></td><td><b>P</b></td><td>Parking Lot</td></tr>
			</table>
			<br><br>
			<a href="https://www.traveloka.com/en/hotel/indonesia/ara-hotel-gading-serpong-535842?spec=30-11-2017.4-12-2017.3.1.HOTEL.535842.Ara%20Hotel%20Gading%20Serpong,%20Tangerang,%20Banten,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
		</div>
		<div class='acom-map col-lg-7 col-md-7 col-sm-12 col-xs-12'>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d44872.81316120882!2d106.62398976866884!3d-6.232878628898228!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2decf7524e0d41b7%3A0xcfe11dbbb2a1bb57!2sAra+Hotel+Gading+Serpong!5e0!3m2!1sen!2sid!4v1505086955514" width="900px" height="1350" frameborder="0" style="border:0; margin-top: -300px; margin-left: -300px" allowfullscreen></iframe>
		</div>
		<p class='clear-float'>&nbsp;</p>
		<div class='acom-room col-lg-12 col-md-12 col-sm-12 col-xs-12'>
			<p align="justify" class="acom-room-title col-lg-12 col-md-12 col-sm-12 col-xs-12'">Superior Room</p>
			
			<div class='acom-slider col-lg-7 col-md-7 col-sm-6 col-xs-12'>
				<div id="main-slideA51" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA51" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA51" data-slide-to="1"></li>
						<li data-target="#main-slideA51" data-slide-to="2"></li>
						<li data-target="#main-slideA51" data-slide-to="3"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/ara/bedroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/ara/bedroom2.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/ara/bathroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/ara/bathroom2.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA51" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA51" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
			<div class='acom-room-detail col-lg-5 col-md-5 col-sm-6 col-xs-12'>
				<p class='acom-price'>Price : <span class='acom-price-value'>IDR 559,500</span>/day*</p>
				<p><sub>Price is based on Traveloka (Sep 18<sup>th</sup>), tax included</sub></p>
				<br>
				<p>Size : 24 m<sup>2</sup></p>
				<p>Max people : 2</p>
				<p>Bed type : 1 double bed or 2 single beds</p>
				<p>Room Amenities :</p>
				<table class='acom-table'>
					<tr><td></td><td><i class='fa fa-snowflake-o'></i></td><td>Air Conditioner</td></tr>
					<tr><td></td><td><i class='fa fa-television'></i></td><td>Television</td></tr>
					<tr><td></td><td><i class='fa fa-snowflake-o'></i></td><td>Refrigerator</td></tr>
					<tr><td></td><td><i class='fa fa-check'></i></td><td>Desk</td></tr>
					<tr><td></td><td><i class='fa fa-glass'></i></td><td>Minibar</td></tr>
				</table>
				<br><br>
				<a href="https://www.traveloka.com/en/hotel/indonesia/ara-hotel-gading-serpong-535842?spec=30-11-2017.4-12-2017.3.1.HOTEL.535842.Ara%20Hotel%20Gading%20Serpong,%20Tangerang,%20Banten,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
			</div>
			<p class='clear-float'>&nbsp;</p><br>
		</div>
		<p class='clear-float'>&nbsp;</p>
	</div>
	<div class="col-md-12" style='margin-bottom: 30px;'>
		<h4 class="classic-title col-lg-12 col-md-12 col-sm-12 col-xs-12'"><span style="font-size:1.3em;">Benito Residence</span></h4>
		<!-- <img class="img-responsive acom-img-front" src="<?php echo base_url(); ?>assets/2017/images/accommodation/niteday/Front.jpg"> -->
		<div class='acom-slider-a'>
				<div id="main-slideA6" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA6" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA6" data-slide-to="1"></li>
						<li data-target="#main-slideA6" data-slide-to="2"></li>
						<li data-target="#main-slideA6" data-slide-to="3"></li>
						<li data-target="#main-slideA6" data-slide-to="4"></li>
						<li data-target="#main-slideA6" data-slide-to="5"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/benito/Front1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/benito/Front2.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/benito/lobby1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/benito/lobby2.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/benito/lobby3.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/benito/parking.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA6" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA6" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
		<div class='acom-det col-lg-5 col-md-5 col-sm-12 col-xs-12'>
			<p>Address : </p>
			<p>JL. Wates, No. 3 Km. 8,</p>
			<p>Pondok Jagung, Serpong, Pd. Jagung,</p>
			<p>Tangerang Selatan, Banten 15326</p>
			<br>
			<p>Distance : </p>
			<p>To BINUS Alam Sutera : 9.4 km [<a href="https://www.google.co.id/maps/dir/Benito+Residence,+JL.+Wates,+No.+3+Km.+8,+Pondok+Jagung,+Serpong+(Dekat+Omni+Alam+Sutera),+Pd.+Jagung,+Tangerang,+Kota+Tangerang+Selatan,+Banten+15326/Binus+Alam+Sutra,+Tangerang+City,+Banten/@-6.2433879,106.6361702,13.5z/data=!4m13!4m12!1m5!1m1!1s0x2e69fb97ee27d435:0xe2bd71b1aa1d3059!2m2!1d106.6519113!2d-6.2532366!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262" target='_blank'>directions &#x226B;</a>]</p>
			<p>From BINUS Alam Sutera : 4.4 km [<a href="https://www.google.co.id/maps/dir/Binus+Alam+Sutra,+Tangerang+City,+Banten/Benito+Residence,+JL.+Wates,+No.+3+Km.+8,+Pondok+Jagung,+Serpong+(Dekat+Omni+Alam+Sutera),+Pd.+Jagung,+Tangerang,+Kota+Tangerang+Selatan,+Banten+15326/@-6.2374669,106.6312915,14z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262!1m5!1m1!1s0x2e69fb97ee27d435:0xe2bd71b1aa1d3059!2m2!1d106.6519113!2d-6.2532366" target='_blank'>directions &#x226B;</a>]</p>
			<p>Phone : (+62) 818-0656-5190</p>
			<p>Nearby attractions : </p>
			<ol class="ol-number">
				<li>OMNI Hospitals - 6.8 km [<a href="https://www.google.co.id/maps/dir/Benito+Residence,+JL.+Wates,+No.+3+Km.+8,+Pondok+Jagung,+Serpong+(Dekat+Omni+Alam+Sutera),+Pd.+Jagung,+Tangerang,+Kota+Tangerang+Selatan,+Banten+15326/OMNI+Hospitals+Alam+Sutera,+Pakulonan,+South+Tangerang+City,+Banten/@-6.258658,106.635688,14z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69fb97ee27d435:0xe2bd71b1aa1d3059!2m2!1d106.6519113!2d-6.2532366!1m5!1m1!1s0x2e69fb95158c1e85:0x831b2975d8e5a793!2m2!1d106.6510832!2d-6.2449115" target='_blank'>directions &#x226B;</a>] </li>
				<li>Flavor Bliss - 7.2 km [<a href="https://www.google.co.id/maps/dir/Benito+Residence,+JL.+Wates,+No.+3+Km.+8,+Pondok+Jagung,+Serpong+(Dekat+Omni+Alam+Sutera),+Pd.+Jagung,+Tangerang,+Kota+Tangerang+Selatan,+Banten+15326/Flavor+Bliss+Sutra+Utama,+South+Tangerang+City,+Banten/@-6.2570628,106.6346417,14z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69fb97ee27d435:0xe2bd71b1aa1d3059!2m2!1d106.6519113!2d-6.2532366!1m5!1m1!1s0x2e69fbeaadfe76e3:0x507fa75d4d2e9636!2m2!1d106.6517336!2d-6.2428934" target='_blank'>directions &#x226B;</a>] </li>
				<li>Living World - 8.0 km [<a href="https://www.google.co.id/maps/dir/Benito+Residence,+JL.+Wates,+No.+3+Km.+8,+Pondok+Jagung,+Serpong+(Dekat+Omni+Alam+Sutera),+Pd.+Jagung,+Tangerang,+Kota+Tangerang+Selatan,+Banten+15326/Living+World,+Pakulonan,+South+Tangerang+City,+Banten/@-6.2569196,106.6357922,14z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69fb97ee27d435:0xe2bd71b1aa1d3059!2m2!1d106.6519113!2d-6.2532366!1m5!1m1!1s0x2e69fbbfddc33093:0x12783cb2371fb070!2m2!1d106.6535924!2d-6.2444311" target='_blank'>directions &#x226B;</a>] </li>
				<li>&AElig;ON Mall BSD City - 9.4 km [<a href="https://www.google.co.id/maps/dir/Benito+Residence,+JL.+Wates,+No.+3+Km.+8,+Pondok+Jagung,+Serpong+(Dekat+Omni+Alam+Sutera),+Pd.+Jagung,+Tangerang,+Kota+Tangerang+Selatan,+Banten+15326/AEON+Mall+BSD+City,+Sampora,+Tangerang,+Banten/@-6.2828147,106.6194228,13z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69fb97ee27d435:0xe2bd71b1aa1d3059!2m2!1d106.6519113!2d-6.2532366!1m5!1m1!1s0x2e69faad1d959e1f:0xa02052b7ba6ab859!2m2!1d106.6438457!2d-6.3165983" target='_blank'>directions &#x226B;</a>] </li>
			</ol>
			<p>Facility : </p>
			<table class='acom-table'>
				<tr><td></td><td><i class='fa fa-wifi'></i></td><td>Wifi</td></tr>
				<tr><td></td><td><i class='fa fa-cutlery'></i></td><td>Restaurant</td></tr>
				<tr><td></td><td><b>P</b></td><td>Parking Lot</td></tr>
			</table>
			<br><br>
			<a href="https://www.traveloka.com/en/hotel/indonesia/benito-residence---bsd-city-3000010002563?spec=30-11-2017.4-12-2017.3.1.HOTEL.3000010002563.Benito%20Residence%20-%20BSD%20City,%20Serpong,%20South%20Tangerang,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
		</div>
		<div class='acom-map col-lg-7 col-md-7 col-sm-12 col-xs-12'>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d46186.7669929193!2d106.63251260757706!3d-6.243315456062507!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69fb97ee27d435%3A0xe2bd71b1aa1d3059!2sBenito+Residence!5e0!3m2!1sen!2sid!4v1505091881696" width="600px" height="1350" frameborder="0" style="border:0; margin-top: -250px;" allowfullscreen></iframe>
		</div>
		<p class='clear-float'>&nbsp;</p>
		<div class='acom-room col-lg-12 col-md-12 col-sm-12 col-xs-12'>
			<p align="justify" class="acom-room-title col-lg-12 col-md-12 col-sm-12 col-xs-12'">Executive Twin Bed</p>
			
			<div class='acom-slider col-lg-7 col-md-7 col-sm-6 col-xs-12'>
				<div id="main-slideA61" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA61" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA61" data-slide-to="1"></li>
						<li data-target="#main-slideA61" data-slide-to="2"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/benito/bedroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/benito/bathroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/benito/bathroom2.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA61" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA61" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
			<div class='acom-room-detail col-lg-5 col-md-5 col-sm-6 col-xs-12'>
				<p class='acom-price'>Price : <span class='acom-price-value'>IDR 240,000</span>/day*</p>
				<p><sub>Price is based on Traveloka (Sep 18<sup>th</sup>), tax included</sub></p>
				<br>
				<p>Size : 16 m<sup>2</sup></p>
				<p>Max people : 2</p>
				<p>Bed type : 2 single beds</p>
				<p>Room Amenities :</p>
				<table class='acom-table'>
					<tr><td></td><td><i class='fa fa-snowflake-o'></i></td><td>Air Conditioner</td></tr>
					<tr><td></td><td><i class='fa fa-television'></i></td><td>Television</td></tr>
					<tr><td></td><td><i class='fa fa-tint'></i></td><td>Complimentary bottled water</td></tr>
					<tr><td></td><td><i class='fa fa-check'></i></td><td>Desk</td></tr>
				</table>
				<br><br>
				<a href="https://www.traveloka.com/en/hotel/indonesia/benito-residence---bsd-city-3000010002563?spec=30-11-2017.4-12-2017.3.1.HOTEL.3000010002563.Benito%20Residence%20-%20BSD%20City,%20Serpong,%20South%20Tangerang,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
			</div>
			<p class='clear-float'>&nbsp;</p><br>
		</div>
		<p class='clear-float'>&nbsp;</p>
		<div class='acom-room col-lg-12 col-md-12 col-sm-12 col-xs-12'>
			<p align="justify" class="acom-room-title col-lg-12 col-md-12 col-sm-12 col-xs-12'">Executive Double Beds</p>
			
			<div class='acom-slider col-lg-7 col-md-7 col-sm-6 col-xs-12'>
				<div id="main-slideA62" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA62" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA62" data-slide-to="1"></li>
						<li data-target="#main-slideA62" data-slide-to="2"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/benito/bedroom2.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/benito/bathroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/benito/bathroom2.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA62" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA62" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
			<div class='acom-room-detail col-lg-5 col-md-5 col-sm-6 col-xs-12'>
				<p class='acom-price'>Price : <span class='acom-price-value'>IDR 240,000</span>/day*</p>
				<p><sub>Price is based on Traveloka (Sep 18<sup>th</sup>), tax included</sub></p>
				<br>
				<p>Size : 16 m<sup>2</sup></p>
				<p>Max people : 2</p>
				<p>Bed type : 1 double bed</p>
				<p>Room Amenities :</p>
				<table class='acom-table'>
					<tr><td></td><td><i class='fa fa-snowflake-o'></i></td><td>Air Conditioner</td></tr>
					<tr><td></td><td><i class='fa fa-television'></i></td><td>Television</td></tr>
					<tr><td></td><td><i class='fa fa-tint'></i></td><td>Complimentary bottled water</td></tr>
					<tr><td></td><td><i class='fa fa-check'></i></td><td>Desk</td></tr>
				</table>
				<br><br>
				<a href="https://www.traveloka.com/en/hotel/indonesia/benito-residence---bsd-city-3000010002563?spec=30-11-2017.4-12-2017.3.1.HOTEL.3000010002563.Benito%20Residence%20-%20BSD%20City,%20Serpong,%20South%20Tangerang,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
			</div>
			<p class='clear-float'>&nbsp;</p><br>
		</div>
		<p class='clear-float'>&nbsp;</p>
	</div>
	<div class="col-md-12" style='margin-bottom: 30px;'>
		<h4 class="classic-title col-lg-12 col-md-12 col-sm-12 col-xs-12'"><span style="font-size:1.3em;">Fame Hotel</span></h4>
		<!-- <img class="img-responsive acom-img-front" src="<?php echo base_url(); ?>assets/2017/images/accommodation/niteday/Front.jpg"> -->
		<div class='acom-slider-a'>
				<div id="main-slideA7" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA7" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA7" data-slide-to="1"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/fame/Front.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/fame/lobby.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA7" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA7" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
		<div class='acom-det col-lg-5 col-md-5 col-sm-12 col-xs-12'>
			<p>Address : </p>
			<p>Tivoli District Lot 3, Jalan Gading Serpong Boulevard,</p>
			<p>Curug Sangereng, Kelapa Dua,</p>
			<p>Tangerang, Banten 15810</p>
			<br>
			<p>Distance : </p>
			<p>To BINUS Alam Sutera : 10.3 km [<a href="https://www.google.co.id/maps/dir/Fame+Hotel+Gading+Serpong,+Tivoli+District+Lot+3,+Jalan+Gading+Serpong+Boulevard,+Curug+Sangereng,+Kelapa+Dua,+Curug+Sangereng,+Klp.+Dua,+Tangerang,+Banten+15810/Binus+Alam+Sutra,+Tangerang+City,+Banten/@-6.238206,106.6021029,13z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fc7a0c7cf883:0x4858d3d1257ee93c!2m2!1d106.621887!2d-6.25521!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262!3e0" target='_blank'>directions &#x226B;</a>]</p>
			<p>From BINUS Alam Sutera : 6.2 km [<a href="https://www.google.co.id/maps/dir/Binus+Alam+Sutra,+Tangerang+City,+Banten/Fame+Hotel+Gading+Serpong,+Tivoli+District+Lot+3,+Jalan+Gading+Serpong+Boulevard,+Curug+Sangereng,+Kelapa+Dua,+Curug+Sangereng,+Klp.+Dua,+Tangerang,+Banten+15810/@-6.2384536,106.6173866,14z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262!1m5!1m1!1s0x2e69fc7a0c7cf883:0x4858d3d1257ee93c!2m2!1d106.621887!2d-6.25521!3e0" target='_blank'>directions &#x226B;</a>]</p>
			<p>Phone : (021) 29303333</p>
			<p>Nearby attractions : </p>
			<ol class="ol-number">
				<li>Scientia Square Park & Summ. Digital Center - 700 m [<a href="https://www.google.co.id/maps/dir/Fame+Hotel+Gading+Serpong,+Tivoli+District+Lot+3,+Jalan+Gading+Serpong+Boulevard,+Curug+Sangereng,+Kelapa+Dua,+Curug+Sangereng,+Klp.+Dua,+Tangerang,+Banten+15810/Scientia+Square+Park,+Curug+Sangereng,+Tangerang,+Banten/@-6.2561128,106.6168785,17z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fc7a0c7cf883:0x4858d3d1257ee93c!2m2!1d106.621887!2d-6.25521!1m5!1m1!1s0x2e69fc651e649223:0x3b96f2ef67285cd9!2m2!1d106.6165475!2d-6.2571747!3e0" target='_blank'>directions &#x226B;</a>] </li>
				<li>Bethsaida Hospitals - 1.0 km [<a href="https://www.google.co.id/maps/dir/Fame+Hotel+Gading+Serpong,+Tivoli+District+Lot+3,+Jalan+Gading+Serpong+Boulevard,+Curug+Sangereng,+Kelapa+Dua,+Curug+Sangereng,+Klp.+Dua,+Tangerang,+Banten+15810/Bethsaida+Hospitals,+Curug+Sangereng,+Tangerang,+Banten/@-6.2542989,106.6186088,16z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fc7a0c7cf883:0x4858d3d1257ee93c!2m2!1d106.621887!2d-6.25521!1m5!1m1!1s0x2e69fc7a082d017f:0x212d083e3a5e9c49!2m2!1d106.6225519!2d-6.2547608!3e0" target='_blank'>directions &#x226B;</a>] </li>
				<li>Summarecon Mall Serpong 2.1 km [<a href="https://www.google.co.id/maps/dir/Fame+Hotel+Gading+Serpong,+Tivoli+District+Lot+3,+Jalan+Gading+Serpong+Boulevard,+Curug+Sangereng,+Kelapa+Dua,+Curug+Sangereng,+Klp.+Dua,+Tangerang,+Banten+15810/Summarecon+Mal+Serpong,+West+Pakulonan,+Tangerang,+Banten/@-6.2487355,106.6161904,15z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fc7a0c7cf883:0x4858d3d1257ee93c!2m2!1d106.621887!2d-6.25521!1m5!1m1!1s0x2e69fc0a0f186afd:0x355ee4742c69b52c!2m2!1d106.6281724!2d-6.2412123!3e0" target='_blank'>directions &#x226B;</a>] </li>
				<li>Supermall Karawaci & Benton Junction - 5.0 km [<a href="https://www.google.co.id/maps/dir/Fame+Hotel+Gading+Serpong,+Tivoli+District+Lot+3,+Jalan+Gading+Serpong+Boulevard,+Curug+Sangereng,+Kelapa+Dua,+Curug+Sangereng,+Klp.+Dua,+Tangerang,+Banten+15810/Benton+Junction,+Kelapa+Dua,+Tangerang,+Banten/@-6.2436325,106.6022469,14z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fc7a0c7cf883:0x4858d3d1257ee93c!2m2!1d106.621887!2d-6.25521!1m5!1m1!1s0x2e69fc1edaad65ef:0x5b44801423d18cf7!2m2!1d106.6093872!2d-6.2282666!3e0" target='_blank'>directions &#x226B;</a>] </li>
			</ol>
			<p>Facility : </p>
			<table class='acom-table'>
				<tr><td></td><td><i class='fa fa-wifi'></i></td><td>Wifi</td></tr>
				<tr><td></td><td><i class='fa fa-cutlery'></i></td><td>Restaurant</td></tr>
				<tr><td></td><td><i class='fa fa-arrows-v'></i></td><td>Elevator</td></tr>
				<tr><td></td><td><b>P</b></td><td>Parking Lot</td></tr>
			</table>
			<br><br>
			<a href="https://www.traveloka.com/en/hotel/indonesia/fame-hotel-gading-serpong-411999?spec=30-11-2017.4-12-2017.3.1.HOTEL.411999.Fame%20Hotel%20Gading%20Serpong,%20Tangerang,%20Banten,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
		</div>
		<div class='acom-map col-lg-7 col-md-7 col-sm-12 col-xs-12'>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d75466.8844281902!2d106.59883098097895!3d-6.232121077611841!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69fc7a0c7cf883%3A0x4858d3d1257ee93c!2sFame+Hotel+Gading+Serpong!5e0!3m2!1sen!2sid!4v1505098722296" width="1000px" height="1350" frameborder="0" style="border:0; margin-top: -250px; margin-left:-350px;" allowfullscreen></iframe>
		</div>
		<p class='clear-float'>&nbsp;</p>
		<div class='acom-room col-lg-12 col-md-12 col-sm-12 col-xs-12'>
			<p align="justify" class="acom-room-title col-lg-12 col-md-12 col-sm-12 col-xs-12'">Superior Room</p>
			
			<div class='acom-slider col-lg-7 col-md-7 col-sm-6 col-xs-12'>
				<div id="main-slideA71" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA71" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA71" data-slide-to="1"></li>
						<li data-target="#main-slideA71" data-slide-to="2"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/fame/bedroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/fame/bedroom2.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/fame/bathroom.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA71" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA71" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
			<div class='acom-room-detail col-lg-5 col-md-5 col-sm-6 col-xs-12'>
				<p class='acom-price'>Price : <span class='acom-price-value'>IDR 562,142</span>/day*</p>
				<p><sub>Price is based on Traveloka (Sep 18<sup>th</sup>), tax included</sub></p>
				<br>
				<p>Size : 18 m<sup>2</sup></p>
				<p>Max people : 2</p>
				<p>Bed type : 1 double bed or 2 single beds</p>
				<p>Room Amenities :</p>
				<table class='acom-table'>
					<tr><td></td><td><i class='fa fa-snowflake-o'></i></td><td>Air Conditioner</td></tr>
					<tr><td></td><td><i class='fa fa-television'></i></td><td>Television</td></tr>
					<tr><td></td><td><i class='fa fa-check'></i></td><td>Desk</td></tr>
				</table>
				<br><br>
				<a href="https://www.traveloka.com/en/hotel/indonesia/fame-hotel-gading-serpong-411999?spec=30-11-2017.4-12-2017.3.1.HOTEL.411999.Fame%20Hotel%20Gading%20Serpong,%20Tangerang,%20Banten,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
			</div>
			<p class='clear-float'>&nbsp;</p><br>
		</div>
		<p class='clear-float'>&nbsp;</p>
	</div>
	<div class="col-md-12" style='margin-bottom: 30px;'>
		<h4 class="classic-title col-lg-12 col-md-12 col-sm-12 col-xs-12'"><span style="font-size:1.3em;">Ibis Gading Serpong</span></h4>
		<!-- <img class="img-responsive acom-img-front" src="<?php echo base_url(); ?>assets/2017/images/accommodation/niteday/Front.jpg"> -->
		<div class='acom-slider-a'>
				<div id="main-slideA8" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA8" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA8" data-slide-to="1"></li>
						<li data-target="#main-slideA8" data-slide-to="2"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/ibis/Front1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/ibis/Front2.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/ibis/lobby.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA8" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA8" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
		<div class='acom-det col-lg-5 col-md-5 col-sm-12 col-xs-12'>
			<p>Address : </p>
			<p>Jl. Gading Serpong Boulevard Blok M5 No.19,</p>
			<p>Curug Sangereng, Kelapa Dua,</p>
			<p>Tangerang, Banten 15810</p>
			<br>
			<p>Distance : </p>
			<p>To BINUS Alam Sutera : 10.6 km [<a href="https://www.google.co.id/maps/dir/ibis+Gading+Serpong,+Jl.+Gading+Serpong+Boulevard+Blok+M5+No.19,+Curug+Sangereng,+Kelapa+Dua,+Tangerang,+Banten+15810/Binus+Alam+Sutra,+Tangerang+City,+Banten/@-6.231061,106.6043213,13z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fc754018f105:0xdd56c07649e884b9!2m2!1d106.6266016!2d-6.2479086!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262!3e0" target='_blank'>directions &#x226B;</a>]</p>
			<p>From BINUS Alam Sutera : 5.3 km [<a href="https://www.google.co.id/maps/dir/Binus+Alam+Sutra,+Tangerang+City,+Banten/ibis+Gading+Serpong,+Jl.+Gading+Serpong+Boulevard+Blok+M5+No.19,+Curug+Sangereng,+Kelapa+Dua,+Tangerang,+Banten+15810/@-6.2348029,106.6196404,14z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262!1m5!1m1!1s0x2e69fc754018f105:0xdd56c07649e884b9!2m2!1d106.6266016!2d-6.2479086!3e0" target='_blank'>directions &#x226B;</a>]</p>
			<p>Phone : (021) 22220116</p>
			<p>Nearby attractions : </p>
			<ol class="ol-number">
				<li>Bethsaida Hospitals - 950 m [<a href="https://www.google.co.id/maps/dir/ibis+Gading+Serpong,+Jl.+Gading+Serpong+Boulevard+Blok+M5+No.19,+Curug+Sangereng,+Kelapa+Dua,+Tangerang,+Banten+15810/Bethsaida+Hospitals,+Curug+Sangereng,+Tangerang,+Banten/@-6.2512841,106.6198913,16z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fc754018f105:0xdd56c07649e884b9!2m2!1d106.6266016!2d-6.2479086!1m5!1m1!1s0x2e69fc7a082d017f:0x212d083e3a5e9c49!2m2!1d106.6225519!2d-6.2547608!3e0" target='_blank'>directions &#x226B;</a>] </li>
				<li>Summarecon Mal Serpong - 1.6 km [<a href="https://www.google.co.id/maps/dir/ibis+Gading+Serpong,+Jl.+Gading+Serpong+Boulevard+Blok+M5+No.19,+Curug+Sangereng,+Kelapa+Dua,+Tangerang,+Banten+15810/Summarecon+Mal+Serpong,+West+Pakulonan,+Tangerang,+Banten/@-6.2461134,106.6227862,16z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fc754018f105:0xdd56c07649e884b9!2m2!1d106.6266016!2d-6.2479086!1m5!1m1!1s0x2e69fc0a0f186afd:0x355ee4742c69b52c!2m2!1d106.6281724!2d-6.2412123!3e0" target='_blank'>directions &#x226B;</a>] </li>
				<li>Scientia Square Park & Summ. Digital Center - 1.7 km [<a href="https://www.google.co.id/maps/dir/ibis+Gading+Serpong,+Jl.+Gading+Serpong+Boulevard+Blok+M5+No.19,+Curug+Sangereng,+Kelapa+Dua,+Tangerang,+Banten+15810/Scientia+Square+Park,+Curug+Sangereng,+Tangerang,+Banten/@-6.2538941,106.6170471,16z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69fc754018f105:0xdd56c07649e884b9!2m2!1d106.6266016!2d-6.2479086!1m5!1m1!1s0x2e69fc651e649223:0x3b96f2ef67285cd9!2m2!1d106.6165475!2d-6.2571747!3e0" target='_blank'>directions &#x226B;</a>] </li>
				<li>Supermall Karawaci & Benton Junction - 5.8 km [<a href="https://www.google.co.id/maps/dir/ibis+Gading+Serpong,+Jl.+Gading+Serpong+Boulevard+Blok+M5+No.19,+Curug+Sangereng,+Kelapa+Dua,+Tangerang,+Banten+15810/-6.2280837,106.6064355/@-6.2291405,106.6073679,17z/data=!4m9!4m8!1m5!1m1!1s0x2e69fc754018f105:0xdd56c07649e884b9!2m2!1d106.6266016!2d-6.2479086!1m0!3e0" target='_blank'>directions &#x226B;</a>] </li>
			</ol>
			<p>Facility : </p>
			<table class='acom-table'>
				<tr><td></td><td><i class='fa fa-wifi'></i></td><td>Wifi</td></tr>
				<tr><td></td><td><i class='fa fa-cutlery'></i></td><td>Restaurant</td></tr>
				<tr><td></td><td><i class='fa fa-arrows-v'></i></td><td>Elevator</td></tr>
				<tr><td></td><td><b>P</b></td><td>Parking Lot</td></tr>
			</table>
			<br><br>
			<a href="https://www.traveloka.com/en/hotel/indonesia/ibis-gading-serpong-1000000467710?spec=30-11-2017.4-12-2017.3.1.HOTEL.1000000467710.ibis%20gad.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
		</div>
		<div class='acom-map col-lg-7 col-md-7 col-sm-12 col-xs-12'>
			<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d53362.83144662853!2d106.62258129433155!3d-6.235210451542417!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69fc754018f105%3A0xdd56c07649e884b9!2sibis+Gading+Serpong!5e0!3m2!1sen!2sid!4v1505121660281" width="1000px" height="1350" frameborder="0" style="border:0; margin-top: -250px; margin-left: -300px;" allowfullscreen></iframe>
		</div>
		<p class='clear-float'>&nbsp;</p>
		<div class='acom-room col-lg-12 col-md-12 col-sm-12 col-xs-12'>
			<p align="justify" class="acom-room-title col-lg-12 col-md-12 col-sm-12 col-xs-12'">Standard Room, 1 Double Bed</p>
			
			<div class='acom-slider col-lg-7 col-md-7 col-sm-6 col-xs-12'>
				<div id="main-slideA81" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA81" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA81" data-slide-to="1"></li>
						<li data-target="#main-slideA81" data-slide-to="2"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/ibis/bedroom2.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/ibis/bathroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/ibis/bathroom2.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA81" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA81" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
			<div class='acom-room-detail col-lg-5 col-md-5 col-sm-6 col-xs-12'>
				<p class='acom-price'>Price : <span class='acom-price-value'>IDR 445,086</span>/day*</p>
				<p><sub>Price is based on Traveloka (Sep 18<sup>th</sup>), tax included</sub></p>
				<br>
				<p>Size : 17 m<sup>2</sup></p>
				<p>Max people : 2</p>
				<p>Bed type : 1 double bed</p>
				<p>Room Amenities :</p>
				<table class='acom-table'>
					<tr><td></td><td><i class='fa fa-snowflake-o'></i></td><td>Air Conditioner</td></tr>
					<tr><td></td><td><i class='fa fa-television'></i></td><td>Television</td></tr>
					<tr><td></td><td><i class='fa fa-coffee'></i></td><td>Coffee / tea maker</td></tr>
					<tr><td></td><td><i class='fa fa-check'></i></td><td>Desk</td></tr>
					<tr><td></td><td><img src="<?php echo base_url(); ?>assets/2017/images/ico/cloth.png" width="15"></td><td>Ironing</td></tr>
				</table>
				<br><br>
				<a href="https://www.traveloka.com/en/hotel/indonesia/ibis-gading-serpong-1000000467710?spec=30-11-2017.4-12-2017.3.1.HOTEL.1000000467710.ibis%20gad.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
			</div>
			<p class='clear-float'>&nbsp;</p><br>
		</div>
		<p class='clear-float'>&nbsp;</p>
		<div class='acom-room col-lg-12 col-md-12 col-sm-12 col-xs-12'>
			<p align="justify" class="acom-room-title col-lg-12 col-md-12 col-sm-12 col-xs-12'">Standard Room, 2 Twin Beds</p>
			
			<div class='acom-slider col-lg-7 col-md-7 col-sm-6 col-xs-12'>
				<div id="main-slideA82" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA82" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA82" data-slide-to="1"></li>
						<li data-target="#main-slideA82" data-slide-to="2"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/ibis/bedroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/ibis/bathroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/ibis/bathroom2.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA82" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA82" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
			<div class='acom-room-detail col-lg-5 col-md-5 col-sm-6 col-xs-12'>
				<p class='acom-price'>Price : <span class='acom-price-value'>IDR 445,086</span>/day*</p>
				<p><sub>Price is based on Traveloka (Sep 18<sup>th</sup>), tax included</sub></p>
				<br>
				<p>Size : 17 m<sup>2</sup></p>
				<p>Max people : 2</p>
				<p>Bed type : 2 single beds</p>
				<p>Room Amenities :</p>
				<table class='acom-table'>
					<tr><td></td><td><i class='fa fa-snowflake-o'></i></td><td>Air Conditioner</td></tr>
					<tr><td></td><td><i class='fa fa-television'></i></td><td>Television</td></tr>
					<tr><td></td><td><i class='fa fa-coffee'></i></td><td>Coffee / tea maker</td></tr>
					<tr><td></td><td><i class='fa fa-check'></i></td><td>Desk</td></tr>
					<tr><td></td><td><img src="<?php echo base_url(); ?>assets/2017/images/ico/cloth.png" width="15"></td><td>Ironing</td></tr>
				</table>
				<br><br>
				<a href="https://www.traveloka.com/en/hotel/indonesia/ibis-gading-serpong-1000000467710?spec=30-11-2017.4-12-2017.3.1.HOTEL.1000000467710.ibis%20gad.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
			</div>
			<p class='clear-float'>&nbsp;</p><br>
		</div>
		<p class='clear-float'>&nbsp;</p>
	</div>
	<div class="col-md-12" style='margin-bottom: 30px;'>
		<h4 class="classic-title col-lg-12 col-md-12 col-sm-12 col-xs-12'"><span style="font-size:1.3em;">Amaris Hotel Tangerang</span></h4>
		<!-- <img class="img-responsive acom-img-front" src="<?php echo base_url(); ?>assets/2017/images/accommodation/niteday/Front.jpg"> -->
		<div class='acom-slider-a'>
				<div id="main-slideA9" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA9" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA9" data-slide-to="1"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/amaris/Front.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/amaris/lobby.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA9" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA9" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
		<div class='acom-det col-lg-5 col-md-5 col-sm-12 col-xs-12'>
			<p>Address : </p>
			<p>Tangcity Superblok, Jalan Jendral Sudirman No. 1,</p>
			<p>Babakan, Kota Tangerang, Banten 15117</p>
			<br>
			<p>Distance : </p>
			<p>To BINUS Alam Sutera : 6.2 km [<a href="https://www.google.co.id/maps/dir/Amaris+Hotel+Tangerang+City,+Tangcity+Superblok,+Jalan+Jendral+Sudirman+No.+1,+Babakan,+Kec.+Tangerang,+Kota+Tangerang,+Banten+15117/Binus+Alam+Sutra,+Tangerang+City,+Banten/@-6.2112813,106.6210772,14z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69f93247d05ddf:0x73d597e5d0d69ac2!2m2!1d106.6333293!2d-6.1946555!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262" target='_blank'>directions &#x226B;</a>]</p>
			<p>From BINUS Alam Sutera : 6.5 km [<a href="https://www.google.co.id/maps/dir/Binus+Alam+Sutra,+Tangerang+City,+Banten/Amaris+Hotel+Tangerang+City,+Tangcity+Superblok,+Jalan+Jendral+Sudirman+No.+1,+Babakan,+Kec.+Tangerang,+Kota+Tangerang,+Banten+15117/@-6.2119173,106.6210181,14z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69f95f44b73969:0xe6462f72491e1d2!2m2!1d106.6478471!2d-6.2223262!1m5!1m1!1s0x2e69f93247d05ddf:0x73d597e5d0d69ac2!2m2!1d106.6333293!2d-6.1946555" target='_blank'>directions &#x226B;</a>]</p>
			<p>Phone : (021) 29170999</p>
			<p>Nearby attractions : </p>
			<ol class="ol-number">
				<li>TangCity Mall - 30 m (Adjacent) [<a href="https://www.google.co.id/maps/dir/Amaris+Hotel+Tangerang+City,+Babakan,+Tangerang+City,+Banten/Tangcity+Mall,+Babakan,+Tangerang+City,+Banten/@-6.194535,106.6316812,17z/data=!3m1!4b1!4m13!4m12!1m5!1m1!1s0x2e69f93247d05ddf:0x73d597e5d0d69ac2!2m2!1d106.6333293!2d-6.1946555!1m5!1m1!1s0x2e69f93215d44fab:0xd422388a5816a564!2m2!1d106.634104!2d-6.1938863" target='_blank'>directions &#x226B;</a>] </li>
				<li>Metropolis Town Square - 1.0 km [<a href="https://www.google.co.id/maps/dir/Amaris+Hotel+Tangerang+City,+Tangcity+Superblok,+Jalan+Jendral+Sudirman+No.+1,+Babakan,+Kota+Tangerang,+Banten+15117/-6.1979516,106.6382081/@-6.1970133,106.6355137,17z/data=!4m9!4m8!1m5!1m1!1s0x2e69f93247d05ddf:0x73d597e5d0d69ac2!2m2!1d106.6333293!2d-6.1946555!1m0!3e0" target='_blank'>directions &#x226B;</a>] </li>
				<li>Mall Balekota - 2.1 km [<a href="https://www.google.co.id/maps/dir/Amaris+Hotel+Tangerang+City,+Tangcity+Superblok,+Jalan+Jendral+Sudirman+No.+1,+Babakan,+Kota+Tangerang,+Banten+15117/Mall+Bale+Kota+XXI,+Buaran+Indah,+Tangerang+City,+Banten/@-6.1880238,106.6296715,15z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69f93247d05ddf:0x73d597e5d0d69ac2!2m2!1d106.6333293!2d-6.1946555!1m5!1m1!1s0x2e69f8deffffffff:0x634f275088a14dde!2m2!1d106.6427318!2d-6.1808962!3e0" target='_blank'>directions &#x226B;</a>] </li>
				<li>Mayapada Hospitals - 2.2 km [<a href="https://www.google.co.id/maps/dir/Amaris+Hotel+Tangerang+City,+Tangcity+Superblok,+Jalan+Jendral+Sudirman+No.+1,+Babakan,+Kota+Tangerang,+Banten+15117/Mayapada+Hospital+Tangerang,+Jalan+Honoris+Raya,+Tangerang+City,+Banten/@-6.1994481,106.6292958,15z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x2e69f93247d05ddf:0x73d597e5d0d69ac2!2m2!1d106.6333293!2d-6.1946555!1m5!1m1!1s0x2e69f947ce8c007b:0x7d0c6bb6ecab2153!2m2!1d106.6413759!2d-6.2052219!3e0" target='_blank'>directions &#x226B;</a>] </li>
				
			</ol>
			<p>Facility : </p>
			<table class='acom-table'>
				<tr><td></td><td><i class='fa fa-wifi'></i></td><td>Wifi</td></tr>
				<tr><td></td><td><i class='fa fa-cutlery'></i></td><td>Restaurant</td></tr>
				<tr><td></td><td><i class='fa fa-arrows-v'></i></td><td>Elevator</td></tr>
				<tr><td></td><td><b>P</b></td><td>Parking Lot</td></tr>
			</table>
			<br><br>
			<a href="https://www.traveloka.com/en/hotel/indonesia/amaris-hotel-tangerang-3000010003403?spec=30-11-2017.4-12-2017.3.1.HOTEL.3000010003403.Amaris%20Hotel%20Tangerang,%20Tangerang,%20Banten,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
		</div>
		<div class='acom-map col-lg-7 col-md-7 col-sm-12 col-xs-12'>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d34603.51561013778!2d106.62936759395683!3d-6.204820071362878!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f93247d05ddf%3A0x73d597e5d0d69ac2!2sAmaris+Hotel+Tangerang+City!5e0!3m2!1sen!2sid!4v1505215843982" width="1000px" height="800" frameborder="0" style="border:0; margin-top: -300px; margin-left: -300px;" allowfullscreen></iframe>
		</div>
		<p class='clear-float'>&nbsp;</p>
		<div class='acom-room col-lg-12 col-md-12 col-sm-12 col-xs-12'>
			<p align="justify" class="acom-room-title col-lg-12 col-md-12 col-sm-12 col-xs-12'">Smart Room Twin</p>
			
			<div class='acom-slider col-lg-7 col-md-7 col-sm-6 col-xs-12'>
				<div id="main-slideA91" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA91" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA91" data-slide-to="1"></li>
						<li data-target="#main-slideA91" data-slide-to="2"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/amaris/bedroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/amaris/bathroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/amaris/bathroom2.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA91" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA91" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
			<div class='acom-room-detail col-lg-5 col-md-5 col-sm-6 col-xs-12'>
				<p class='acom-price'>Price : <span class='acom-price-value'>IDR 390,000</span>/day*</p>
				<p><sub>Price is based on Traveloka (Sep 18<sup>th</sup>), tax included</sub></p>
				<br>
				<p>Size : 16 m<sup>2</sup></p>
				<p>Max people : 2</p>
				<p>Bed type : 2 single beds</p>
				<p>Room Amenities :</p>
				<table class='acom-table'>
					<tr><td></td><td><i class='fa fa-snowflake-o'></i></td><td>Air Conditioner</td></tr>
					<tr><td></td><td><i class='fa fa-television'></i></td><td>Television</td></tr>
					<tr><td></td><td><i class='fa fa-tint'></i></td><td>Complimentary bottled water</td></tr>
					<tr><td></td><td><i class='fa fa-check'></i></td><td>Desk</td></tr>
				</table>
				<br><br>
				<a href="https://www.traveloka.com/en/hotel/indonesia/amaris-hotel-tangerang-3000010003403?spec=30-11-2017.4-12-2017.3.1.HOTEL.3000010003403.Amaris%20Hotel%20Tangerang,%20Tangerang,%20Banten,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
			</div>
			<p class='clear-float'>&nbsp;</p><br>
		</div>
		<p class='clear-float'>&nbsp;</p>
		<div class='acom-room col-lg-12 col-md-12 col-sm-12 col-xs-12'>
			<p align="justify" class="acom-room-title col-lg-12 col-md-12 col-sm-12 col-xs-12'">Smart Room Queen</p>
			
			<div class='acom-slider col-lg-7 col-md-7 col-sm-6 col-xs-12'>
				<div id="main-slideA92" class="carousel slide main-slide-class" data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#main-slideA92" data-slide-to="0" class="active"></li>
						<li data-target="#main-slideA92" data-slide-to="1"></li>
						<li data-target="#main-slideA92" data-slide-to="2"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/amaris/bedroom2.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/amaris/bathroom1.jpg" alt="slider">
						</div>
						<div class="item">
							<img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/accommodation/amaris/bathroom2.jpg" alt="slider">
						</div>
					</div>
					<a class="left carousel-control" href="#main-slideA92" data-slide="prev">
						<span><i class="fa fa-angle-left"></i></span>
					</a>
					<a class="right carousel-control" href="#main-slideA92" data-slide="next">
						<span><i class="fa fa-angle-right"></i></span>
					</a>
				</div>
			</div>
			<div class='acom-room-detail col-lg-5 col-md-5 col-sm-6 col-xs-12'>
				<p class='acom-price'>Price : <span class='acom-price-value'>IDR 390,000</span>/day*</p>
				<p><sub>Price is based on Traveloka (Sep 18<sup>th</sup>), tax included</sub></p>
				<br>
				<p>Size : 16 m<sup>2</sup></p>
				<p>Max people : 2</p>
				<p>Bed type : 1 double bed</p>
				<p>Room Amenities :</p>
				<table class='acom-table'>
					<tr><td></td><td><i class='fa fa-snowflake-o'></i></td><td>Air Conditioner</td></tr>
					<tr><td></td><td><i class='fa fa-television'></i></td><td>Television</td></tr>
					<tr><td></td><td><i class='fa fa-tint'></i></td><td>Complimentary bottled water</td></tr>
					<tr><td></td><td><i class='fa fa-check'></i></td><td>Desk</td></tr>
				</table>
				<br><br>
				<a href="https://www.traveloka.com/en/hotel/indonesia/amaris-hotel-tangerang-3000010003403?spec=30-11-2017.4-12-2017.3.1.HOTEL.3000010003403.Amaris%20Hotel%20Tangerang,%20Tangerang,%20Banten,%20Indonesia.1" target='_blank'><button type='button' class="btn-system btn-large" >Book Now</button></a>
			</div>
			<p class='clear-float'>&nbsp;</p><br>
		</div>
		<p class='clear-float'>&nbsp;</p>
	</div>
</div>