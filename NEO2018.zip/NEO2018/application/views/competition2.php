<div class="page-banner no-subtitle">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="white">Competition</h1>
			</div>
		</div>
	</div>
</div>
<div class="container" id="competition-welcome">
	<div class="col-md-12">
		              
		<!-- Classic Heading -->
		<!-- <h4 class="classic-title"><span>Fields in National English Olympics</span></h4> -->

	</div>
</div>

<div class="container">
	<div class="col-md-12">
		<!-- Toggle -->
		<div class="panel-group" id="accordion">
			<h2>Diklik yaa rulesnya, terus yang warna MERAH itu tahun lalu ada, tahun ini ga ada</h2>
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#scrabble">
							<i class="fa fa-angle-up control-icon"></i>
							<h4 class="classic-title" style="text-decoration: none;"><i class="fa fa-pencil"></i> <span>Scrabble</span> <span style="margin-left:30px;">IDR 250,000 per person</span></h4>
						</a>
					</h4>
				</div>
				<div id="scrabble" class="panel-collapse collapse">
					<div class="panel-body">
						<div class="col-md-12">
							<div class="col-md-2">
								<img src="<?php echo base_url(); ?>assets/2017/images/iconcompetition/scrabble.png" class="competition-icon">
							</div>	
							<div class="col-md-10">
								<div class="classic-testimonials testimoni-competition">
					                <div class="testimonial-content">
					                    <p>Scrabble is a word game in which two players score points by placing tiles, each bearing a single letter, onto a game board which is divided into a 15×15 grid of squares.</p>		
					                    <a data-toggle="modal" data-target="#modalGeneral"><b>General Rules »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalScrabble"><b>Rules for Scrabble »</b></a>
					                </div>
					            </div>
							</div>
						</div>
					</div>
				</div>

				<div class="panel-heading">
					<h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#stortel">
							<i class="fa fa-angle-up control-icon"></i>
							<h4 class="classic-title"><i class="fa fa-pencil"></i> <span>Storytelling</span><span style="margin-left:30px;">IDR 300,000 per person</span></h4>
						</a>
					</h4>
				</div>
				<div id="stortel" class="panel-collapse collapse">
					<div class="panel-body">
						<div class="col-md-12">	
							<div class="col-md-2">
								<img src="<?php echo base_url(); ?>assets/2017/images/iconcompetition/storytelling.png" class="competition-icon">
							</div>						
							<div class="col-md-10">
								<div class="classic-testimonials testimoni-competition">
					                <div class="testimonial-content">
					                    <p>Storytelling is a form of public speaking that is meant to entertain people through the means of delivering a story. Good storytelling balances between a compelling plot and an amusing delivery that gets the message across.</p>
					                    <a data-toggle="modal" data-target="#modalGeneral"><b>General Rules »</b></a><br>
					                    <hr style="margin: 10px;">
					                    <a data-toggle="modal" data-target="#modalStortel1"><b>Preliminary One: Prepared Story »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalStortel2"><b>Preliminary Two: Tall Tales »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalStortel3"><b>Quarter Final: Tag Team »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalStortel4"><b>Semi Final: Fortune and Fate »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalStortel5"><b>Final: Group Duel »</b></a><br>
					                    <!-- <a data-toggle="modal" data-target="#modalStortel2"><b>Preliminary Two: Tall Tales >></b></a> -->
					                </div>
					            </div>
							</div>
						</div>
					</div>
				</div>

				<div class="panel-heading">
					<h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#debate">
							<i class="fa fa-angle-up control-icon"></i>
							<h4 class="classic-title" ><i class="fa fa-pencil"></i> <span>Debate</span><span style="margin-left:30px;">IDR 350,000 per team (3 people)</span></h4>
						</a>
					</h4>
				</div>
				<div id="debate" class="panel-collapse collapse">
					<div class="panel-body">
						<div class="col-md-12">
							<div class="col-md-2">
								<img src="<?php echo base_url(); ?>assets/2017/images/iconcompetition/debate.png" class="competition-icon">
							</div>	
							<div class="col-md-10">
								<div class="classic-testimonials testimoni-competition">
					                <div class="testimonial-content">
					                    <p>Debate is an avenue of critical thinking and public speaking. It doesn't only teach you what to think and how to think, it also teaches you how to persuade people with your ideas and argumentation.</p>
					                    <p>In NEO 2017, we will be using Asian Parliamentary (7-minute substantive speeches, There will be a Reply, with <span id='tooltip-poi'><u>POI</u></span>).</p>
					                    <a data-toggle="modal" data-target="#modalGeneral"><b>General Rules »</b></a><br>
					                    <!-- <a data-toggle="modal" data-target="#modalgajadi"><b>Rules for Debate »</b></a> -->
					                </div>
					            </div>
							</div>
						</div>
					</div>
				</div>


				<div class="panel-heading">
					<h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#speech">
							<i class="fa fa-angle-up control-icon"></i>
							<h4 class="classic-title" ><i class="fa fa-pencil"></i> <span>Speech</span><span style="margin-left:30px;">IDR 300,000 per person</span></h4>
						</a>
					</h4>
				</div>
				<div id="speech" class="panel-collapse collapse">
					<div class="panel-body">
						<div class="col-md-12">
							<div class="col-md-2">
								<img src="<?php echo base_url(); ?>assets/2017/images/iconcompetition/speech.png" class="competition-icon">
							</div>	
							<div class="col-md-10">
								<div class="classic-testimonials testimoni-competition">
					                <div class="testimonial-content">
					                    <p>Learn to express your opinion and inspire the audience. It lies on the ability to send a messages to audience. The messages that can affect others.</p>
					                    <a data-toggle="modal" data-target="#modalGeneral"><b>General Rules »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalSpeech1"><b>Preliminary One : Prepared Speech »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalSpeech2"><b>Preliminary Two : Evaluation Speech »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalSpeech3"><b>Quarter Final : Inspiring Speech »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalSpeech4"><b>Semi Final : Humorous Speech »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalSpeech5"><b>Final : Oratorical Speech »</b></a><br>
					                    <!-- <a data-toggle="modal" data-target="#modalSpeech2"><b>Preliminary Two: Table Topic >></b></a> -->
					                </div>
					            </div>
							</div>
						</div>
					</div>
				</div>

				<div class="panel-heading">
					<h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#news">
							<i class="fa fa-angle-up control-icon"></i>
							<h4 class="classic-title" ><i class="fa fa-pencil"></i> <span>Newscasting</span><span style="margin-left:30px;">IDR 300,000 per person</span></h4>
						</a>
					</h4>
				</div>
				<div id="news" class="panel-collapse collapse">
					<div class="panel-body">
						<div class="col-md-12">
							<div class="col-md-2">
								<img src="<?php echo base_url(); ?>assets/2017/images/iconcompetition/newscasting.png" class="competition-icon">
							</div>	
							<div class="col-md-10">
								<div class="classic-testimonials testimoni-competition">
					                <div class="testimonial-content">
					                    <p>Learn how to act professionally in front of a camera through news read, live report, talk show, and many more.</p>
					                    <a data-toggle="modal" data-target="#modalGeneral"><b>General Rules »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalNews1"><b>Preliminary One : News Reading »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalNews2"><b>Preliminary Two : Cultural News >></b></a><br>
					                    <a data-toggle="modal" data-target="#modalNews3"><b>Quarter Final : Talkshow >></b></a><br>
					                    <a data-toggle="modal" data-target="#modalNews4"><b>Semifinal : Live Report >></b></a><br>
					                    <a data-toggle="modal" data-target="#modalNews5"><b>Final : News Reading and Interview >></b></a> 	 
					                </div>
					            </div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $this->load->view('frontend/modals'); ?>
<?php $this->load->view('frontend/modalLogin'); ?>