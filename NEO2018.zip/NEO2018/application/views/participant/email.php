<div class="page-banner no-subtitle">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="white">Send Email</h1>
			</div>
		</div>
	</div>
</div>

<div class="container">
	<div id="about-bnec" class="col-md-6">
      	<h4 class="classic-title"><span style="font-size: 18px;">Send Transfer Payment Receipt and Institution Logo</span></h4>
		<div class="col-md-12" style="padding-left:3em;">
	      	<h5>Select your email service</h5>
	      	<div class='col-md-2'>
	      		<a href="https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=regist2018neo@gmail.com&su=<?php echo $this->session->userdata('namaSMA'); ?>&body=" target="_blank">
	      			<img src="<?php echo base_url(); ?>assets/2018/images/ico/gmail.svg">
	      			<h6 style='text-align: center;'>Gmail</h6>
	      		</a>
	      	</div>
	      	<div class='col-md-2'>
	      		<a href="http://compose.mail.yahoo.com/?to=regist2018neo@gmail.com&subject=<?php echo $this->session->userdata('namaSMA'); ?>&body=" target="_blank">
	      			<img src="<?php echo base_url(); ?>assets/2018/images/ico/yahoo.png">
	      			<h6 style='text-align: center;'>Yahoo!</h6>
	      		</a>
	      	</div>
	      	<div class='col-md-2'>
	      		<a href="http://mail.live.com/mail/EditMessageLight.aspx?n=&to=regist2018neo@gmail.com&cc=CC&subject=<?php echo $this->session->userdata('namaSMA'); ?>&body=" target="_blank">
	      			<img src="<?php echo base_url(); ?>assets/2018/images/ico/outlook.svg">
	      			<h6 style='text-align: center;'>Outlook</h6>
	      		</a>
	      	</div>
      	</div>
	</div>
	<div style='height: 200px;'></div>
</div>