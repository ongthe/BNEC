<?php date_default_timezone_set("Asia/jakarta"); ?>
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.min.css" />
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker3.min.css" />

<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>

<?php 
    if(empty($allTrans))
    {
        ?>
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
            </button>
            <strong>You have to register your fields first!</strong>
        </div>
        <?php
    }

     if($this->session->flashdata('addTrans') != '') {
     ?>
        <div class="alert alert-success alert-dismissible" role="success">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('addTrans'); ?></strong>
        </div>
    <?php
     }

     if($this->session->flashdata('failedAddTrans') != '') {
     ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('addTrans'); ?></strong>
        </div>
    <?php
     }

    if($this->session->flashdata('confirmPayment') != '') {
     ?>
        <div class="alert alert-success alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('confirmPayment'); ?></strong>
        </div>
    <?php
     }

     if($this->session->flashdata('failedConfirmPayment') != '') {
     ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('confirmPayment'); ?></strong>
        </div>
    <?php
     }
 ?>

<div class="page-banner no-subtitle">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="white h1-s">PAYMENT CONFIRMATION</h1>
			</div>
		</div>
	</div>
</div>

<div class="container no-padding" id="confirm-list">
    <?php for($i=0;$i<count($allTrans);$i++){ ?>
    <div class="col-md-6">
        <div class="call-action call-action-boxed call-action-style4 clearfix confirm-item">
            <h4 style="color:#ce1d54;">Transaction Number : <?php echo $allTrans[$i]->transaction_id; ?></h4>
             <?php $dateTemp = new DateTime($allTrans[$i]->transaction_date);$date =$dateTemp->format('d M Y');?>
            <b><p>Transaction Date : <?php echo $date; ?></p></b>
            <b><p>Fields : <?php echo $allTrans[$i]->competition_name; ?> <!-- (<?php echo $allTrans[$i]->qty; ?>) --></p></b>
            <b><h4>Price : IDR <span class="price"><?php echo $allTrans[$i]->competition_price; /** $allTrans[$i]->qty*/; ?></span></h4></b>
        
        </div>
    </div>
    <?php } ?>
</div>

<div class="container call-action call-action-boxed call-action-style1 no-descripton clearfix" id="confirm-payment">
	<form role="form" class="contact-form" id="confirm-form" action="<?php echo base_url().'Payment/confirm_payment1' ?>" method="POST">
		<div class="checkbox">
			<div class="col-md-3">
				<label>Transaction Number :</label>
		  	</div>
		  	<div class="col-md-9">
                <?php for($i=0;$i<count($allTrans);$i++){ ?>
			  	  <label class="choice"><input type="checkbox" 
			  	  value="<?php echo $allTrans[$i]->transaction_id; ?>" 
			  	  class="transNumber" 
			  	  name="chkTrsNo[]" 
			  	  <?php if($allTrans[$i]->status == 'Confirm') { ?> checked="checked" disabled="disabled"><?php  } else { ?> ><?php } ?>
			  	  <?php echo $allTrans[$i]->transaction_id; ?></label>
                <?php } ?>
            </div>
		</div>
           <div class="form-group">
                <div class="controls">
                   <div class="col-md-3">
                      <label style="padding-top: 5px;">Transfer Date :</label>
                   </div>
        <div class="col-md-9 date">
            <div class="input-group input-append date" id="dateRangePicker">
                <input type="text" placeholder="MM/DD/YYYY" class="form-control" name="transfer_date" value="<?php if(!empty($allTrans)) { if(count($confirm) > 0) { echo $confirm[0]->tglTransfer; } } ?>" <?php if(!empty($allTrans)) { if(count($confirm) > 0) { ?> disabled="disabled" <?php } } ?> />
                <span class="input-group-addon add-on"><a class="glyphicon glyphicon-calendar"></a></span>
            </div>
        </div>
    </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3">
                    <label style="padding-top: 15px;">Bank Account Name :</label>
                </div>
                <div class="col-md-9" style="margin-top: 10px;">
                  <!-- gracia -->
                    <input type="text" placeholder="Bank Account Name" name="noRek" value="<?php if(!empty($allTrans)) { if(count($confirm) > 0) { echo $confirm[0]->noRek; } } ?>" <?php if(!empty($allTrans)) { if(count($confirm) > 0) { ?> disabled="disabled" <?php } } ?> required>
                  <!-- end -->
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3">
                    <label>Bank Name :</label>
                </div>
                <div class="col-md-9">
                    <input type="text" placeholder="Bank Name, example : BCA/Mandiri" name="atas_nama" value="<?php if(!empty($allTrans)) { if(count($confirm) > 0) { echo $confirm[0]->atasNama; } } ?>" <?php if(!empty($allTrans)) { if(count($confirm) > 0) { ?> disabled="disabled" <?php } } ?> required>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3">
                    <label>Nominal :</label>
                </div>
                <div class="col-md-9">
                    <input type="number" placeholder="Nominal" name="nominal" value="<?php if(!empty($allTrans)) { if(count($confirm) > 0) { echo $confirm[0]->nominal; } } ?>" <?php if(!empty($allTrans)) { if(count($confirm) > 0) { ?> disabled="disabled" <?php } } ?> required>
                </div>
            </div>
        </div>
        <div class="col-md-12 payment-row">        
            <br><p style="font-size:1em;"><b>You can register the participant</b> after the admin has confirmed your payment <a href="<?php echo base_url(); ?>Competition/myFields">My Fields</a></p>
        </div>
    
    <div class="button-side btn-form">      
        <a href="<?php echo base_url(); ?>payment/invoiceslist" class="btn-system btn-large">Pay Later</a>
        <button type="submit" id="submit" class="btn-system btn-large">Confirm</button>
    </form>
    </div>
</div>

<!-- Modal -->
  <div class="modal fade" id="messageModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content alert-bg" style="margin-top: 120px;">
        <div class="modal-header" style="border-bottom: 0;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="color: white; font-size: 16px;">Transfer Payment Receipt</h4>
        </div>
        <div class="modal-body">
          <p align="justify" style="color: white; font-size: 16px;">Please send the transfer payment receipt and your institution logo to <strong>regist2017neo@gmail.com</strong> 
          <p align="justify" style="color: white; font-size: 16px;">#Note!!!</p>
<p align="justify" style="color: white; font-size: 16px;">Email Subject: Your Institution/School Name</p>
        </div>
        <div class="modal-footer" style="border-top: 0;">
          <a href="<?php echo base_url(); ?>Participant/send_email">
            <button type="button" class="btn btn-default">Send Now</button>
          </a>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

<script type="text/javascript">
	$(document).ready(function()
	{
   $('#dateRangePicker')
   .datepicker({
     format: 'mm/dd/yyyy',
     startDate: '01/01/2010',
     endDate: '12/30/2020'
   })
   .on('changeDate', function(e) {
	            // Revalidate the date field
	            $('#dateRangeForm').formValidation('revalidateField', 'date');
           });
   $('#messageModal').modal('show');
   $("#submit").click(function() {
     if($('.transNumber:checked').length == 0)
     {
      alert('Please choose at least one transaction number');
      return false;
    }
  });

   setTimeout(function() {
    $(".alert").fadeOut().empty();
  }, 5000);
 });
</script>