<div class="section short-about">
    <div class="container" id="home-content" style="width: 100%;">
    	<div class="col-md-offset-2 col-md-8" style="margin-bottom:6em;">
            
            <div class="call-action call-action-boxed call-action-style4 clearfix confirm-item" style="text-align:center;">
                <h1 class="white" style="margin-bottom: 0.7em;">Welcome, <?php echo $user; ?></h1>      
                <h4 class="white" style="margin-bottom:2em;">These are the steps to join this competition</h4>      
            	<a href="<?php echo base_url(); ?>Competition" class="btn-system btn-large border-btn" style="margin-bottom:1em;">
            		Step 1 <br>
            		Register Fields
            	</a>            
                <a href="<?php echo base_url(); ?>Payment/invoices_list" class="btn-system btn-large border-btn" style="margin-bottom:1em;">
                	Step 2 <br>
                	Pay via Transfer
                </a>                
                <!-- <a href="" class="btn-system btn-large border-btn" style="margin-bottom:1em;" data-toggle="modal" data-target="#messageModal"> -->
                <a href="<?php echo base_url(); ?>Participant/send_email" class="btn-system btn-large border-btn" style="margin-bottom:1em;">
                	Step 3 <br>
                	Send Transfer Payment Receipt by Email
                </a>                
                <a href="<?php echo base_url(); ?>Payment/confirm_payment" class="btn-system btn-large border-btn" style="margin-bottom:1em;">
                    Step 4 <br>
                    Confirm Payment
                </a>
                <a href="<?php echo base_url(); ?>Payment/invoices_list" class="btn-system btn-large border-btn" style="margin-bottom:1em;">
                	Step 5 <br>
                	Wait to be confirmed by Admin
                </a>
                <a href="<?php echo base_url(); ?>Competition/my_fields" class="btn-system btn-large border-btn" style="margin-bottom:1em;">
                	Step 6 <br>
                	Register Participant
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
  <div class="modal fade" id="messageModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" style="margin-top: 120px;">
        <div class="modal-header" style="background-color: #ce1d54; border-bottom: 0;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="color: white; font-size: 16px;">Transfer Payment Receipt</h4>
        </div>
        <div class="modal-body" style="background-color: #ce1d54;">
          <p align="justify" style="color: white; font-size: 16px;">Please send the transfer payment receipt and your institution logo to <strong>email.sementara2017AAAAAAA@gmail.com</strong> 
          <p align="justify" style="color: white; font-size: 16px;">#Note!!!</p>
<p align="justify" style="color: white; font-size: 16px;">Email Subject: Your Institution/School Name</p>
        </div>
        <div class="modal-footer" style="background-color: #ce1d54; border-top: 0;">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>