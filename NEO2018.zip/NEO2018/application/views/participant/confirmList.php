<div class="page-banner no-subtitle">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="white">Invoices</h1>
			</div>
		</div>
	</div>
</div>

<div class="container" id="confirm-list">
	<div class="col-md-6">
		<div class="call-action call-action-boxed call-action-style4 clearfix confirm-item">
			<h4>Transaction Number : 123123123</h4>
			<p>Transaction Date : 12 Mei 2016</p>
			<div class="button-side">
				<a href="<?php echo base_url(); ?>Payment/confirmPayment" class="btn-system btn-large">Confirm Payment</a>
			</div>
			<p>Fields : Story Telling (2)</p>
			<p>Total Price : 300.000</p>
		
		</div>
	</div>
	<div class="col-md-6">
		<div class="call-action call-action-boxed call-action-style1 clearfix confirm-item">
			<h4>Transaction Number : 123123123</h4>
			<p>Transaction Date : 12 Mei 2016</p>
			<div class="button-side">
				<a href="<?php echo base_url(); ?>Payment/confirmPayment" class="btn-system btn-large">Confirm Payment</a>
			</div>
			<p>Fields : Story Telling (2)</p>
			<p>Total Price : 300.000</p>
		</div>
	</div>
	<div class="col-md-6">
		<div class="call-action call-action-boxed call-action-style4 clearfix confirm-item">
			<h4>Transaction Number : 123123123</h4>
			<p>Transaction Date : 12 Mei 2016</p>
			<div class="button-side">
				<a href="<?php echo base_url(); ?>Payment/confirmPayment" class="btn-system btn-large">Confirm Payment</a>
			</div>
			<p>Fields : Story Telling (2)</p>
			<p>Total Price : 300.000</p>
		</div>
	</div>
	<div class="col-md-6">
		<div class="call-action call-action-boxed call-action-style1 clearfix confirm-item">
			<h4>Transaction Number : 123123123</h4>
			<p>Transaction Date : 12 Mei 2016</p>
			<div class="button-side">
				<a href="<?php echo base_url(); ?>Payment/confirmPayment" class="btn-system btn-large">Confirm Payment</a>
			</div>
			<p>Fields : Story Telling (2)</p>
			<p>Total Price : 300.000</p>
		</div>
	</div>
</div>