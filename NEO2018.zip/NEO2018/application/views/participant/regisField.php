<div class="page-banner no-subtitle">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="white">REGISTER FIELDS</h1>
			</div>
		</div>
	</div>
</div>

<div class="container" id="regis-fields">
	<div class="row pricing-tables">
		<div class="col-md-12 row-field">
			<?php for($i=0;$i< count($comps);$i++){ 

				?>
			<div class="col-md-4 col-xs-6">
		        <div class="pricing-table">
		        	<form action="<?php echo base_url().'Payment/payment1/'.$comps[$i]->competition_id; ?>" method="POST">
						<div class="plan-name">
							<h3><?php echo $comps[$i]->competition_name; ?></h3>
						</div>
						<div class="plan-price">
							<div class="price-value">
								<div style="background-color: #111; width: 50%; margin-left: 25%; border-radius: 100%;">
									<img src="<?php echo base_url(); ?>assets/2018/images/iconcompetition/<?php echo strtolower($comps[$i]->competition_name);?>.svg">
								</div>
							</div>
						</div>
						<div class="plan-list">
							<ul>
								<li><strong><?php if($comps[$i]->competition_id==3){echo '2 </strong> People';}else{echo '1 </strong> Person';} ?></li>
								<li>
									<strong>IDR <span class="price">
										<?php if($early_bid > strtotime('now')): ?>
											<?php echo $comps[$i]->competition_price; ?>
										<?php else: ?>
											<?php echo $comps;?>
										<?php endif ?>
										</span></strong>
									<?php if ($comps[$i]->competition_name == "Debate"): ?>
										per team
									<?php else: ?>
										per person
									<?php endif ?>

								</li>
							</ul>
						</div>
						<div class="plan-signup">
							<button type="submit" id="submit" class="btn-system btn-small">Buy Now</button>
						</div>
					</form>
				</div>
		    </div>
		    <?php } ?>
		</div>
		
		</div>
	</div>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        setTimeout(function() {
          $(".alert").fadeOut().empty();
        }, 3000);
    });
</script>