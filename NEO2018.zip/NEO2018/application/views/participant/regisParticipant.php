<?php 
    if(isset($addParticipant))
    { 
        if($addParticipant)
        {
            ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>
                <strong>Add Participant Success!</strong>
            </div>
            <?php 
        }
        else 
        { 
            ?>
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>
                <strong>Failed</strong> to add participant! Please <strong>Try again.</strong>
            </div>
            <?php
        }
    }
 ?>

<div class="page-banner no-subtitle">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="white">Participant Registration Form</h1>
            </div>
        </div>
    </div>
</div>

<div class="container call-action call-action-boxed call-action-style1 no-descripton clearfix" id="regis-Participant">
    <form role="form" class="contact-form" id="confirm-form" method="post" action="<?php echo base_url().'Participant/add_participant/'.$transaction_id.'/'.$fields_name; ?>">
        <?php if($fields_name != "Debate") { ?>
        <div class="checkbox">
            <div class="col-md-3" style="margin-top: 7.5px;">
                <label>Full Name :</label>
            </div>
            <div class="col-md-9">                
               <input type="text" placeholder="Full Name" name="FullName" required>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3">
                    <label>Gender :</label>
                </div>
                <div class="col-md-9">
                    <input type="radio" name="gender" id="male" value="M" required />
                    <label for="male" style="padding-left: 5px !important;">Male</label>
                    <input type="radio" name="gender" id="female" value="F" style="margin-left: 10px;" required/>
                    <label for="female" style="padding-left: 5px !important;">Female</label>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3" style="margin-top: 20px;">
                    <label>Phone Number :</label>
                </div>
                <div class="col-md-9" style="margin-top: 10px;">
                    <input type="number" placeholder="Phone Number" name="phone" required>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3" style="margin-top: 10px;">
                    <label>Date of Birth :</label>
                </div>
                <div class="col-md-9">
                    <input type="date" placeholder="Date of Birth" name="dob" required>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3" style="margin-top: 5px;">
                    <label>Email :</label>
                </div>
                <div class="col-md-9">
                    <input type="email" placeholder="Email" name="email" required>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3">
                    <label>Vegetarian :</label>
                </div>
                <div class="col-md-9">
                    <input type="checkbox" name="vegetarian" id="vegetarian" value="1" />
                    <label for="vegetarian" style="padding-left: 5px !important;">Vegetarian</label>
                    <!-- <input type="radio" name="vegetarian" id="nonVegetarian" value="0" style="margin-left: 10px;"/> -->
                    <!-- <label for="nonVegetarian" style="padding-left: 5px !important;">Non Vegetarian</label> -->
                </div>
            </div>
        </div>
        <div class="button-side btn-form" style="margin-top: 20px;">        
            <button type="submit" id="submit" class="btn-system btn-large">Register</button>
        </div>
        <?php } else { ?>
        <div>
            <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
                <li class="active"><a href="#debater1" data-toggle="tab">Debater 1</a></li>
                <li><a href="#debater2" data-toggle="tab">Debater 2</a></li>
                <li><a href="#debater3" data-toggle="tab">Debater 3</a></li>
                <li><a href="#team" data-toggle="tab">Team</a></li>
            </ul>
            <div id="my-tab-content" class="tab-content">
                <div class="tab-pane active" id="debater1">
                    <div class="col-md-12" style="margin-left: -50px;">
                        <div class="checkbox">
                            <div class="col-md-4" style="margin-top: 7.5px;">
                                <label>Full Name :</label>
                            </div>
                            <div class="col-md-8">                
                               <input type="text" placeholder="Full Name" name="FullNameDB1" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4">
                                    <label>Gender :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="radio" name="genderDB1" id="male" value="M" />
                                    <label for="male" style="padding-left: 5px !important;">Male</label>
                                    <input type="radio" name="genderDB1" id="female" value="F" style="margin-left: 10px;"/>
                                    <label for="female" style="padding-left: 5px !important;">Female</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 20px;">
                                    <label>Phone Number :</label>
                                </div>
                                <div class="col-md-8" style="margin-top: 10px;">
                                    <input type="number" placeholder="Phone Number" name="phoneDB1" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 10px;">
                                    <label>Date of Birth :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="date" placeholder="Date of Birth" name="dobDB1" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 5px;">
                                    <label>Email :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="email" placeholder="Email" name="emailDB1" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4">
                                    <label>Vegetarian :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="checkbox" name="vegetarianDB1" id="vegetarian" value="1" />
                                    <label for="vegetarian" style="padding-left: 5px !important;">Vegetarian</label>
                                    <!-- <input type="radio" name="vegetarianDB1" id="nonVegetarian" value="0" style="margin-left: 10px;"/> -->
                                    <!-- <label for="nonVegetarian" style="padding-left: 5px !important;">Non Vegetarian</label> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="debater2">
                    <div class="col-md-12" style="margin-left: -50px;">
                        <div class="checkbox">
                            <div class="col-md-4" style="margin-top: 7.5px;">
                                <label>Full Name :</label>
                            </div>
                            <div class="col-md-8">                
                               <input type="text" placeholder="Full Name" name="FullNameDB2" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4">
                                    <label>Gender :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="radio" name="genderDB2" id="male" value="M" />
                                    <label for="male" style="padding-left: 5px !important;">Male</label>
                                    <input type="radio" name="genderDB2" id="female" value="F" style="margin-left: 10px;"/>
                                    <label for="female" style="padding-left: 5px !important;">Female</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 20px;">
                                    <label>Phone Number :</label>
                                </div>
                                <div class="col-md-8" style="margin-top: 10px;">
                                    <input type="number" placeholder="Phone Number" name="phoneDB2" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 10px;">
                                    <label>Date of Birth :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="date" placeholder="Date of Birth" name="dobDB2" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 5px;">
                                    <label>Email :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="email" placeholder="Email" name="emailDB2" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4">
                                    <label>Vegetarian :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="checkbox" name="vegetarianDB2" id="vegetarian" value="1" />
                                    <label for="vegetarian" style="padding-left: 5px !important;">Vegetarian</label>
                                    <!-- <input type="radio" name="vegetarianDB2" id="nonVegetarian" value="0" style="margin-left: 10px;"/> -->
                                    <!-- <label for="nonVegetarian" style="padding-left: 5px !important;">Non Vegetarian</label> -->
                                </div>
                            </div>
                        </div>
                    </div> 
                </div>  
                <div class="tab-pane" id="debater3">
                    <div class="col-md-12" style="margin-left: -50px;">
                        <div class="checkbox">
                            <div class="col-md-4" style="margin-top: 7.5px;">
                                <label>Full Name :</label>
                            </div>
                            <div class="col-md-8">                
                               <input type="text" placeholder="Full Name" name="FullNameDB3" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4">
                                    <label>Gender :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="radio" name="genderDB3" id="male" value="M" />
                                    <label for="male" style="padding-left: 5px !important;">Male</label>
                                    <input type="radio" name="genderDB3" id="female" value="F" style="margin-left: 10px;"/>
                                    <label for="female" style="padding-left: 5px !important;">Female</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 20px;">
                                    <label>Phone Number :</label>
                                </div>
                                <div class="col-md-8" style="margin-top: 10px;">
                                    <input type="number" placeholder="Phone Number" name="phoneDB3" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 10px;">
                                    <label>Date of Birth :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="date" placeholder="Date of Birth" name="dobDB3" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4" style="margin-top: 5px;">
                                    <label>Email :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="email" placeholder="Email" name="emailDB3" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="controls">
                                <div class="col-md-4">
                                    <label>Vegetarian :</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="checkbox" name="vegetarianDB3" id="vegetarian" value="1" />
                                    <label for="vegetarian" style="padding-left: 5px !important;">Vegetarian</label>
                                    <!-- <input type="radio" name="vegetarianDB3" id="nonVegetarian" value="0" style="margin-left: 10px;"> -->
                                    <!-- <label for="nonVegetarian" style="padding-left: 5px !important;">Non Vegetarian</label> -->
                                </div>
                            </div>
                        </div>
                    </div> 
                </div> 
                <div class="tab-pane" id="team">
                    <div class="col-md-12" style="margin-left: -30px;">
                        <select class="form-control" name="teamName">
                            <option value="A">Team A</option>
                            <option value="B">Team B</option>
                            <option value="C">Team C</option>
                         </select>
                    </div>
                    <div class="button-side btn-form" style="margin-top: 20px; margin-left: 45px;">        
                        <button type="submit" id="submit" class="btn-system btn-large">Register</button>
                    </div>
                    <!-- <div class="button-side btn-form" style="margin-top: 20px;">         -->
                        <!-- <button type="submit" id="submit" class="btn-system btn-large">Register</button> -->
                    <!-- </div -->
                </div>
            </div>
        </div>
        <?php } ?>
    </form>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        $('#tabs').tab();
    });
</script>