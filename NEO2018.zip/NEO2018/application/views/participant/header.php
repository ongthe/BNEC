<!doctype html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><html lang="en" class="no-js"> <![endif]-->
<html lang="en">

<head>

<!-- Basic -->
<title><?php echo $page; ?></title>

 <!-- Favicon (32x32) -->
<link rel="shortcut icon" width="100%" height="100%" href="<?php echo base_url(); ?>assets/2018/images/neo_icon.png"/>

<!-- Define Charset -->
<meta charset="utf-8">

<!-- Responsive Metatag -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- Page Description and Author -->
<meta name="description" content="Margo - Responsive HTML5 Template">
<meta name="author" content="iThemesLab">

<!-- Bootstrap CSS  -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/2018/css/bootstrap.min.css" type="text/css" media="screen">
<!-- Font Awesome CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- Margo CSS Styles  -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/2018/css/style.css" media="screen">


<!-- Responsive CSS Styles  -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/2018/css/responsive.css" media="screen">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/2018/css/responsive1.css" media="screen">

<!-- Css3 Transitions Styles  -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/2018/css/animate.css" media="screen">

<!-- Color CSS Styles  -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/2018/css/color.css" title="red" media="screen" />

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/2018/css/main.css" media="screen">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/2018/css/style2017b.css" media="screen">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/2018/css/accommodation.css" media="screen">


<!-- Margo JS  -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/2018/js/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/2018/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/2018/js/jquery.fitvids.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/2018/js/owl.carousel.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/2018/js/nivo-lightbox.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/2018/js/jquery.isotope.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/2018/js/jquery.appear.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/2018/js/count-to.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/2018/js/jquery.textillate.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/2018/js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/2018/js/jquery.parallax.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/2018/js/script.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/2018/js/script2017.js"></script>

<!--[if IE 8]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

</head>

<body>

<!-- Full Body Container -->
<div id="container">


<!-- Start Header Section --> 
<div class="hidden-header"></div>
<header class="clearfix">
	
	   <!-- Start Top Bar -->
	<div class="top-bar">
		<div class="container">
			<div class="row">
				<div class="col-md-8">
					<!-- Start Contact Info -->
					<ul class="contact-details">
						<li><a href="<?php echo base_url(); ?>Guest/contact"><i class="fa fa-map-marker"></i> Binus University (Alam Sutera), Tangerang</a>
						</li>
						<li><a href="https://mail.google.com/mail/?view=cm&fs=1&to=nationalenglisholympics@gmail.com&su=&body="><i class="fa fa-envelope-o"></i> nationalenglisholympics@gmail.com</a>
						</li>
						<li><a href="<?php echo base_url(); ?>Guest/contact"><i class="fa fa-calendar"></i> November 22<sup>nd</sup> - 25<sup>th</sup>, 2018</a>
						</li>
					</ul>
					<!-- End Contact Info -->
				</div><!-- .col-md-6 -->
				<div class="col-md-4">
					<!-- Start Social Links -->
					<ul class="social-list">
						<!-- <li>
							<a class="facebook itl-tooltip" data-placement="bottom" title="Facebook" href="https://www.facebook.com/binus.neo" target="_blank"><i class="fa fa-facebook"></i></a>
						</li>
						<li>
							<a class="twitter itl-tooltip" data-placement="bottom" title="Twitter" href="https://twitter.com/bnecneo2018" target="_blank"><i class="fa fa-twitter"></i></a>
						</li> -->
						<li>
							<div style='position: relative; height: 20.5px;'>
								
								<div class='absolute17'>
									<a id='tool-ig' class="instgram itl-tooltip" data-placement="bottom" title="Instagram" href="https://www.instagram.com/bnecneo2018/"><i class="fa fa-instagram "></i></a>
								</div>
							
								<div class='absolute17'>
									<a class="instgram itl-tooltip ig-hover" data-placement="bottom" title="Instagram" href="https://www.instagram.com/bnecneo2018/" target="_blank"><i class="fa fa-instagram"></i></a>
								</div>
							</div>
						</li>
					</ul>
					<!-- End Social Links -->
				</div><!-- .col-md-6 -->
			</div><!-- .row -->
		</div><!-- .container -->
	</div><!-- .top-bar -->
	<!-- End Top Bar -->
	
	<!-- Start  Logo & Naviagtion  -->
	<div class="navbar navbar-default navbar-top">
		<div class="container">
			<div class="navbar-header">
				<!-- Stat Toggle Nav Link For Mobiles -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<i class="fa fa-bars"></i>
				</button>
				<!-- End Toggle Nav Link For Mobiles -->
			   <a class="navbar-brand" href="#" style="padding-top: 1.5em;color: white;">
					<!-- <img alt="" src="<?php echo base_url(); ?>assets/images/bnec.png" class="logo-header"> -->
					The 2018 National English Olympics
				</a>
			</div>
			<div class="navbar-collapse collapse">
				<!-- Start Navigation List -->
				<ul class="nav navbar-nav navbar-right">
					<li>
						<a href="<?php echo base_url(); ?>Participant" id="home">Home</a>
					</li>                    
					<li>
						<a href="#" id="fields">Fields</a>
						<ul class="dropdown">
							<li><a href="<?php echo base_url(); ?>Competition">Register Fields</a>
							</li>
							<li><a href="<?php echo base_url(); ?>Competition/my_fields">My Fields</a>
							</li>
							<li><a href="<?php echo base_url(); ?>Participant/competition">Competition</a>
							</li>
						</ul>
					</li>
					<li>
						<a href="#" id="pay">Payment</a>
						<ul class="dropdown">
							<li><a href="<?php echo base_url(); ?>Payment/invoices_list">Invoices</a>
							</li>
							<li><a href="<?php echo base_url(); ?>Payment/confirm_payment">Confirm Payment</a>
							</li>
						</ul>
					</li>
					<li>
						<a href="#" id="info">Info</a>
						<ul class="dropdown">
							<!-- <li><a href="<?php echo base_url();?>Participant/accommodation">Accommodation</a></li> -->
							<li><a href="<?php echo base_url();?>Participant/faq">FAQ</a></li>
						</ul>
					</li>
					<li>
						<a href="<?php echo base_url(); ?>Participant/contact">Contact Us</a>
					</li>
					<li>
						<a href="<?php echo base_url(); ?>Login/logout">Sign Out</a>
					</li>
				</ul>
				<!-- End Navigation List -->
			</div>
		</div>
	</div>
	<!-- End Header Logo & Naviagtion -->
</header> 
<!-- End Header Section -->


<div id="page-content-wrapper">
	<?= $content ?>
</div>

<!-- Start Footer Section -->
		<footer>
			<div class="container">
				<div class="row footer-widgets">
					<!-- Start Subscribe & Social Links Widget -->
					<div class="col-md-4 col-xs-6">
						<div class="footer-widget mail-subscribe-widget">
							<h4>Get in touch<span class="head-line"></span></h4>
							<ul class="contact-details">
								<li>Date: <span style="color: #f7c604 !important">November 22<sup>nd</sup> - 25<sup>th</sup>, 2018</span></li>
								<li>Email: <a style="color: #f7c604 !important" href="https://mail.gaoogle.com/mail/?view=cm&fs=1&to=nationalenglisholympics@gmail.com&su=&body=">nationalenglisholympics@gmail.com</a></li>
								<li>Location: <span style="color: #f7c604 !important">Binus University (Alam Sutera), Tangerang</span></li>
								<li>Website: <a style="color: #f7c604 !important" href="neo.mybnec.org">neo.mybnec.org</a></li>
							</ul>
						</div>
					</div><!-- .col-md-3 -->
					<!-- End Subscribe & Social Links Widget -->

					<div class="col-md-4 col-xs-6">
						<div class="footer-widget social-widget">
							<h4>Follow Us<span class="head-line"></span></h4>
							<ul class="social-icons">
								<!-- <li>
									<a class="facebook itl-tooltip" href="https://www.facebook.com/binus.neo" target="_blank"><i class="fa fa-facebook"></i></a>
								</li>
								<li>
									<a class="twitter itl-tooltip" href="https://twitter.com/bnecneo2018" target="_blank"><i class="fa fa-twitter"></i></a>
								</li> -->
								<li>
									<div style='position: relative; height: 20.5px;'>
										<div class='absolute17'>
											<a class="instgram itl-tooltip" href="https://www.instagram.com/bnecneo2018/"><i class="fa fa-instagram "></i></a>
										</div>
										<div class='absolute17 ig-hover'>
											<a class="instgram itl-tooltip" href="https://www.instagram.com/bnecneo2018/"><i class="fa fa-instagram "></i></a>
										</div>
									</div>
								</li>
							</ul>
						</div>
					</div>

					<!-- .col-md-3 -->
					<!-- End Subscribe & Social Links Widget -->
				   
					<!-- Start Contact Widget -->
					<div class="col-md-4 col-xs-12" style="margin-top: -20px;">
						<div class="footer-widget contact-widget">
							<img src="<?php echo base_url(); ?>assets/2018/images/neo.png" class="img-responsive logo-footer" alt="Footer Logo" />
							<div class="col-xs-12">
								<ul class="col-xs-4 no-padding">
									<li><a class="grey" href="<?php echo base_url(); ?>Participant/about">About</a>
									</li>
									<li><a class="grey" href="<?php echo base_url();?>Participant/faq">FAQ</a>
									<!-- <li><a class="grey" href="<?php echo base_url();?>Participant/accommodation">Accommodation</a>
									</li> -->
								</ul>
								<ul class="col-xs-6 no-padding">
									<li><a class="grey" href="<?php echo base_url(); ?>Guest/contact">Location</a>
									</li>
									<li><a class="grey" href="<?php echo base_url(); ?>Guest/contact">Contact</a>
									</li>
								</ul>
							</div>
						</div>
					</div><!-- .col-md-3 -->
					<!-- End Contact Widget -->

					
				</div><!-- .row -->

				<!-- Start Copyright -->
				<div class="copyright-section">
					<div class="row">
						<div class="col-md-6">
							<p>National English Olympics 2018</p>
						</div>
				</div>

			</div>
		</footer>
		
		
	</div>
	<!-- End Full Body Container -->

	<!-- Go To Top Link -->
	<a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

	<div id="loader">
		<div class="spinner">
			<div class="dot1"></div>
			<div class="dot2"></div>
		</div>
	</div>
</body>
<script>

$(document).ready(function() {
	var page=<?php echo json_encode($page); ?>;
	$("#home").removeClass("active");
	$("#competition").removeClass("active");
	$("#regis").removeClass("active");
	$('#'+page).addClass("active");

	$('.price').each(function() {
		$(this).html(numberFormat($(this).html()));
	});
} );

function numberFormat(x)
{
	return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

</script>
</html>