<?php 
    if($this->session->flashdata('addParticipant') != '') {
     ?>
        <div class="alert alert-success alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('addParticipant'); ?></strong>
        </div>
    <?php
     }

    if($this->session->flashdata('failedAddParticipant') != '') {
     ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('failedAddParticipant'); ?></strong>
        </div>
    <?php
     }
     if($this->session->flashdata('editParticipant') != '') {
     ?>
        <div class="alert alert-success alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('editParticipant'); ?></strong>
        </div>
    <?php
     }
     if($this->session->flashdata('failedEditParticipant') != '') {
     ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('failedEditParticipant'); ?></strong>
        </div>
    <?php
     }
?>

<div class="page-banner no-subtitle">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="white">My Fields</h1>
			</div>
		</div>
	</div>
</div>

<div class="container no-padding" id="confirm-list">
    <?php for($i=0;$i<count($fields);$i++){
      //if($i==0){
        ?>
        <h4 style="margin-bottom: 0.7em;">
        Your payment will be processed at 9 PM by Admin everyday.</h4>
          <div class="col-xs-6">
              <div class="call-action call-action-boxed call-action-style4 clearfix confirm-item">
                  <h4>Fields Name : <?php echo $fields[$i]->competition_name; ?></h4>
                  <div class="button-side" style="margin-top: 10px;">
                      <?php if($fields[$i]->status == 'registParticipant'){ ?>
                          <a href="<?php echo base_url().'Participant/regis_participant/'.$fields[$i]->transaction_id.'/'.$fields[$i]->competition_name; ?>" class="btn-system btn-large show-l">Register Participant</a>
                          <a href="<?php echo base_url().'Participant/regis_participant/'.$fields[$i]->transaction_id.'/'.$fields[$i]->competition_name; ?>" class="btn-system btn-large show-s">Register</a>
                      <?php } else if($fields[$i]->status == 'ready'){ ?>                              
                          <a href="<?php echo base_url().'/Competition/view_participant/'.$fields[$i]->transaction_id.'/'.$fields[$i]->competition_name; ?>" class="btn-system btn-large show-l">View Participant</a>
                          <a href="<?php echo base_url().'/Competition/view_participant/'.$fields[$i]->transaction_id.'/'.$fields[$i]->competition_name; ?>" class="btn-system btn-large show-s">View</a>
                      <?php } else if($fields[$i]->status == 'Confirm'){ ?>                              
                          <a class="btn-system btn-large show-l">Waiting the payment to be confirmed</a>
                          <a class="btn-system btn-large show-s">Wait confirmation</a>
                      <?php } ?>
                  </div>        
              </div>
          </div>
      <?php
        }
        //else {
         // if($fields[$i]->transaction_id!=$fields[$i-1]->transaction_id){?>
         <!--  <div class="col-xs-6">
              <div class="call-action call-action-boxed call-action-style4 clearfix confirm-item">
                  <h4>Fields Name : <?php echo $fields[$i]->competition_name; ?></h4>
                  <div class="button-side" style="margin-top: 10px;">
                      <?php if($fields[$i]->status == 'regisParticipant'){ ?>
                          <a href="<?php echo base_url().'Participant/regis_participant/'.$fields[$i]->transaction_id.'/'.$fields[$i]->competition_name; ?>" class="btn-system btn-large show-l">Register Participant</a>
                          <a href="<?php echo base_url().'Participant/regis_participant/'.$fields[$i]->transaction_id.'/'.$fields[$i]->competition_name; ?>" class="btn-system btn-large show-s">Register</a>
                      <?php } else if($fields[$i]->status == 'ready'){ ?>                              
                          <a href="<?php echo base_url().'/Competition/view_participant/'.$fields[$i]->transaction_id.'/'.$fields[$i]->competition_name; ?>" class="btn-system btn-large show-l">View Participant</a>
                          <a href="<?php echo base_url().'/Competition/view_participant/'.$fields[$i]->transaction_id.'/'.$fields[$i]->competition_name; ?>" class="btn-system btn-large show-s">View</a>
                      <?php } else if($fields[$i]->status == 'Confirm'){ ?>                              
                          <a class="btn-system btn-large show-l">Not yet confirmed by admin</a>
                          <a class="btn-system btn-large show-s">Wait confirmation</a>
                      <?php } ?>
                     
                  </div>        
              </div>
          </div> -->
      <?php// } }}
    //if(count($fields)==0){?>
      <!-- <div class="col-md-offset-2 col-md-8" style="margin-bottom:6em;">
            <div class="call-action call-action-boxed call-action-style4 clearfix confirm-item" style="text-align:center;">
                <h1 >You have no registered field</h1>
                <h4 style="margin-bottom: 0.7em;">
  Your payment will be processed everyday at 9 PM by admin</h4>
                <a href="<?php echo base_url(); ?>Competition" style="font-size: 1.3em;">Register Here</a>
            </div>
        </div> -->

    <?php  
   // }
    ?>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        setTimeout(function() {
          $(".alert").fadeOut().empty();
        }, 2500);
    });
</script>

 