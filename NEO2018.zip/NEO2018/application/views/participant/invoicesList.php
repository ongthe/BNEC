<?php if($this->session->flashdata('confirmPayment') != ''): ?>
	<div class="alert alert-success alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
		<strong><?php echo $this->session->flashdata('confirmPayment'); ?></strong>
	</div>
<?php endif ?>

<?php if($this->session->flashdata('failedConfirmPayment') != ''): ?>
	<div class="alert alert-danger alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
		<strong><?php echo $this->session->flashdata('confirmPayment'); ?></strong>
	</div>
<?php endif ?>

<div class="page-banner no-subtitle">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="white">TRANSACTION STATUS</h1>
			</div>
		</div>
	</div>
</div>

<div class="container" id="invoices-list">	

<img src="<?php echo base_url(); ?>assets/2018/images/warning.png" style="max-width: 50px !important;">
<span style="color: red; font-size: 16px; font-weight: bold;"> Please Notice!!!</span>
<br>
	<p align="justify" style="font-size:16px;margin-top: 20px;font-weight: bold;"> If you haven't paid, please transfer the fee to 
		<strong style="color: red;">BCA 604 2324 988 (Calvin Antony dan Joice Marcella)</strong>. 
		<br>
		Keep the transfer payment receipt -> Proceed to step 3 -> Accept
	</p>

	<p align="justify" style="font-size: 16px; font-weight: bold; margin-bottom: 20px;">
		Your payment will be processed at 09:00 PM by Admin everyday.</p>
	<table class="table" id="tblShow">
		<thead>
			<tr>
				<th>No.</th>
				<th>Transaction Number</th>
				<th>Transaction Date</th>
				<th>Fields</th>
				<th>Participant</th>
				<th>Status</th>
			</tr>
		</thead>
		<tbody>			
			<?php for($i=0;$i<count($transaction);$i++): ?>
				<tr>
				<td><?php echo $i+1; ?></td>
				<td><?php echo $transaction[$i]->transaction_id; ?></td>
				<?php $dateTemp = new DateTime($transaction[$i]->transaction_date);$date =$dateTemp->format('d M Y');?>
				<td><?php echo $date; ?></td>
				<td><?php echo $transaction[$i]->competition_name; ?></td>
				<td><?php if($transaction[$i]->transaction_id===NULL){echo 'Not Registered Yet';}else{echo "Registered";} ?></td>
				<td><?php if($transaction[$i]->status=='regisField'){echo "Unpaid";}else if($transaction[$i]->status=='Confirm'){echo "Waiting for payment to be confirmed";}if($transaction[$i]->status=='regisParticipant'){echo "Have to register participant";}if($transaction[$i]->status=='ready'){echo "Ready to compete";} ?></td>
				</tr>
			<?php endfor ?>
		</tbody>
	</table>
</div>

<!-- Modal -->
	<div class="modal fade" id="messageModal" role="dialog">
		<div class="modal-dialog">
		
			<!-- Modal content-->
			<div class="modal-content alert-bg" style="margin-top: 120px;">
				<div class="modal-header" style="border-bottom: 0;">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title" style="color: white; font-size: 16px;">Transfer Payment Receipt</h4>
				</div>
				<div class="modal-body">
					<p align="justify" style="color: white; font-size: 16px;">Please send the transfer payment receipt and your institution logo to <strong>binusenglishclub.as@gmail.com</strong> 
					<p align="justify" style="color: white; font-size: 16px;">#Note!!!</p>
<p align="justify" style="color: white; font-size: 16px;">Email Subject: Your Institution/School Name</p>
				</div>
				<div class="modal-footer" style="border-top: 0;">
					
					<a href="<?php echo base_url(); ?>Participant/send_email">
						<button type="button" class="btn btn-default">Send Now</button>
					</a>
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
			
		</div>
	</div>

<script type="text/javascript">
	$(document).ready(function()
	{
		$('#messageModal').modal('show');
		setTimeout(function() {
					$(".alert").fadeOut().empty();
				}, 3000);
	});
</script>
