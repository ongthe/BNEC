<?php date_default_timezone_set("Asia/jakarta"); ?>
<div class="page-banner no-subtitle">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="white">PAYMENT</h1>
			</div>
		</div>
	</div>
</div>

<div class="container call-action call-action-boxed call-action-style1 no-descripton clearfix" id="payment">
	<div class="col-md-12 payment-row">
		<div class="col-md-3">
			<b>Transaction Date</b>
		</div>
		<div class="col-md-3">
			: <?php echo date('F jS \, Y'); ?>
		</div>
	</div>
	<div class="col-md-12 payment-row">
		<div class="col-md-3">
			<b>Nama Sekolah</b>
		</div>
		<div class="col-md-9">
			: <?php echo $this->session->userdata('namaSMA'); ?>
		</div>
	</div>
	<div class="col-md-12 payment-row">
		<div class="col-md-3">
			<b>Fields</b>
		</div>
		<div class="col-md-4">
			: <?php echo $field->competition_name; ?>
		</div>
	</div>
	<div class="col-md-12 payment-row">
		<div class="col-md-3">
			<b>Price</b>
		</div>
		<div class="col-md-4">
			: <span><?php echo $field->competition_price; ?></span>
		</div>
		<!-- <div class="col-md-2">
			<b>Quantity</b>
		</div>
		<div class="col-md-3">
			: <?php echo $qty; ?>
		</div> -->
	</div>
	<div class="line col-md-12"></div>
	<!-- <div class="col-md-12 payment-row">
		<div class="col-md-offset-7 col-md-2">
			<b>Total</b>
		</div>
		<div class="col-md-3">
			: <?php echo $field->hargaKompetisi/* * $qty*/; ?>
		</div>
	</div> -->
	<div class="col-md-12 payment-row">
		<div class="col-md-12">
			<br><img src="<?php echo base_url(); ?>assets/2018/images/warning.png" style="max-width: 50px !important;">
			<span style="color: red; font-weight: bold;"> Please Notice!!!</span>
                        <br><p align="justify" style="font-size:0.8em;margin-top: 20px;font-weight: bold;"> If you haven't paid, please transfer the fee to <strong style="color: red;">BCA 604 2324 988 (Calvin Antony dan Joice Marcella)</strong>, keep the transfer payment receipt, and click accept.</p>
		</div>
	</div>

	<div class="button-side btn-form">
		<a href="<?php echo base_url(); ?>Competition" class="btn-system btn-large border-btn">Cancel</a>
		<a href="<?php echo base_url().'Payment/acceptTrans/'. $field->competition_id; ?>" class="btn-system btn-large" >Accept</a> 
	</div>
</div>
