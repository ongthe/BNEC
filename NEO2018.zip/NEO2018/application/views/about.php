<div class="page-banner no-subtitle">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="white">About Us</h1>
			</div>
		</div>
	</div>
</div>

<div class="container">
	<div id="about-bnec" class="col-md-12">
		<div class="col-md-7" id="binusenglishclub">
	      	<h4 class="classic-title"><span>Binus English Club</span></h4>
	      	<p align="justify">Established in 1992, BINUS English Club (BNEC) is the only English-based student organization in BINUS University. Every year, more than 1000 students register to be a part of BNEC. This Organization was awarded as "The Best Student Organization" by BINUS University for up to 7 times (2010, 2011, 2012, 2014, 2015, 2016, and 2017). Other than winning many English-related competitions, BNEC has also achieved an award from Guinness World Records for breaking a world record of "The Most People Doing Crosswords Simultaneously" with a number of 550 people.
	      	</p>
	      	<p align="justify">English Olympics is one of BNEC's most prestigious events. We have been conducting this event since 2004; it started with a Nation Wide English Olympics for 6 years. It then developed into a year of Southeast Asian English Olympics and lastly 4 years of Asian English Olympics with more than 500 participants from Indonesia, Singapore, Malaysia, Philippines, Hong Kong, Thailand, Vietnam, and Macau.
	      	</p>
	    </div>
	    <div class="col-md-5"> 
	    	<img src="<?php echo base_url(); ?>assets/2018/images/bnec.png" class="bnec">
	      	<!-- <div class="touch-slider" data-slider-navigation="true" data-slider-pagination="true">
	        	<div class="item"><img src="<?php echo base_url(); ?>assets/2018/images/benefit.jpg"></div>
	        	<div class="item"><img src="<?php echo base_url(); ?>assets/2018/images/benefit.jpg"></div>
	        	<div class="item"><img src="<?php echo base_url(); ?>assets/2018/images/benefit.jpg"></div>
	      	</div>  -->     
	    </div>
	</div>
	<div id="about-neo" class="col-md-12">
	    <div class="col-md-4"> 
	      	<img style="width: 100%; margin-left: 0%; margin-top: -30px;" src="<?php echo base_url(); ?>assets/2018/images/neo_circle.png" class="neo">     
	    </div>
	    <div class="col-md-8" id="nationalenglisholympics" style="padding-top: 32px;">
	      	<h4 class="classic-title"><span>National English Olympics</span></h4>
	      	<p align="justify" class='s11pt'>Seeing the potential of talents all across Indonesia, BNEC aims to recruit talents from Indonesia by holding the National English Olympics. NEO is a new event from BNEC, in which high school students from Indonesia will compete in 5 fields of competition (Debate, Speech, Scrabble, Newscasting, Storytelling).</p>
	      	<p align="justify" class='s11pt'>This year marks the second National English Olympics to be held at BINUS University Alam Sutera. It will be held on November 22<sup>nd</sup> - 25<sup>th</sup> 2018, holding the theme "Shaping Notions".</p>
	    </div>
	</div>
</div>