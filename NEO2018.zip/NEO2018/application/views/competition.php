<div class="page-banner no-subtitle">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="white">Competition</h1>
			</div>
		</div>
	</div>
</div>
<div class="container" id="competition-welcome">
	<div class="col-md-12">
		              
		<!-- Classic Heading -->
		<!-- <h4 class="classic-title"><span>Fields in National English Olympics</span></h4> -->

	</div>
</div>

<div class="container">
	<div class="col-md-12">
		<!-- Toggle -->
		<div class="panel-group" id="accordion">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#scrabble">
							<i class="fa fa-angle-up control-icon"></i>
							<h4 class="classic-title" style="text-decoration: none;"><i class="fa fa-pencil"></i> <span>Scrabble</span> <span style="margin-left:30px;">IDR 250,000 per person</span></h4>
						</a>
					</h4>
				</div>
				<div id="scrabble" class="panel-collapse collapse">
					<div class="panel-body">
						<div class="col-md-12">
							<div class="col-md-2">
								<div style="background-color: #111; border-radius: 100%;">
									<img src="<?php echo base_url(); ?>assets/2018/images/iconcompetition/scrabble.svg" class="competition-icon">
								</div>
							</div>	
							<div class="col-md-10">
								<div class="classic-testimonials testimoni-competition">
					                <div class="testimonial-content">
					                    <p>Scrabble is an art of jumbling letters into a word. Tactics combined with dexterity will lead you to victory and when it comes, you will be the champion. So, do you dare to take the victory with you? Go challenge yourself here!</p>		
					                    <a data-toggle="modal" data-target="#modalGeneral"><b>General Rules »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalScrabble"><b>Rules for Scrabble »</b></a>
					                </div>
					            </div>
							</div>
						</div>
					</div>
				</div>

				<div class="panel-heading">
					<h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#stortel">
							<i class="fa fa-angle-up control-icon"></i>
							<h4 class="classic-title"><i class="fa fa-pencil"></i><span>Storytelling</span><span style="margin-left:30px;">IDR 300,000 per person</span></h4>
						</a>
					</h4>
				</div>
				<div id="stortel" class="panel-collapse collapse">
					<div class="panel-body">
						<div class="col-md-12">	
							<div class="col-md-2">
								<div style="background-color: #111; border-radius: 100%;">
									<img src="<?php echo base_url(); ?>assets/2018/images/iconcompetition/storytelling.svg" class="competition-icon">
								</div>
							</div>						
							<div class="col-md-10">
								<div class="classic-testimonials testimoni-competition">
									<div class="testimonial-content">
										<p></p>
										<a data-toggle="modal" data-target="#modalGeneral"><b>General Rules »</b></a><br>
										<a data-toggle="modal" data-target="#modalStortel1"><b>Preliminary One: Prepared Story »</b></a><br>
										<a data-toggle="modal" data-target="#modalStortel2"><b>Preliminary Two: Tag Team »</b></a><br>
										<a data-toggle="modal" data-target="#modalStortel3"><b>Quarter Final: Hot Seat »</b></a><br>
										<a data-toggle="modal" data-target="#modalStortel4"><b>Semi Final: Fortune and Fate »</b></a><br>
										<a data-toggle="modal" data-target="#modalStortel5"><b>Final: Duel »</b></a><br>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="panel-heading">
					<h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#debate">
							<i class="fa fa-angle-up control-icon"></i>
							<h4 class="classic-title" ><i class="fa fa-pencil"></i> <span>Debate</span><span style="margin-left:30px;">IDR 600,000 per team (3 people)</span></h4>
						</a>
					</h4>
				</div>
				<div id="debate" class="panel-collapse collapse">
					<div class="panel-body">
						<div class="col-md-12">
							<div class="col-md-2">
								<div style="background-color: #111; border-radius: 100%;">
									<img src="<?php echo base_url(); ?>assets/2018/images/iconcompetition/debate.svg" class="competition-icon">
								</div>
							</div>	
							<div class="col-md-10">
								<div class="classic-testimonials testimoni-competition">
					                <div class="testimonial-content">
					                    <p>Debaters require to have skills in arguing, critical thinking, and also logical consistency.</p>
					                    <p>Not only that, analysing the opponent’s statement is also important in order to find the way to win the argument. You will learn those skills and gain mastery by joining the Debate field, so get ready to challenge yourself!</p>
					                    <p>Parliamentary Format : British Parliamentary</p>
					                    <p>Team Format : Each team consisting of 2 people</p>
					                    <a data-toggle="modal" data-target="#modalGeneral"><b>General Rules »</b></a><br>
					                    <!-- <a data-toggle="modal" data-target="#modalgajadi"><b>Rules for Debate »</b></a> -->
					                </div>
					            </div>
							</div>
						</div>
					</div>
				</div>


				<div class="panel-heading">
					<h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#speech">
							<i class="fa fa-angle-up control-icon"></i>
							<h4 class="classic-title" ><i class="fa fa-pencil"></i> <span>Speech</span><span style="margin-left:30px;">IDR 300,000 per person</span></h4>
						</a>
					</h4>
				</div>
				<div id="speech" class="panel-collapse collapse">
					<div class="panel-body">
						<div class="col-md-12">
							<div class="col-md-2">
								<div style="background-color: #111; border-radius: 100%;">
									<img src="<?php echo base_url(); ?>assets/2018/images/iconcompetition/speech.svg" class="competition-icon">
								</div>
							</div>	
							<div class="col-md-10">
								<div class="classic-testimonials testimoni-competition">
					                <div class="testimonial-content">
					                    <p>This field is all about public speaking, which involves speaking in front of hundreds or thousands of people listening. It takes to be inspiring, motivating, and also humorous at the same time to catch audience’s attention. Interested in those things? Come join our Speech field!</p>
					                    <a data-toggle="modal" data-target="#modalGeneral"><b>General Rules »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalSpeech1"><b>Preliminary One : Prepared Speech »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalSpeech2"><b>Preliminary Two : Table Topic »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalSpeech3"><b>Quarter Final : Extemporanous »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalSpeech4"><b>Semi Final : Evaluation Speech »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalSpeech5"><b>Final : Oratorical Speech »</b></a><br>
					                    <!-- <a data-toggle="modal" data-target="#modalSpeech2"><b>Preliminary Two: Table Topic >></b></a> -->
					                </div>
					            </div>
							</div>
						</div>
					</div>
				</div>

				<div class="panel-heading">
					<h4 class="panel-title">
						<a data-toggle="collapse" data-parent="#accordion" href="#news">
							<i class="fa fa-angle-up control-icon"></i>
							<h4 class="classic-title" ><i class="fa fa-pencil"></i> <span>Newscasting</span><span style="margin-left:30px;">IDR 300,000 per person</span></h4>
						</a>
					</h4>
				</div>
				<div id="news" class="panel-collapse collapse">
					<div class="panel-body">
						<div class="col-md-12">
							<div class="col-md-2">
								<div style="background-color: #111; border-radius: 100%;">
									<img src="<?php echo base_url(); ?>assets/2018/images/iconcompetition/newscasting.svg" class="competition-icon">
								</div>
							</div>	
							<div class="col-md-10">
								<div class="classic-testimonials testimoni-competition">
					                <div class="testimonial-content">
					                    <p>Learn how to act professionally in front of a camera through news read, live report, talk show, and many more.</p>
					                    <a data-toggle="modal" data-target="#modalGeneral"><b>General Rules »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalNews1"><b>Preliminary One : News Reading »</b></a><br>
					                    <a data-toggle="modal" data-target="#modalNews2"><b>Preliminary Two : Cultural News >></b></a><br>
					                    <a data-toggle="modal" data-target="#modalNews3"><b>Quarter Final : Live Report >></b></a><br>
					                    <a data-toggle="modal" data-target="#modalNews4"><b>Semifinal : News Reading + Interview >></b></a><br>
					                    <a data-toggle="modal" data-target="#modalNews5"><b>Final : Talkshow >></b></a> 	 
					                </div>
					            </div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $this->load->view('guest/modals'); ?>
