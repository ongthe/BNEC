<style type="text/css">
	li
	{
		font-size: 10pt;
		font-family: helvetica;
	}

	p
	{
		font-size: 10pt;
		line-height: 14pt;
		font-family: helvetica;
	}
</style>
<div class="modal fade modal-competition-all" id="modalGeneral" tabindex="-1" role="dialog" aria-labelledby="modalGeneral">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Rules for All NEO Participant</h4>
			</div>
			<div class="modal-body">
				<ol class="ol-number">
					<li>Participants are highly suggested to come at least 30 minutes before the Opening Ceremony and must re-register at the assigned location before the Opening Ceremony starts.</li>
					<li>Participants are highly recommended to attend the Coaching Clinic as their privilege to learn some tips and tricks that will be brought by our judges regarding the rounds.</li>
					<li>Participants who don't attend the Technical Meeting and Coaching Clinic won't be guaranteed to get further information from the committee outside of those sessions.</li>
					<li>All participants must arrive at the waiting room at least 15 minutes before the competition starts.</li>
					<li>All participants will be called 3 times when their turn comes up before being considered as a walk-out.</li>
					<li>Participants should remain outside the performing room that is designated by the committee until they are called to perform.</li>
					<li>Participants are not allowed to watch other participants' performance.</li>
					<li>Judges may (in their discretion) deduct 3 points from the total score in one round for violation of rules (except for timing). Judges may also disqualify participants for gross misconduct or ineligibility.</li>
					<li>Properties categorized as sharp tools or dangerous weapons, liquids, or powders that can litter the performing room are prohibited. </li>
					<li>Participants are suggested to bring their own stationery to support the necessary things.</li>
					<li>All judges’ decisions and results are considered as final.</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

<div class="modal fade modal-competition-all" id="modalScrabble" tabindex="-1" role="dialog" aria-labelledby="modalScrabble">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Rules for Scrabble</h4>
			</div>
			<div class="modal-body">
				<ol class="ol-number">
					<li>1 vs 1</li>
					<li>System: Tournament (Australian Draw & King-of-the-Hill)</li>
					<li>Total Rounds: 18 (No Elimination)</li>
					<li>This tournament will be rated by ISF</li>
					<li>Word Authority: CSW 15</li>
					<li>The rules will be based on <a href="http://www.wespa.org/rules/rulesv3.pdf" target="_blank">WESPA</a></li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

<div class="modal fade modal-competition-all" id="modalDebate" tabindex="-1" role="dialog" aria-labelledby="modalDebate">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Rules for Scrabble</h4>
			</div>
			<div class="modal-body">
				<ol class="ol-number">
					<li>1 vs 999</li>
					<li>Tournament System: Australian Draw & King of the Hill</li>
					<li>Total Rounds: 15 Rounds (No Elimination)</li>
					<li>Word Authority: CSW 15</li>
					<li>Penalty: 5 points per words that are actually allowable</li>
					<li>The rules will be based on WESPA</li>
					<li>Overtime: 5 minutes for each player</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

<div class="modal fade modal-competition-all" id="modalStortel1" tabindex="-1" role="dialog" aria-labelledby="modalStortel1">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Preliminary One: Prepared Story</h4>
			</div>
			<div class="modal-body">
				<p>For the first round you will tell us a story from your hometown, but they will have to tell us in a way that has a hero arc, where we can feel the hero develop throughout the story.</p>
				<p><b>Specific Rules:</b></p>
				<ol class="ol-number">
					<li>The story for this round shall be prepared by the participants, and should be modified from the original story.</li>
					<li>The performing time shall be 6 minutes long.</li>
					<li>There will be a sign shown to the performing participant at the fourth minute, fifth minute, as well as the last 30 seconds before the performing ends.</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

<div class="modal fade modal-competition-all" id="modalStortel2" tabindex="-1" role="dialog" aria-labelledby="modalStortel1">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Preliminary Two: Tag Team</h4>
			</div>
			<div class="modal-body">
				<p>You will teamed up into a group of 4 people, and tell a story consecutively within the time given. There will be a short story prepared by the committee to continue the story.</p>
				<p><b>Specific Rules:</b></p>
				<ol class="ol-number">
					<li>The random plot for this round will be given before the round begins.</li>
					<li>Participants have 30 seconds to continue the story before passing it to other teammate.</li>
					<li>Each participant must be at least chosen three times.</li>
					<li>In the story there are at least 2 interesting events.</li>
					<li>The performing time shall not be longer than 15 minutes long.</li>
					<li>There will be a sign shown to the performing participant at the last fifth minute, the last third minute and the last minute before the performing ends.</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

<div class="modal fade modal-competition-all" id="modalStortel3" tabindex="-1" role="dialog" aria-labelledby="modalStortel1">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Quarter Final: Hot Seat</h4>
			</div>
			<div class="modal-body">
				<p>You will tell us a famous story, but here's a twist, there will a number of properties on chairs, you will have to tell you story using all of the properties in order without straying too far from the story.</p>
				<p><b>Specific Rules:</b></p>
				<ol class="ol-number">
					<li>The properties will be shown after the participant has entered the performing room.</li>
					<li>The performing time shall be 6 minutes long.</li>
					<li>Participants will have to try to use all of the properties</li>
					<li>The theme will be ghost stories.</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

<div class="modal fade modal-competition-all" id="modalStortel4" tabindex="-1" role="dialog" aria-labelledby="modalStortel1">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Semi Final: Fortune and Fate</h4>
			</div>
			<div class="modal-body">
				<p>For the semi final round, participants will take a ballot with 3 different categories (Place, Condition, and Properties). You will narrate the story based on the ballot you have got. The point of this round is to challenge you to make a good strategy and also be creative to narrate the story and make it to be interesting.</p>
				<p><b>Specific Rules:</b></p>
				<ol class="ol-number">
					<li>The performing time shall be 6 minutes long.</li>
					<li>There will be a sign shown to the performing participant at the fourth minute, fifth minute, as well as the last 30 seconds before the performing ends.</li>
					<li>The theme will be fairy tales</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

<div class="modal fade modal-competition-all" id="modalStortel5" tabindex="-1" role="dialog" aria-labelledby="modalStortel1">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Final: Duel</h4>
			</div>
			<div class="modal-body">
				<p>You will face the duel version of storytelling, one versus one in battling on telling the story with the short story determined by the judges.</p>
				<p><b>Specific Rules:</b></p>
				<ol class="ol-number">
					<li>Participants have 30 seconds to continue the story before the judge passing it to other participant.</li>
					<li>There will be plot twist in the middle of the story.</li>
					<li>The performing time shall be 12 minutes per round.</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->


<div class="modal fade modal-competition-all" id="modalgajadi" tabindex="-1" role="dialog" aria-labelledby="modalgajadi">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">COMING SOON</h4>
			</div>
			<div class="modal-body">
				<p>We will write our specific rules later</p>
				<!-- <p><b>Specific Rules:</b></p> -->
				<!-- <ol class="ol-number"> -->
					<!-- <li>The random plot for this round will be given before the round begins.</li> -->
					<!-- <li>The performing time shall be 7 minutes in length.</li> -->
					<!-- <li>There will be a sign shown to the performing participant at the fifth minute, sixth minute, as well as the last 30 seconds before the performing ends.</li> -->
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

<div class="modal fade modal-competition-all" id="modalSpeech1" tabindex="-1" role="dialog" aria-labelledby="modalSpeech1">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Preliminary One: Prepared Speech</h4>
			</div>
			<div class="modal-body">
				<p>You will prepare the speech based on the theme given. You can use your own creativity to create the speech to become more impressive and inspiring.</p>
				<p><b>Specific Rules:</b></p>
				<ol class="ol-number">
					<li>Theme : Shaping Notions.</li>
					<li>The speech may include references from other sources as long as it’s not plagiarized.</li>
					<li>Participants are not allowed to bring any forms of note.</li>
					<li>The performing time shall be 5 minutes long.</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->


<div class="modal fade modal-competition-all" id="modalSpeech2" tabindex="-1" role="dialog" aria-labelledby="modalSpeech2">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Preliminary Two: Table Topic</h4>
			</div>
			<div class="modal-body">
				<p>You will be given a random topic, you will then have to present the best speech possible given the small amount of preparation.</p>
				<p><b>Specific Rules:</b></p>
				<ol class="ol-number">
					<li>Topics will be given before performing.</li>
					<li>The theme will be randomly given to each participant.</li>
					<li>The performing time shall be 2.5 minutes long.</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

<div class="modal fade modal-competition-all" id="modalSpeech3" tabindex="-1" role="dialog" aria-labelledby="modalSpeech2">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Quarter Final : Extemporanous</h4>
			</div>
			<div class="modal-body">
				<p>You will be given an article and some time to prepare, you will then have to deliver the speech as if they have mastered the topic.</p>
				<p><b>Specific Rules:</b></p>
				<ol class="ol-number">
					<li>Topics will be given in the quarantine room.</li>
					<li>The performing time shall be 5 minutes long.</li>
					<li>You are allowed to bring notes.</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

<div class="modal fade modal-competition-all" id="modalSpeech4" tabindex="-1" role="dialog" aria-labelledby="modalSpeech2">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Semi Final : Evaluation Speech</h4>
			</div>
			<div class="modal-body">
				<p>You will be given a sample speech video in which contestants will observe and try to evaluate. This will test on how you give constructive feedback effectively.</p>
				<p><b>Specific Rules:</b></p>
				<ol class="ol-number">
					<li>The sample speech video will be determined by committee.</li>
					<li>The performing time shall be 5 minutes long.</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

<div class="modal fade modal-competition-all" id="modalSpeech5" tabindex="-1" role="dialog" aria-labelledby="modalSpeech2">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Final : Oratorical Speech</h4>
			</div>
			<div class="modal-body">
				<p>There will be several topics that can be chosen from in which participants are required to bring in the form of speech. From the determined topic, participants have to bring it impressively and professionally pretending to be an orator. For example, expertizing in health, in which you will have a speech regarding what you have researched in front of the public.</p>
				<p><b>Specific Rules:</b></p>
				<ol class="ol-number">
					<li>The topics will be given beforehand.</li>
					<li>Participants will have 30 minutes to prepare.</li>
					<li>The performing time shall be 5 minutes long.</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

<div class="modal fade modal-competition-all" id="modalNews1" tabindex="-1" role="dialog" aria-labelledby="modalNews1">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Preliminary One: News Reading</h4>
			</div>
			<div class="modal-body">
				<p>You will prepare then perform 2 stories about the topic given</p>
				<ol class="ol-number">
					<li>Topic: Asian Games -Palembang 2018</li>
					<li>Participants will deliver two article about Asian Games Jakarta-Palembang 2018.</li>
					<li>Performing Time: 5 minutes.</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->


<div class="modal fade modal-competition-all" id="modalNews2" tabindex="-1" role="dialog" aria-labelledby="modalNews2">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Preliminary Two: Cultural News</h4>
			</div>
			<div class="modal-body">
				<p>You will be choose a couple random topics, after being given some time to prepare your news reading, you will then perform in front of the judges.</p>
				<ol class="ol-number">
					<li>Participants must pick 2 out of 6 categories such as food, travel destination, tradition, history, traditional art and hero.</li>
					<li>Participants are allowed to bring script to the performing room.</li>
					<li>Performing Time: 5 minutes.</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

<div class="modal fade modal-competition-all" id="modalNews3" tabindex="-1" role="dialog" aria-labelledby="modalNews3">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Quarter Final : Live Report</h4>
			</div>
			<div class="modal-body">
				<p>You will be given a topic concerning a certain situation, you will then have to perform as if your are actually there on the spot.</p>
				<ol class="ol-number">
					<li>Participants must create their own report.</li>
					<li>The condition will be given before performing in the quarantine room.</li>
					<li>Not allowed to bring the script to the performing room.</li>
					<li>Performing Time: 5 minutes.</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

<div class="modal fade modal-competition-all" id="modalNews4" tabindex="-1" role="dialog" aria-labelledby="modalNews4">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Semifinal : Live Report</h4>
			</div>
			<div class="modal-body">
				<p>You will be given a situation and a source for you to interview, you will have to present their news and interview their source.</p>
				<ol class="ol-number">
					<li>Article and detail about the guest will be given at the quarantine room before participants perform.</li>
					<li>Participants will do the news reading and continue with interview.</li>
					<li>You are allowed to bring script to the performing room.</li>
					<li>Performing Time: 7 minutes.</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

<div class="modal fade modal-competition-all" id="modalNews5" tabindex="-1" role="dialog" aria-labelledby="modalNews5">
	<div class="modal-dialog modal-lg" role="document" class="modal-competition">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Final : Talkshow</h4>
			</div>
			<div class="modal-body">
				<p>You will be given a topic and a background for the topic, you will then have to explain the topic to the audience and then invite the source for a brief Q&A session.</p>
				<ol class="ol-number">
					<li>There will be a special guest.</li>
					<li>Participants will be given CV and resume of the guest before performing in the quarantine room.</li>
					<li>Participants must create their own talk show based on the CV and Resume given.</li>
					<li>Participants are allowed to bring script to the performing room.</li>
					<li>Performing Time: 8 minutes.</li>
				</ol>
			</div>
			<div class="modal-footer">				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog modal-lg -->
</div><!-- /.modal -->

