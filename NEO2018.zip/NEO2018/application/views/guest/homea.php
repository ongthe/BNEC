<?php if(isset($login)){ if($login){?>
<div class="alert alert-danger">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
    </button>
    <strong>Invalid username or password!</strong>
</div>
<?php }} ?>

<?php 
     if($this->session->flashdata('addSchool') != '') {
     ?>
        <div class="alert alert-success alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('addSchool'); ?></strong>
        </div>
    <?php
     }

     if($this->session->flashdata('failedAddSchool') != '') {
     ?>
        <div class="alert alert-success alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('addSchool'); ?></strong>
        </div>
    <?php
     }
 ?>

        <!-- Start Home Page Slider -->
        <section id="home">
            <!-- Carousel -->
            <div id="main-slide" class="carousel slide" data-ride="carousel">

                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#main-slide" data-slide-to="0" class="active"></li>
                    <li data-target="#main-slide" data-slide-to="1"></li>
                    <li data-target="#main-slide" data-slide-to="2"></li>
                </ol>
                <!--/ Indicators end-->

                <!-- Carousel inner -->
                <div class="carousel-inner sliderbg">

                    <div class="item active">
                        <img class="img-responsive transparent" src="<?php echo base_url(); ?>assets/2017/images/slider/bg.jpg" alt="slider">
                        <div class='slider-content'>
                            <img class='animated3 slider-logo' src="<?php echo base_url(); ?>assets/2017/images/neo.png" alt="slider" >
                        </div>
                    </div>
                    <!--/ Carousel item end -->
                    <!-- <div class="item">
                        <img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/slider/bg2.jpg" alt="slider">
                    </div> -->
                    <div class="item">

                        <img class="img-responsive transparent" src="<?php echo base_url(); ?>assets/images/slider/bg.jpg" alt="slider">
                        <div class="slider-content">
                            <div class="col-md-12 text-center slider-icons17">
                                <!-- <br> -->
                                <h3 class="animated3 titleMobile" style="margin-top: 35px;">
                                    <span>5 Fields of Competitions</span>
                                </h3>
                                
                                <div style='margin: auto' class='slider-icon-wrapper'>
                                    <div class='competition-slider'>
                                        <a href="<?php echo base_url(); ?>Guest/competition#news">
                                            <div class="animatedF0 ">
                                                <div class='floating0'>
                                                    <div class='compet-container'>
                                                        <img src="<?php echo base_url(); ?>assets/2017/images/iconcompetition/slider/newscasting.png" alt='slider' class='compet' id='competL0'>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class='animatedT0'>
                                                <h5 id='competT0'>Newscasting</h5> <!-- 1 -->
                                            </div>
                                        </a>
                                    </div>
                                    <div class='competition-slider'>
                                        <a href="<?php echo base_url(); ?>Guest/competition#scrabble">
                                            <div class="animatedF1">     
                                                <div class='floating1'>
                                                    <div class='compet-container'>
                                                        <img src="<?php echo base_url(); ?>assets/2017/images/iconcompetition/slider/scrabble.png" alt='slider' class='compet' id='competL1'>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class='animatedT1'>
                                                <h5 id='competT1'>Scrabble</h5> <!-- 2 -->
                                            </div>
                                        </a>
                                    </div>
                                    <div class='competition-slider'>
                                        <a href="<?php echo base_url(); ?>Guest/competition#speech">
                                            <div class="animatedF2">
                                                <div class='floating2'>
                                                    <div class='compet-container'>
                                                        <img src="<?php echo base_url(); ?>assets/2017/images/iconcompetition/slider/speech.png" alt='slider' class='compet' id='competL2'>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class='animatedT2'>
                                                <h5 id='competT2'>Speech</h5> <!-- 3 -->
                                            </div>
                                        </a>
                                    </div>
                                    <div class='competition-slider'>
                                        <a href="<?php echo base_url(); ?>Guest/competition#stortel">
                                            <div class="animatedF3">                   
                                                <div class='floating3'>
                                                    <div class='compet-container'>
                                                        <img src="<?php echo base_url(); ?>assets/2017/images/iconcompetition/slider/storytelling.png" alt='slider' class='compet' id='competL3'>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class='animatedT3'>
                                                <h5 id='competT3'>Storytelling</h5>
                                            </div>
                                        </a>
                                    </div>
                                    <div class='competition-slider'>
                                        <a href="<?php echo base_url(); ?>Guest/competition#debate">
                                            <div class="animatedF4">
                                            <div class='floating4'>
                                                    <div class='compet-container'>
                                                        <img src="<?php echo base_url(); ?>assets/2017/images/iconcompetition/slider/debate.png" alt='slider' class='compet' id='competL4'>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class='animatedT4'>
                                                <h5 id='competT4'>Debate</h5>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <br style='clear: both;'>
                                <h4 class="animated3 titleMobile" style="margin-top: 0.8em;">
                                    <span>Click the icons for more info</span>
                                </h4>
                                <!-- <p class="animated4"><a href="<?php echo base_url(); ?>Guest/competition" class="slider btn btn-system btn-large">More Info</a> -->
                                <!-- </p> -->
                            </div>
                        </div>
                    </div>
                    <div class="item">

                        <img class="img-responsive transparent" src="<?php echo base_url(); ?>assets/2017/images/slider/bg.jpg" alt="slider">
                        <div class="slider-content">
                            <div class="col-md-12 text-center">
                                <h2 class="animatedF2 white">
                                  <!-- <span><strong>The</strong> 2016 </span> -->
                                  <img src="<?php echo base_url(); ?>assets/2017/images/iconcompetition/observer.png" alt='slider' class='obs floating4'>
                                </h2>
                                <h3 class="animated3" style="margin-top: 35px;">
                                    <span>Want to observe?</span>
                                </h3>
                                <h4 class="animated3 obs-detail">
                                    <span>You can register as observer right on website</span>
                                </h4>
                                <p class="animated4"><a href="<?php echo base_url(); ?>Guest/registration" class="slider btn btn-system btn-large">Register Now</a>
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="item">
                        <img class="img-responsive" src="<?php echo base_url(); ?>assets/2017/images/slider/bg1.jpg" alt="slider">
                        <div class="slider-content">
                            <div class="col-md-12 text-center">
                                <h2 class="animated7 white">
                                <span>The way of <strong>Success</strong></span>
                            </h2>
                                <h3 class="animated8 white">
                                <span>Why you are waiting?</span>
                            </h3>   
                                <div class="">
                                    <a class="animated4 slider btn btn-system btn-large btn-min-block" href="<?php echo base_url(); ?>Guest/about">Read More</a>
                                    <a class="animated4 slider btn btn-default btn-min-block" href="<?php echo base_url(); ?>Guest/registration">Join</a>
                                </div>
                            </div>
                        </div>
                    </div> -->
                    <!--/ Carousel item end -->
                </div>
                <!-- Carousel inner end-->

                <!-- Controls -->
                <a class="left carousel-control" href="#main-slide" data-slide="prev">
                    <span><i class="fa fa-angle-left"></i></span>
                </a>
                <a class="right carousel-control" href="#main-slide" data-slide="next">
                    <span><i class="fa fa-angle-right"></i></span>
                </a>
            </div>
            <!-- /carousel -->
        </section> 
        <!-- End Home Page Slider -->

        <section class="home-field">
            <div class="container-content" style="padding-top: 3em !important; padding-bottom: 1em !important;">
                <h1 style="text-align:center; padding-bottom: 1.5em;">Presented By</h2>
                <div>    
                    <!-- <a href="<?php echo base_url(); ?>Guest/competition" id="competition"> -->
                    <a href="http://binus.ac.id" id="competition">
                        <div class="col-md-6 col-sm-6 col-xs-12 service-box service-center sponsorS" data-animation="fadeIn" data-animation-delay="01">
                            <div class="service-icon">
                                <!-- <img class="icon-competition" src="<?php echo base_url(); ?>assets/2017/images/sponsors/sponsorNaN.png"> -->
                                <img class="icon-competition" src="<?php echo base_url(); ?>assets/2017/images/binus.png">
                            </div>
                            <div class="service-content">
                                <h4>BINUS University</h4>                            
                            </div>
                        </div>
                    </a>
                    <!-- <a href="<?php echo base_url(); ?>Guest/competition" id="competition"> -->
                    <a href="http://mybnec.org" id="competition">
                        <div class="col-md-6 col-sm-6 col-xs-12 service-box service-center sponsorS" data-animation="fadeIn" data-animation-delay="01">
                            <div class="service-icon">
                                <!-- <img class="icon-competition" src="<?php echo base_url(); ?>assets/2017/images/sponsors/sponsorNaN.jpg"> -->
                                <img class="icon-competition" src="<?php echo base_url(); ?>assets/2017/images/bnec.png">
                            </div>
                            <div class="service-content">
                                <h4>BINUS English Club</h4>                            
                            </div>
                        </div>
                    </a>
                    <!-- <a href="<?php echo base_url(); ?>Guest/competition" id="competition">
                        <div class="col-md-3 col-sm-6 col-xs-12 service-box service-center sponsorS" data-animation="fadeIn" data-animation-delay="01">
                            <div class="service-icon">
                                <img class="icon-competition" src="<?php echo base_url(); ?>assets/2017/images/sponsors/sponsorNaN.png">
                            </div>
                            <div class="service-content">
                                <h4>...</h4>                            
                            </div>
                        </div>
                    </a>
                    <a href="<?php echo base_url(); ?>Guest/competition" id="competition">
                        <div class="col-md-3 col-sm-6 col-xs-12 service-box service-center sponsorS" data-animation="fadeIn" data-animation-delay="01">
                            <div class="service-icon">
                                <img class="icon-competition" src="<?php echo base_url(); ?>assets/2017/images/sponsors/sponsorNaN.png">
                            </div>
                            <div class="service-content">
                                <h4>...</h4>                            
                            </div>
                        </div>
                    </a> -->
                </div>
            </div>

        </section>

        
        <div class="section short-about" style='clear: both;'>
            <div class="container">
                <div class="section-video-content text-center">

                    <h1>
                        National English Olympics
                    </h1>
                    <h4>November 30<sup>th</sup> - December 4<sup>th</sup>, 2017</h4>
                    <div class="classic-testimonials" id="about-testimoni">
                        <div class="testimonial-content">
                            <p class="white">Seeing the potential talents from all across Indonesia, BNEC aims to recruit talents from Indonesia by holding the National English Olympics (NEO). NEO is a new event from BNEC, in which high school students from Indonesia will compete in 5 fields of competition (Debate, Speech, Scrabble, Newscasting, or Storytelling).</p>
                            <p class="white">The 2017 National English Olympics will be held at BINUS University on November 30<sup>th</sup> - December 4<sup>th</sup>, 2017 with the theme being "Break Through the Limit".</p>
                        </div>
                    </div>
                    <a href="<?php echo base_url(); ?>Guest/about" class="btn-system btn-large"><i class="fa fa-tasks"></i> Read More</a>                    

                </div>
            </div>
        </div>

        <div class="section benefit">
            <div class="container">
                <div class="section-video-content text-center">                   
                    <h1 style="margin-bottom:2em;">
                        What You Get From NEO
                    </h1>
                    <div id="benefits" class=''>
                         <!-- 1 -->
                        <!-- <div class="col-md-12">
                            <div class="col-md-6">
                                <img src="<?php echo base_url(); ?>assets/2017/images/benefit/scholarship.png">
                            </div>
                            <div class="col-md-6 classic-testimonials">
                                <div class="testimonial-content">
                                    <h2 class="middle-content" style="margin-top: 15%;">Scholarship</h2>
                                    <p>The finalists of each field will have the chance to get scholarship from Binus University for up to 4 years of free tuition fee, admission fee, and others!
                                    </p>
                                </div>
                            </div>
                        </div> -->
                        <!-- 2 -->
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style='margin-bottom: 20px;'>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 classic-testimonials" id="aeo_ticket">
                                <div class="testimonial-content">
                                    <h2 class="middle-content" style="margin-top: 10%;">Free ticket to The 2018 AEO</h2>
                                    <p>The champion from each field will be provided with a free registration fee ticket to join the Asian scale english olympics competed by around 10 countries from Asia each year!
                                    </p>
                                    <a href="http://aeo.mybnec.org/" class="btn-system btn-large" style="margin-top:1em;">for more information about previous AEO, click here</a>
                                </div>                                
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <a href="http://aeo.mybnec.org/"><img src="<?php echo base_url(); ?>assets/2017/images/benefit/aeo.jpg"></a>
                            </div>
                        </div>
                         <!-- 4 -->
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" id="money">
                                <img src="<?php echo base_url(); ?>assets/2017/images/benefit/money.png">
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 classic-testimonials">
                                <div class="testimonial-content">
                                    <h2 class="middle-content" style="margin-top: 15%;">Cash as a prize</h2>
                                    <p>Top 3 winners of each field will get cash as prize!</p>
                                </div>
                            </div>
                        </div>     
                        <!-- 4 -->
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 classic-testimonials" id="trophy_medal">
                                <div class="testimonial-content">
                                    <h2 class="middle-content">Trophies and Medals</h2>
                                    <p>The top 3 winners of each fields will get a trophy and medal each! Moreover, the high school that achieves the most medals and trophies which is accumulated by their scores will attain The 2016 NEO Institutional Champion trophy.</p>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <img src="<?php echo base_url(); ?>assets/2017/images/benefit/trophy_medal.png">
                            </div>
                        </div>                   
                        <!-- 3 -->
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" id="map">
                                <img src="<?php echo base_url(); ?>assets/2017/images/benefit/map.jpg">
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 classic-testimonials">
                                <div class="testimonial-content">
                                    <h2 class="middle-content" style="margin-top: 15%;">National Experience</h2>
                                    <p>Experience competing with people from various backgrounds all over Indonesia.</p>
                                </div>
                            </div>
                        </div>
                        <!-- 4 -->
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 classic-testimonials" id="networking">
                                <div class="testimonial-content col-md-12">
                                    <h2 class="middle-content">Networking Expansion</h2>
                                    <p>With a population over 260 million, Indonesia is unquestionably a country with millions of talents. It's your chance to meet all these talents and improve yourself!</p>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <img src="<?php echo base_url(); ?>assets/2017/images/benefit/globee.jpg">
                            </div>
                        </div>                     
                        
                    </div>

                    <a href="<?php echo base_url(); ?>Guest/registration" class="btn-system btn-large" id="join" style="font-size:2em;"><i class="fa fa-plus-circle"></i> Join Now</a>

                </div>
            </div>
        </div>

        <?php $this->load->view('frontend/modalLogin'); ?>

        
<script type="text/javascript">
    $(document).ready(function(){/*
        $('.carousel-inner').height($(window).height()*0.85);
        $('.carousel-inner>.item>img, .carousel-inner>.item>a>img').height($(window).height()*0.85);*/
        $('#benefits img').css('max-height', '299px');
        $('#benefits .testimonial-content').height($('#benefits img').height()*0.9);
        setTimeout(function() {
          $(".alert").fadeOut().empty();
        }, 3000);

    });
</script>