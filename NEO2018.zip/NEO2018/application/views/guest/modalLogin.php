<div class="modal fade" id="modalLogin" tabindex="-1" role="dialog" aria-labelledby="modalDelete">
  <div class="modal-dialog" role="document" id="modal-login">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Sign In</h4>
      </div>
      <div class="modal-body">
        <form role="form" class="contact-form" id="login-form" action="<?php echo base_url(); ?>Login/login" method="post">
          <div class="form-group">
            <div class="controls">
              <input type="text" placeholder="Email" name="username" required>
            </div>
          </div>
          <div class="form-group">
            <div class="controls">
              <input type="password" placeholder="Password" name="password" required>
            </div>
          </div>
      </div>
      <div class="modal-footer">
        <button type="submit" id="submit" class="btn-system btn-large">Sign In</button>
        </form>
        <a href="<?php echo base_url(); ?>Guest/registration" class="btn-system btn-large">Register</a>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
