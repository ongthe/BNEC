<?php 
    if($this->session->flashdata('addSchool') != '') {
     ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('addSchool'); ?></strong>
        </div>
    <?php
     }
?>

<style type="text/css">
.nav-tabs > li.active > a, .nav-tabs > li.active > a:hover, .nav-tabs > li.active > a:focus{
    border-color: #00787e;
    background: #00787e;
    color: white;
}
td{
    font-weight: bold;
}
</style>

<div class="page-banner no-subtitle">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="white">Semifinal Announcement</h1>
            </div>
        </div>
    </div>
</div>

<div class="container" id="regis-school">
    <div class="tabs-section">                            
        <!-- Nav Tabs -->
        <ul class="nav nav-tabs">
           
            <li class="active"><a href="#tab-2" data-toggle="tab"><i class="fa fa-pencil"></i>Story Telling</a></li>
            <li><a href="#tab-3" data-toggle="tab"><i class="fa fa-pencil"></i>Debate</a></li>
            <li><a href="#tab-4" data-toggle="tab"><i class="fa fa-pencil"></i>Speech</a></li>
            <li><a href="#tab-5" data-toggle="tab"><i class="fa fa-pencil"></i>Newscasting</a></li>
             <li><a href="#tab-1" data-toggle="tab"><i class="fa fa-pencil"></i>Scrabble</a></li>
        </ul>
                
        <!-- Tab panels -->
        <div class="tab-content" style="border: 1px solid #ce1d54;">
            <!-- Tab Content 1 -->
            <div class="tab-pane fade" id="tab-1">    <h2>No Elimination</h2>         
                
            </div>
            <!-- Tab Content 2 -->
            <div class="tab-pane fade in active" id="tab-2">                
                <table class="table" id="tblShow" style="margin:3em 0;">
                    <thead>
                        <tr>
                            <th>No.</th>
                            
                            <th>Participant Name</th>
                            <th>School Name</th>
                        </tr>
                    </thead>
                    <tbody>                    
                        <tr>                
                            <td>1.</td>
                            <td>Adelia Putri</td>
                            <td>SMKN 18 Jakarta</td>
                        </tr>
                        <tr>                
                            <td>2.</td>
                            <td>Alexia Deva Pane</td>
                            <td>Sekolah Pelita Harapan SC</td>
                        </tr>
                        <tr>                
                            <td>3.</td>
                            <td>Almyra Luna Kamilla</td>
                            <td>SMAN 29 Jakarta</td>
                        </tr>
                        <tr>                
                            <td>4.</td>
                            <td>Amanina Zulfati Fakhira</td>
                            <td>SMAN 1 Samarinda</td>
                        </tr>
                        <tr>
                            <td>5.</td>
                            <td>Deeva Zevana</td>
                            <td>IIHS Jakarta</td>
                        </tr>
                        <tr>
                            <td>6.</td>
                            <td>Jihan Amirah Rafidah</td>
                            <td>SMA IIHS</td>
                        </tr>
                        <tr>
                            <td>7.</td>
                            <td>Rania Keyza Tsabita</td>
                            <td>SMAN 2 Tanggerang Selatan</td>
                        </tr>
                        <tr>
                            <td>8.</td>
                            <td>Ratu Bintang A.A.</td>
                            <td>SMAN 78 Jakarta</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <!-- Tab Content 3 -->
            <div class="tab-pane fade" id="tab-3">                
                <table class="table" id="tblShow" style="margin:3em 0;">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>School Name</th>
                        </tr>
                    </thead>
                    <tbody>                    
                        <tr>       
                        <tr>                
                            <td>1.</td>
                            <td>SMAN 3 Samarinda</td>
                        </tr>       
                        <tr>                
                            <td>2.</td>
                            <td>SMA Mondial Batam</td>
                        </tr>  
                        <tr>                
                            <td>3.</td>
                            <td>SMAN 2 Tanggerang Selatan</td>
                        </tr>
                            <td>4.</td>
                            <td>SMAN 1 Samarinda</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <!-- Tab Content 4 -->
            <div class="tab-pane fade" id="tab-4">                
                <table class="table" id="tblShow" style="margin:3em 0;">
                    <thead>
                        <tr>
                            <th>No.</th>
                            
                            <th>Participant Name</th>
                            <th>School Name</th>
                        </tr>
                    </thead>
                    <tbody>                    
                        <tr>                
                            <td>1.</td>
                            <td>Ghiffary Yovandika Anwarry Fadhillah</td>
                            <td>SMA Islam Terpadu Iqra</td>
                        </tr>
                        <tr>                
                            <td>2.</td>
                            <td>Maura Pasya Putri Chairul</td>
                            <td>SMA Negeri 1 Samarinda</td>
                        </tr>
                        <tr>                
                            <td>3.</td>
                            <td>Naila Zafira Wilson</td>
                            <td>SMA Kharisma Bangsa</td>
                        </tr>
                        <tr>                
                            <td>4.</td>
                            <td>Achmad Raihan Tharivandi</td>
                            <td>SMAN 85</td>
                        </tr>
                        <tr>                
                            <td>5.</td>
                            <td>Calmness Felia Halim</td>
                            <td>SMA Mondial</td>
                        </tr>
                        <tr>                
                            <td>6.</td>
                            <td>Rachel Rebecca</td>
                            <td>SMA Mondial</td>
                        </tr>
                        <tr>                
                            <td>7.</td>
                            <td>Erza Tegar Hati</td>
                            <td>SMA Negeri 3 Samarinda</td>
                        </tr>
                        <tr>                
                            <td>8.</td>
                            <td>Dimas Randy Tirtoajie</td>
                            <td>International Islamic High School</td>
                        </tr>
                        <tr>                
                            <td>9.</td>
                            <td>Mega Yanti</td>
                            <td>SMA Maitreyawira</td>
                        </tr>
                        <tr>                
                            <td>10.</td>
                            <td>Viviani</td>
                            <td>SMK Negeri 1 Tanjungpinang Kepulauan Riau</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <!-- Tab Content 5 -->
            <div class="tab-pane fade" id="tab-5">                
                <table class="table" id="tblShow" style="margin:3em 0;">
                    <thead>
                        <tr>
                            <th>No.</th>
                            
                            <th>Participant Name</th>
                            <th>School Name</th>
                        </tr>
                    </thead>
                    <tbody>                    
                        <tr>                
                            <td>1.</td>
                            <td>Sabrina Fortunella Toding</td>
                            <td>SMAN 3 Samarinda</td>
                        </tr>              
                        <tr>                
                            <td>2.</td>
                            <td>Tinezia Putri</td>
                            <td>SMA 29 Jakarta</td>
                        </tr>              
                        <tr>                
                            <td>3.</td>
                            <td>Anisa Rana Syahira</td>
                            <td>SMA 3 Samarinda</td>
                        </tr>              
                        <tr>                
                            <td>4.</td>
                            <td>Anisya Istiadzah Candraningtyas</td>
                            <td>SMAN 2 Tanggerang Selatan</td>
                        </tr>              
                        <tr>                
                            <td>5.</td>
                            <td>Melvin</td>
                            <td>SMKN 1 Tanjung Pinang</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
            <!-- End Tab Panels -->
             
    </div>
</div>
