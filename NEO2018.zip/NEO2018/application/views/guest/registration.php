<?php 
    if($this->session->flashdata('addSchool') != '') {
     ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('addSchool'); ?></strong>
        </div>
    <?php
     }
?>

<div class="page-banner no-subtitle">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="white">Registration Form</h1>
            </div>
        </div>
    </div>
</div>

<div class="container call-action call-action-boxed call-action-style1 no-descripton clearfix" id="regis-school">
	<form role="form" class="contact-form" id="confirm-form" method="post" action="<?php echo base_url(); ?>Guest/addSchool">
		<div class="checkbox">
			<div class="col-md-3">
				<label>School Name :</label>
		  	</div>
		  	<div class="col-md-9">                
		  	   <input type="text" placeholder="School Name" name="schoolName" required>
            </div>
		</div>
        <div class="form-group">
            <div class="controls">
            	<div class="col-md-3">
					<label>School Address :</label>
			  	</div>
			  	<div class="col-md-9">
            		<textarea rows="3"  placeholder="School Address" name="address" style="width:100%;" required></textarea>
            	</div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
            	<div class="col-md-3">
					<label>School Email :</label>
			  	</div>
			  	<div class="col-md-9">
            		<input type="email" placeholder="School Email" name="email" required>
            	</div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
            	<div class="col-md-3">
					<label>PIC Name :</label>
			  	</div>
			  	<div class="col-md-9">
            		<input type="text" placeholder="PIC Name" name="picName" required>
            	</div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
            	<div class="col-md-3">
					<label>PIC Phone :</label>
			  	</div>
			  	<div class="col-md-9">
            		<input type="text" placeholder="PIC Phone" name="phone" required>
            	</div>
            </div>
        </div>
        <div class="form-group">
            <div class="controls">
                <div class="col-md-3">
                    <label>Password :</label>
                </div>
                <div class="col-md-9">
                    <input type="password" placeholder="Password" name="password" required>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <p style="margin: 1.1em;color: red;">* use your Email as Username for signing in</p>
        </div>
	<div class="button-side btn-form">		
        <button type="submit" id="submit" class="btn-system btn-large">Register</button>
    </form>
	</div>
</div>
