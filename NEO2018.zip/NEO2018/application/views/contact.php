<?php if($this->session->flashdata('addMessage') != '') { ?>
<div class="alert alert-success alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('addMessage'); ?></strong>
        </div>
<?php
 }if($this->session->flashdata('failedAddMessage') != '') {
     ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo $this->session->flashdata('failedAddMessage'); ?></strong>
        </div>
    <?php
     }?>

<div class="map">
	<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15865.35727126805!2d106.65282299819333!3d-6.2189074982109895!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f9600dedbd81%3A0xa628640280dce57b!2sMall+%40+Alam+Sutera!5e0!3m2!1sen!2sid!4v1533358417159" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>

<!-- Start Content -->
<div id="content" style="margin-top: -25px;">
	<div class="container">
		
		<div class="row">
			
			<div class="col-md-8">
				
				<!-- Classic Heading -->
				<h4 class="classic-title"><span>Contact Us</span></h4>
				
				<!-- Start Contact Form -->
			    <form role="form" class="contact-form" id="contact-form" method="post" action="<?php echo base_url(); ?>/Guest/sendMessage">
				    <div class="form-group">
					    <div class="controls">
					    	<input type="text" placeholder="Name" name="name" required>
					    </div>
				    </div>
				    <div class="form-group">
					    <div class="controls">
					    	<input type="email" class="email" placeholder="Email" name="email" required>
					    </div>
				    </div>
				    <div class="form-group">
					    <div class="controls">
					    	<input type="text" class="requiredField" placeholder="Subject" name="subject" required>
					    </div>
				    </div>
				    <div class="form-group">
					    <div class="controls">
					    	<textarea rows="7"  placeholder="Message" name="message" required></textarea>
					    </div>
				    </div>
				<button type="submit" id="submit" class="btn-system btn-large">Send</button><div id="success" style="color:#34495e;"></div>
			    </form>
				<!-- End Contact Form -->
				
			</div>
			
			<div class="col-md-4">
				
				<!-- Classic Heading -->
				<h4 class="classic-title"><span>Information</span></h4>
				
				<!-- Divider -->
				<div class="hr1" style="margin-bottom:10px;"></div>
				
				<!-- Info - Icons List -->
				<table class="icons-list" id='linkContact'>
					<tr><td><i class="fa fa-map-marker"></i></td><td><strong>Address</td><td>:</strong> Binus University (Alam Sutera), Tangerang</td></tr>
					<tr><td><i class="fa fa-envelope-o"></i></td><td><strong>Email</td><td>:</strong> nationalenglisholympics@gmail.com</td></tr>
				 	<tr><td><i class="fa fa-calendar"></i></td><td><strong>Date</td><td>:</strong>  October 28<sup>th</sup> - 31<sup>st</sup>, 2017</td></tr>
					<tr><td><i class="fa fa-facebook"></i></td><td><strong>Facebook</td><td>:</strong> <a class='socmedLink animation-right' href="https://www.facebook.com/binus.neo" target="_blank">BNEC NEO</a></td></tr>
					<tr><td><i class="fa fa-instagram"></i></td><td><strong>Instagram</td><td>:</strong> <a class='socmedLink animation-right' href="https://www.instagram.com/bnecneo2017" target="_blank">bnecneo2017</a></td></tr>
					<tr><td><i class="fa fa-twitter"></i></td><td><strong>Twitter</td><td>:</strong> <a class='socmedLink animation-right' href="https://www.twitter.com/bnecneo2017" target="_blank">bnecneo2017</a></td></tr>
					<!-- <li><i class="fa fa-home"></i> <strong>Website :</strong> neo.mybnec.org</li> -->
				</table>
				
				<!-- Divider -->
				<div class="hr1" style="margin-bottom:15px;"></div>
				
				<!-- Classic Heading -->
				<h4 class="classic-title"><span>Contact Persons</span></h4>
				
				<!-- Info - List -->
				<!-- <ul class="list-unstyled"> -->
				<table id='contactTable'>
					<tr><td colspan='2'><strong>Name : </strong>Desti Yeo</td></tr>
					<tr>
						<td><img src="<?php echo base_url(); ?>assets/2018/images/ico/naverline.png" width="15" style='margin-left:-3px;'> <a href="http://line.me/ti/p/~destiyeo" target='_blank' class='animation-right'>destiyeo</a></td>
						<td><i class="fa fa-mobile"></i> <a href="tel:+6282288942083" class='animation-right'>(+62) 822 8894 2083</a></td>
					</tr>
					<tr><td colspan='2'><strong>Name : </strong>Jenny</td></tr>
					<tr>
						<td><img src="<?php echo base_url(); ?>assets/2018/images/ico/naverline.png" width="15" style='margin-left:-3px;'> <a href="http://line.me/ti/p/~taniajenitta" target='_blank' class='animation-right'>taniajenitta</a></td>
						<td><i class="fa fa-mobile"></i> <a href="tel:+6281316461021" class='animation-right'>(+62) 813 1646 1021</a></td>
					</tr>
					<tr><td colspan='2'><strong>Name : </strong>Leonnardo Benjamin Hutama</td></tr>
					<tr>
						<td><img src="<?php echo base_url(); ?>assets/2018/images/ico/naverline.png" width="15" style='margin-left:-3px;'> <a href="http://line.me/ti/p/~fresilia" target='_blank' class='animation-right'>fresilia</a></td>
						<td><i class="fa fa-mobile"></i> <a href="tel:+6289693952226" class='animation-right'>(+62) 896 9395 2226</a></td>
					</tr>
				</table>
				<!-- </ul> -->
				
			</div>
			
		</div>
		
	</div>
</div>
<!-- End content -->