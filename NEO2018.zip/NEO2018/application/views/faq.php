<div class="page-banner no-subtitle">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="white">Frequently Asked Question</h1>
			</div>
		</div>
	</div>
</div>

<div class="container">
	<div id="about-bnec" class="col-md-12">
      	<h4 class="classic-title"><span style="font-size: 18px;">Registration</span></h4>
		<div class="col-md-12" style="padding-left:3em;">
	      	<ul style="list-style: disc;">
	      		<li style="font-size:1.2em;"><b>How do I request an invitation letter for my institution?</b><br>
	      			You can request it to NEO’s contact person or person-in-charge (PIC) who will then help you.</li>
	      		<li style="font-size:1.2em;"><b>Who can participate in NEO?</b><br>
				Students are eligible to participate in The 2018 National English Olympics as long as they are enrolled in senior high schools (SMA/SMK/similar level).</li>
					
				<li style="font-size:1.2em;"><b>May I bring any supporter (teachers, friends, family, etc.) during the National English Olympics?</b><br>
				No, the observer is the only representative who is allowed to come and join the whole activity in National English Olympics.</li>

				<!-- <li style="font-size:1.2em;"><b>What is an observer?</b><br>
				An observer is a person who does not participate in the competition as a participant, but is allowed to observe the whole activity and get the same privileges as the participants, such as: food, transportation, and certificate. The observer`s fee is IDR 150,000.</li> -->

				<li style="font-size:1.2em;"><b>If I want to register for more than 1 participant, how many accounts should I have?</b><br>
				Each institution can only have one account for registration. If the committee were to find out two or more accounts from the same institution, the committee will have the right to delete one of the accounts.</li>

				<li style="font-size:1.2em;"><b>How and when will I know that my institution is officially registered?</b><br>
				You will get the official announcement right after you finish the payment in our NEO website.</li>

				<li style="font-size:1.2em;"><b>Can I secure my spot by giving partial/down payment?</b><br>
				We are sorry, but we do not accept any partial/down payment. You need to pay your entire fee to secure your spot.</li>

				<li style="font-size:1.2em;"><b>If I cancel the registration, will I get a full refund?</b><br>
				No, the committee will only provide 50% of the refund for any kind of payment. As an exception, if you’re cancelling your registration D-7 from the competition D-Day, you won’t get any refund at all.</li>

				<li style="font-size:1.2em;"><b>Can I edit my participant’s data after I register?</b><br>
				PIC’s and participant’s data can only be edited until October 21<sup>st</sup>, 2018. The committee will print the name stated on the website for the certificates. You will be charged IDR 35,000 if you change the name after that date.</li>

				<!-- <li style="font-size:1.2em;"><b>What’s the last step after registering the participants?</b><br>
				After registering the delegates, don't forget to send the institution logo to regist2017neo@gmail.com. The institution logo will be shown on the Opening Ceremony.</li> -->

	      	</ul>
      	</div>
	</div>

	<div class="col-md-12" style="margin-top:3em;">
      	<h4 class="classic-title"><span style="font-size:1.3em;">Accommodation and Transportation</span></h4>
		<div class="col-md-12" style="padding-left:3em;">
	      	<ul style="list-style: disc;">
	      		<li style="font-size:1.2em;"><b>Does the committee provide accommodation for us?</b><br>
	      			No, we don’t facilitate any accommodation, but we will provide you references of accommodation such as: lodging, transportation, food, etc. around BINUS University. </li>
	      		<li style="font-size:1.2em;"><b>Does the committee provide meals?</b><br>
				The committee provides meals only for breakfast and lunch. No dinner provided, except for the Final Day.</li>
					
				<li style="font-size:1.2em;"><b>Will the committee provide any property needed by the participants for the competition?</b><br>
				No, the committee will not provide any property, costume, and/or equipment.</li>
	      	</ul>
      	</div>
	</div>

	<div class="col-md-12" style="margin:3em 0 3em 0;">
      	<h4 class="classic-title"><span style="font-size:1.3em;">Competition</span></h4>
		<div class="col-md-12" style="padding-left:3em;">
	      	<ul style="list-style: disc;">
	      		<li style="font-size:1.2em;"><b>How many participants are allowed in each field for each institution?</b><br>
	      			You can only send a maximum of 3 people or team in each field of the competition.</li>
	      		<li style="font-size:1.2em;"><b>Do we need to send N-1 for the debate team?</b><br>
				No, you don’t need to send any N-1.</li>
	      	</ul>
      	</div>
	</div>
	
</div>