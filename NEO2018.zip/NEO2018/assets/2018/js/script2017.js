$(document).ready(function() {
	// $('[data-toggle="tooltip"]').tooltip();
	$('#tooltip-poi').tooltip({title: "<p style='color: #fff; font-size: 10pt;'>Points of Information</p>", html: true, placement: "top"}); 
	// $('#tool-ig').tooltip({title: "<p style='color: #fff; font-size: 10pt;'>Points of Information</p>", html: true, placement: "bottom"}); 
	var hash = window.location.hash.substr(1);
	if(hash == "debate")
	{
		$("#debate").addClass("in");
		if (performance.navigation.type != 1) scrolling();
	}
	else if(hash == "scrabble")
	{
		$("#scrabble").addClass("in");
		// $(window).scrollTop(162);
		if (performance.navigation.type != 1) scrolling();
	}
	else if(hash == "stortel")
	{
		$("#stortel").addClass("in");
		if (performance.navigation.type != 1) scrolling();
	}
	else if(hash == "news")
	{
		$("#news").addClass("in");
		// $(window).scrollTop(398);
		if (performance.navigation.type != 1) scrolling(2);
	}
	else if(hash == "speech")
	{
		$("#speech").addClass("in");
		// $(window).scrollTop(339);
		if (performance.navigation.type != 1) scrolling();
	}
	else
	{
		$("#scrabble").addClass("in");
	}



	$('#competL0').hover(
		function() {toBlack(0);}  ,
		function() {toDef(0);}
	);

	$('#competL1').hover(
		function() {toBlack(1);} , 
		function() {toDef(1);}
	);

	$('#competL2').hover(
		function() {toBlack(2);} , 
		function() {toDef(2);}
	);

	$('#competL3').hover(
		function() {toBlack(3);} , 
		function() {toDef(3);}
	);

	$('#competL4').hover(
		function() {toBlack(4);} , 
		function() {toDef(4);}
	);

});

function toBlack(x)
{
	var stringVar = 'competT' + x;

	// $(stringVar).animate({
		// color: '#000000'
	// }, 200);
	document.getElementById(stringVar).style.color = "#ffffff";
	document.getElementById(stringVar).style.transition = ".2s";
}

function toDef(x)
{
	var stringVar = 'competT' + x;
	// $(stringVar).animate({
	// 	color: '#126e63',
	// }, 200);
	document.getElementById(stringVar).style.color = "#bbbbbb";
	document.getElementById(stringVar).style.transition = ".2s";
}

function scrolling(x = 1)
{
	
	setTimeout(function(){
		var y = $(window).scrollTop();
		y -= 130;
		if(x == 2)
			y += 30;
		// alert('y='+y);
		$(window).scrollTop(0);
		setTimeout(function()
			{
				// $(window).scrollTop(y);
				console.log(y);
				var body = $("html, body");
				body.stop().animate({scrollTop: y}, 1500, 'swing')
			}, 350);	
	}, 250);
	
	
}

// function testa(xx)
// {
// 	// var y = $(window).scrollTop();  //your current y position on the page
// 	// $("html","body").stop().animate({scrollTop: y}, 500, 'swing')
// 	$(window).scrollTop(xx);
// 	// alert(xx);
// 	// var y = $(window).scrollTop();
// 	// console.log(y);
// }